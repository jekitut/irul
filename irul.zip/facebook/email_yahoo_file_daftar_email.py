# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


jumlah = 0
jml = []
berhasil = []
logo()
file = raw_input (u +"›"+ k +" File Daftar Email Yahoo "+ n +": ")
try:
	jl = open (file, "r").readlines()
	o = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
	for i in jl:
		jumlah += 1
		jml.append (jumlah)
		email = i.replace ("\n", "")
		yahoo = re.compile (r'@.*')
		yahooo = yahoo.search(email).group()
		if "yahoo.com" in yahooo:
			br = Browser()
			br.set_handle_robots(False)
			br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
			br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]
			br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
			br._factory.is_html = True
			br.select_form(nr=0)
			br["username"] = email
			klik = br.submit().read()
			rc = re.compile (r'"messages.ERROR_INVALID_USERNAME">.*')
			try:
				rcc = rc.search(klik).group()
			except:
				continue
			if '"messages.ERROR_INVALID_USERNAME">' in rcc:
				print h +"\r✔ "+ email +"   ",
				o.write (email +"\n")
				berhasil.append (email)
	o.close ()
	print n +"\r"+ 52* " ",
	print u +"\r• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
	enter()
except IOError:
	print m + tebal +"✘ File Daftar Email Yahoo Tidak Ditemukan"
	sleep (5)