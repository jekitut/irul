# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read ()
id = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket).text)
	print h +"✔ Komentar Ke "+ n +": "+ h + nama["name"]
	print u +"• "+ n +"Gunakan Tanda "+ h + tebal +"<>"+ n +" Untuk Membuat Baris Baru"
	km = raw_input (u +"›"+ h +" Tulis Komentar "+ n +": ")
	jumlah = raw_input (u +"›"+ p +" Jumlah Komentar "+ n +": ")
	isi = km.replace ("<>", "\n")
	jl = json.loads (get ("https://graph.facebook.com/v3.0/"+ id +"?fields=feed.limit("+ jumlah +")&access_token="+ toket).text)
	for i in jl["feed"]["data"]:
		berhasil.append (i["id"])
		post ("https://graph.facebook.com/"+ i["id"] +"/comments?message="+ isi +"&access_token="+ toket)
		sys.stdout.write (b +"\rMengomentari Postingan"+ n +" • "+ h + str(len(berhasil)) +"   ")
		sys.stdout.flush ()
	hapus()
	enter()
except KeyError:
	print m + tebal +"✘ Id Grup Tidak Ditemukan"+ n
	sleep (3)