# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read ()
nama = json.loads (get ("https://graph.facebook.com/me?access_token="+ toket).text)
print u +"• "+ k +"Menghapus Postingan "+ nama["name"]
jl = json.loads (get ("https://graph.facebook.com/me/feed?access_token="+ toket).text)
for i in jl["data"]:
	ok = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?method=delete&access_token="+ toket).text)
	if "True" in ok:
		berhasil.append (i["id"])
	else:
		gagal.append (i["id"])
	sys.stdout.write (b +"\rMenghapus Postingan"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
	sys.stdout.flush ()
hapus()
enter()