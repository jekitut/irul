# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
id = raw_input (u +"›"+ k +" Id Grup  "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket).text)
	print h +"✔ Email Anggota Grup "+ nama["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket).text)
	emailanggotagrup = []
	file = raw_input (u +"›"+ k +" Simpan File Dengan Nama "+ n +": ")
	o = open ("out/"+ file, "a")
	for i in jl["data"]:
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		try:
			o.write (jll["email"] + "\n")
			emailanggotagrup.append (jll["email"])
			print h +"\r✔ Email "+ n +": "+ h + jll["email"] +"   ",
		except KeyError:
			pass
		sys.stdout.flush ()
	o.close ()
	print n +"\r"+ 52* " ",
	print u +"\r•"+ k +" Jumlah Email "+ n +": "+ h + str(len(emailanggotagrup))
	print h +"✔ Menyimpan File Dengan Nama "+ n +": "+ b +"out/"+ file
	enter()
except KeyError:
	print m + tebal +"✘ Id Grup Tidak Ditemukan"+ n
	sleep (5)