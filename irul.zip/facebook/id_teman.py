# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
jl = json.loads (get ("https://graph.facebook.com/me/friends?access_token="+ toket).text)
idteman = []
file = raw_input (u +"›"+ k +" Simpan File Dengan Nama "+ n +": ")
o = open ("out/"+ file, "a")
for i in jl["data"]:
	o.write (i["id"] + "\n")
	idteman.append (i["id"])
	print h +"\r✔ Id "+ n +": "+ h + i["id"] +"   ",
	sys.stdout.flush ()
o.close ()
print n +"\r"+ 52* " ",
print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(idteman))
print h +"✔ Menyimpan File Dengan Nama "+ n +": "+ b +"out/"+ file
enter()