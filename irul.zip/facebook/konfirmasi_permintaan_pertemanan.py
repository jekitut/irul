# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read ()
jumlah = raw_input (u +"›"+ h +" Jumlah Konfirmasi "+ n +": ")
jl = json.loads (get ("https://graph.facebook.com/me/friendrequests?limit="+ jumlah +"&access_token="+ toket).text)
if "[]" in jl["data"]:
	print m + tebal +"✘ Permintaan Pertemanan Tidak Ditemukan"+ n
	sleep (3)
else:
	for i in jl["data"]:
		jll = json.loads (post ("https://graph.facebook.com/me/friends/"+ i["from"]["id"] +"?access_token="+ toket).text)
		if "True" in str(jll):
			berhasil.append (h +"✔ "+ i["from"]["name"])
		else:
			gagal.append (m +"✘ "+ i["from"]["name"])
		sys.stdout.write (b +"\rKonfirmasi Permintaan"+ n +" • "+ h + str(len(berhasil)) + n +" : "+ m + str(len(gagal)) +"   ")
		sys.stdout.flush ()
	print "\n"+ u + 53 * "═"
	for be in berhasil:
		print be
	for ga in gagal:
		print ga
	hapus()
	enter()