# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


def irul():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Aktifkan Penjaga Foto Profil"
	print u +"║"+ k +"02"+ u +"║"+ k +" Nonaktifkan Penjaga Foto Profil"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	guard = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if guard == "01" or guard == "1":
		start("true")
	elif guard == "02" or guard == "2":
		start("false")
	elif guard == "09" or guard == "9":
		system ("exit")
	else:
		salah()
		irul()


def start(enable = True):
	toket = open ("Token.txt", "r").read ()
	jl = json.loads (get ("https://graph.facebook.com/me?access_token="+ toket).text)
	id = jl["id"]
	rp = post ("https://graph.facebook.com/graphql", data = 'variables={"0":{"is_shielded": %s,"session_id":"9b78191c-84fd-4ab6-b0aa-19b39f04a6bc","actor_id":"%s","client_mutation_id":"b0316dd6-3fd6-4beb-aed4-bb29c5dc64b0"}}&method=post&doc_id=1477043292367183&query_name=IsShieldedSetMutation&strip_defaults=true&strip_nulls=true&locale=en_US&client_country_code=US&fb_api_req_friendly_name=IsShieldedSetMutation&fb_api_caller_class=IsShieldedSetMutation' % (enable, str(id)), headers = {"Content-Type" : "application/x-www-form-urlencoded", "Authorization" : "OAuth "+ toket}).text
	if '"is_shielded":true' in rp:
		logo()
		print h +"✔ Berhasil Mengaktifkan Penjaga Foto Profil"
		enter()
	elif '"is_shielded":false' in rp:
		logo()
		print k +"✔ Berhasil Menonaktifkan Penjaga Foto Profil"
		enter()
	else:
		print m + tebal +"!!! Error !!!"+ n
		sleep (3)


irul()