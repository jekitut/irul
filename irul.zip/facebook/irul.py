# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


def menu():
	system ("python2 login.py")
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"00"+ u +"║"+ n +" Lihat Informasi Akun Facebook"
	print u +"║"+ c +"01"+ u +"║"+ c +" Informasi Pengguna"
	print u +"║"+ m +"02"+ u +"║"+ m +" Mengambil Nomor / Email / Id"
	print u +"║"+ h +"03"+ u +"║"+ h +" Hack Akun Facebook"
	print u +"║"+ k +"04"+ u +"║"+ k +" Bot Facebook"
	print u +"║"+ p +"05"+ u +"║"+ p +" Hapus Cache"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	menuu = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if menuu == "00" or menuu == "0":
		facebook()
	elif menuu == "01" or menuu == "1":
		system ("python2 informasi.py")
	elif menuu == "02" or menuu == "2":
		mengambil()
	elif menuu == "03" or menuu == "3":
		hack()
	elif menuu == "04" or menuu == "4":
		bot()
	elif menuu == "05" or menuu == "5":
		system ("rm -rf out")
		mkdir ("out")
		menu()
	elif menuu == "09" or menuu == "9":
		chdir ("..")
		system ("python2 irul.py")
	else:
		salah()
		menu()


def facebook():
	logo()
	jl = json.loads (get ("https://graph.facebook.com/me?access_token="+ open ("Token.txt", "r").read ()).text)
	print n +"›"+ h +"›"+ k +"›"+ m +"›"+ k +" Nama "+ n +": "+ h + tebal + jl["name"] + n
	print n +"›"+ h +"›"+ k +"›"+ m +"›"+ h +" Id   "+ n +": "+ k + tebal + jl["id"] + n
	print u +"\n╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"01"+ u +"║"+ n +" Lihat Token Facebook"
	print u +"║"+ c +"02"+ u +"║"+ c +" Daftar Grup Facebook"
	print u +"║"+ m +"03"+ u +"║"+ m +" Pelindung Gambar Profil"
	print u +"║"+ h +"04"+ u +"║"+ h +" Keluar Akun Facebook"
	print u +"║"+ k +"09"+ u +"║"+ k +" Kembali"
	print u +"╚══╝\n"
	facebookk = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if facebookk == "01" or facebookk == "1":
		logo()
		print n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Token Facebook "+ n +": "+ open ("Token.txt", "r").read ()
		enter()
		facebook()
	elif facebookk == "02" or facebookk == "2":
		system ("python2 daftar_grup.py")
		facebook()
	elif facebookk == "03" or facebookk == "3":
		system ("python2 penjaga_foto_profil.py")
		facebook()
	elif facebookk == "04" or facebookk == "4":
		system ("rm -rf Token.txt")
		menu()
	elif facebookk == "09" or facebookk == "9":
		menu()
	else:
		salah()
		facebook()


def mengambil():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"01"+ u +"║"+ n +" Nomor Teman"
	print u +"║"+ c +"02"+ u +"║"+ c +" Email Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Id Teman"
	print u +"║"+ h +"04"+ u +"║"+ h +" Nomor Temannya Dari Teman"
	print u +"║"+ k +"05"+ u +"║"+ k +" Email Temannya Dari Teman"
	print u +"║"+ p +"06"+ u +"║"+ p +" Id Temannya Dari Teman"
	print u +"║"+ b +"07"+ u +"║"+ b +" Nomor Anggota Grub"
	print u +"║"+ n +"08"+ u +"║"+ n +" Email Anggota Grub"
	print u +"║"+ c +"09"+ u +"║"+ c +" Id Anggota Grub"
	print u +"║"+ m +"10"+ u +"║"+ m +" Mencari Id"
	print u +"║"+ h +"99"+ u +"║"+ h +" Kembali"
	print u +"╚══╝\n"
	mengambill = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if mengambill == "01" or mengambill == "1":
		system ("python2 nomor_teman.py")
		mengambil()
	elif mengambill == "02" or mengambill == "2":
		system ("python2 email_teman.py")
		mengambil()
	elif mengambill == "03" or mengambill == "3":
		system ("python2 id_teman.py")
		mengambil()
	elif mengambill == "04" or mengambill == "4":
		system ("python2 nomor_temannya_dari_teman.py")
		mengambil()
	elif mengambill == "05" or mengambill == "5":
		system ("python2 email_temannya_dari_teman.py")
		mengambil()
	elif mengambill == "06" or mengambill == "6":
		system ("python2 id_temannya_dari_teman.py")
		mengambil()
	elif mengambill == "07" or mengambill == "7":
		system ("python2 nomor_anggota_grup.py")
		mengambil()
	elif mengambill == "08" or mengambill == "8":
		system ("python2 email_anggota_grup.py")
		mengambil()
	elif mengambill == "09" or mengambill == "9":
		system ("python2 id_anggota_grup.py")
		mengambil()
	elif mengambill == "10":
		print m +"\nSilahkan Hubungi Pembuat Script Ini"
		print h + tebal +"https://github.com/rezadkim/dark-fb"+ n
		sleep (5)
		mengambil()
	elif mengambill == "99":
		menu()
	else:
		salah()
		mengambil()


def hack():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Acak (Kata Sandi Otomatis)"
	print u +"║"+ h +"02"+ u +"║"+ h +" Acak (Memerlukan File Daftar Id Profil)"
	print u +"║"+ k +"03"+ u +"║"+ k +" Target (Kata Sandi Otomatis)"
	print u +"║"+ k +"04"+ u +"║"+ k +" Target (Memerlukan File Daftar Kata Sandi)"
	print u +"║"+ m +"05"+ u +"║"+ m +" Mengambil Email Yahoo"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	hackk = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if hackk == "01" or hackk == "1":
		system ("python2 acak_kata_sandi_otomatis.py")
		hack()
	elif hackk == "02" or hackk == "2":
		system ("python2 acak_file_daftar_id_profil.py")
		hack()
	elif hackk == "03" or hackk == "3":
		system ("python2 target_kata_sandi_otomatis.py")
		hack()
	elif hackk == "04" or hackk == "4":
		system ("python2 target_file_daftar_kata_sandi.py")
		hack()
	elif hackk == "05" or hackk == "5":
		yahoo()
	elif hackk == "09" or hackk == "9":
		menu()
	else:
		salah()
		hack()


def yahoo():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Email Yahoo Teman"
	print u +"║"+ k +"02"+ u +"║"+ k +" Email Yahoo Temannya Dari Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Email Yahoo Anggota Grub"
	print u +"║"+ c +"04"+ u +"║"+ c +" Email Yahoo (Memerlukan File Daftar Email Yahoo)"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	yahooo = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if yahooo == "01" or yahooo == "1":
		system ("python2 email_yahoo_teman.py")
		yahoo()
	elif yahooo == "02" or yahooo == "2":
		system ("python2 email_yahoo_temannya_dari_teman.py")
		yahoo()
	elif yahooo == "03" or yahooo == "3":
		system ("python2 email_yahoo_anggota_grup.py")
		yahoo()
	elif yahooo == "04" or yahooo == "4":
		system ("python2 email_yahoo_file_daftar_email.py")
		yahoo()
	elif yahooo == "09" or yahooo == "9":
		hack()
	else:
		salah()
		yahoo()


def bot():
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"01"+ u +"║"+ n +" Buat Postingan"
	print u +"║"+ c +"02"+ u +"║"+ c +" Reactions Postingan Profil"
	print u +"║"+ m +"03"+ u +"║"+ m +" Reactions Postingan Grup"
	print u +"║"+ h +"04"+ u +"║"+ h +" Mengomentari Postingan Profil"
	print u +"║"+ k +"05"+ u +"║"+ k +" Mengomentari Postingan Grup"
	print u +"║"+ p +"06"+ u +"║"+ p +" Menghapus Semua Postingan"
	print u +"║"+ b +"07"+ u +"║"+ b +" Konfirmasi Permintaan Pertemanan"
	print u +"║"+ n +"08"+ u +"║"+ n +" Menghapus Semua Pertemanan"
	print u +"║"+ c +"09"+ u +"║"+ c +" Kembali"
	print u +"╚══╝\n"
	bott = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if bott == "01" or bott == "1":
		system ("python2 buat_postingan.py")
		bot()
	elif bott == "02" or bott == "2":
		system ("python2 reactions_postingan_profil.py")
		bot()
	elif bott == "03" or bott == "3":
		system ("python2 reactions_postingan_grup.py")
		bot()
	elif bott == "04" or bott == "4":
		system ("python2 mengomentari_postingan_profil.py")
		bot()
	elif bott == "05" or bott == "5":
		system ("python2 mengomentari_postingan_grup.py")
		bot()
	elif bott == "06" or bott == "6":
		system ("python2 menghapus_semua_postingan.py")
		bot()
	elif bott == "07" or bott == "7":
		system ("python2 konfirmasi_permintaan_pertemanan.py")
		bot()
	elif bott == "08" or bott == "8":
		try:
			system ("python2 menghapus_semua_pertemanan.py")
			bot()
		except KeyboardInterrupt:
			bot()
	elif bott == "09" or bott == "9":
		menu()
	else:
		salah()
		bot()


menu()