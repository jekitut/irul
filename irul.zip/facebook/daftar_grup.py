# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
try:
	toket = open ("Token.txt", "r").read ()
	jl = json.loads (get ("https://graph.facebook.com/me/groups?access_token="+ toket).text)
	for i in jl["data"]:
		berhasil.append (h +"✔ "+ i["id"] + u +" => "+ h + i["name"])
	sys.stdout.write (b +"\rGrup Saya"+ n +" • "+ h + str(len(berhasil)) +"   ")
	sys.stdout.flush ()
	print "\n"+ u + 53 * "═"
	for be in berhasil:
		print be
	hapus()
	enter()
except KeyError:
	print m + tebal +"✘ Tidak Ada Daftar Grup"+ n
	sleep (3)