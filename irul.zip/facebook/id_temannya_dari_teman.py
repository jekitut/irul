# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
id = raw_input (u +"›"+ k +" Id Profil  "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/"+ id +"?access_token="+ toket).text)
	print h +"✔ Id Temannya Dari "+ nama["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"?fields=friends.limit(5000)&access_token="+ toket).text)
	idtemannyadariteman = []
	file = raw_input (u +"›"+ k +" Simpan File Dengan Nama "+ n +": ")
	o = open ("out/"+ file, "a")
	for i in jl["friends"]["data"]:
		o.write (i["id"] + "\n")
		idtemannyadariteman.append (i["id"])
		print h +"\r✔ Id "+ n +": "+ h + i["id"] +"   ",
		sys.stdout.flush ()
	o.close ()
	print n +"\r"+ 52* " ",
	print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(idtemannyadariteman))
	print h +"✔ Menyimpan File Dengan Nama "+ n +": "+ b +"out/"+ file
	enter()
except KeyError:
	print m + tebal +"✘ Id Profil Tidak Ditemukan"+ n
	sleep (5)