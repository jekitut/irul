# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


def hasil():
	print "\n"+ u + 53 * "═"
	for be in berhasil:
		print be
	hapus()
	enter()


def irul():
	global berhasil
	logo()
	toket = open ("Token.txt", "r").read ()
	try:
		print u +"• "+ m +"Untuk Berhenti Tekan Tombol CTRL + C"
		jl = json.loads (get ("https://graph.facebook.com/me/friends?access_token="+ toket).text)
		for i in jl["data"]:
			delete ("https://graph.facebook.com/me/friends?uid="+ i["id"] +"&access_token="+ toket)
			berhasil.append (h +"✔ "+ i["name"])
			sys.stdout.write (b +"\rMenghapus Pertemanan"+ n +" • "+ h + str(len(berhasil)) +"   ")
			sys.stdout.flush ()
		hasil()
	except KeyboardInterrupt:
		hasil()


irul()