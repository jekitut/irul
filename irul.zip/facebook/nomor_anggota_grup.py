# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read ()
id = raw_input (u +"›"+ k +" Id Grup  "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/group/?id="+ id +"&access_token="+ toket).text)
	print h +"✔ Nomor Anggota Grup "+ nama["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"/members?fields=name,id&limit=999999999&access_token="+ toket).text)
	file = raw_input (u +"›"+ k +" Simpan File Dengan Nama "+ n +": ")
	o = open ("out/"+ file, "a")
	for i in jl["data"]:
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		try:
			o.write (jll["mobile_phone"] +" => "+ i["name"] +"\n")
			berhasil.append (jll["mobile_phone"])
		except KeyError:
			gagal.append (i["id"])
		sys.stdout.write (b +"\rNomor"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
		sys.stdout.flush ()
	o.close ()
	hapus()
	print h +"\r✔ Menyimpan File Dengan Nama "+ n +": "+ b +"out/"+ file
	enter()
except KeyError:
	print m + tebal +"✘ Id Grup Tidak Ditemukan"+ n
	sleep (3)