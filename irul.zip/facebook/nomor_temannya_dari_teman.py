# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
id = raw_input (u +"›"+ k +" Id Profil  "+ n +": ")
try:
	nama = json.loads (get ("https://graph.facebook.com/"+ id +"?access_token="+ toket).text)
	print h +"✔ Nomor Temannya Dari "+ nama["name"]
	jl = json.loads (get ("https://graph.facebook.com/"+ id +"/friends?access_token="+ toket).text)
	nomortemannyadariteman = []
	file = raw_input (u +"›"+ k +" Simpan File Dengan Nama "+ n +": ")
	o = open ("out/"+ file, "a")
	for i in jl["data"]:
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		try:
			o.write (jll["mobile_phone"] + "\n")
			nomortemannyadariteman.append (jll["mobile_phone"])
			print h +"\r✔ Nomor "+ n +": "+ h + jll["mobile_phone"] +"   ",
		except KeyError:
			pass
		sys.stdout.flush ()
	o.close ()
	print n +"\r"+ 52* " ",
	print u +"\r•"+ k +" Jumlah Nomor "+ n +": "+ h + str(len(nomortemannyadariteman))
	print h +"✔ Menyimpan File Dengan Nama "+ n +": "+ b +"out/"+ file
	enter()
except KeyError:
	print m + tebal +"✘ Id Profil Tidak Ditemukan"+ n
	sleep (5)