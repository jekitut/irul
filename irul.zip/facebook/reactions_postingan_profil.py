# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


reaksi = []
def reactions():
	global tipe
	logo()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ b +"01"+ u +"║"+ b +" Suka"
	print u +"║"+ p +"02"+ u +"║"+ p +" Super"
	print u +"║"+ h +"03"+ u +"║"+ h +" Haha"
	print u +"║"+ h +"04"+ u +"║"+ h +" Wow"
	print u +"║"+ k +"05"+ u +"║"+ k +" Sedih"
	print u +"║"+ m +"06"+ u +"║"+ m +" Marah"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	reactionss = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if reactionss == "01" or reactionss == "1":
		tipe = "LIKE"
		start()
	elif reactionss == "02" or reactionss == "2":
		tipe = "LOVE"
		start()
	elif reactionss == "03" or reactionss == "3":
		tipe = "HAHA"
		start()
	elif reactionss == "04" or reactionss == "4":
		tipe = "WOW"
		start()
	elif reactionss == "05" or reactionss == "5":
		tipe = "SAD"
		start()
	elif reactionss == "06" or reactionss == "6":
		tipe = "ANGRY"
		start()
	elif reactionss == "09" or reactionss == "9":
		system ("exit")
	else:
		salah()
		reactions()


def start():
	logo()
	toket = open ("Token.txt", "r").read()
	id = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
	try:
		nama = json.loads (get ("https://graph.facebook.com/"+ id +"?access_token="+ toket).text)
		print h +"✔ Reactions "+ b + tipe + h +" Ke "+ n +": "+ h + nama["name"]
		jumlah = raw_input (u +"›"+ h +" Jumlah Reactions "+ n +": ")
		jl = json.loads (get ("https://graph.facebook.com/"+ id +"?fields=feed.limit("+ jumlah +")&access_token="+ toket).text)
		for i in jl["feed"]["data"]:
			reaksi.append (i["id"])
			post ("https://graph.facebook.com/"+ i["id"] +"/reactions?type="+ tipe +"&access_token="+ toket)
			print h +"\r✔ "+ p + i["id"][16:].replace ("\n", " ") +" "+ b + tipe +" "+ n + str(len(reaksi)) +"   ",
			sys.stdout.flush ()
		print ""
		enter()
	except KeyError:
		print m + tebal +"✘ Id Profil Tidak Ditemukan"+ n
		sleep (3)


reactions()