# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
toket = open ("Token.txt", "r").read()
nama_pengguna = raw_input (u +"›"+ k +" Nama / Id "+ n +": ")
print ""
jl = json.loads (get ("https://graph.facebook.com/me/friends?access_token="+ toket).text)
for i in jl["data"]:
	if nama_pengguna in i["name"] or nama_pengguna in i["id"]:
		jll = json.loads (get ("https://graph.facebook.com/"+ i["id"] +"?access_token="+ toket).text)
		print u +"╔═╗"
		try:
			print u +"║"+ h +"•"+ u +"║"+ b +" Nama  "+ n +": "+ h + jll["name"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Nama  "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			print u +"║"+ h  +"•"+ u +"║"+ b +" Nomor "+ n +": "+ h + jll["mobile_phone"]
		except KeyError:
			print u +"║"+ m  +"•"+ u +"║"+ b +" Nomor "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			print u +"║"+ h +"•"+ u +"║"+ b +" Email "+ n +": "+ h + jll["email"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Email "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			print u +"║"+ h +"•"+ u +"║"+ b +" Id    "+ n +": "+ h + jll["id"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Id    "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			print u +"║"+ h +"•"+ u +"║"+ b +" Tanggal Lahir "+ n +": "+ h + jll["birthday"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Tanggal Lahir "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			print u +"║"+ h +"•"+ u +"║"+ b +" Alamat "+ n +": "+ h + jll["location"]["name"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Alamat "+ n +": "+ m +"Data Tidak Ditemukan"
		try:
			for ii in jll["education"]:
				print u +"║"+ h +"•"+ u +"║"+ b +" Pendidikan "+ n +": "+ h + ii["school"]["name"]
		except KeyError:
			print u +"║"+ m +"•"+ u +"║"+ b +" Pendidikan "+ n +": "+ m +"Data Tidak Ditemukan"
		print u +"╚═╝"
		enter()
		system ("python2 irul.py")
else:
	print m + tebal +"✘ Akun Facebook Tidak Ditemukan"+ n
	sleep (5)
	system ("python2 irul.py")