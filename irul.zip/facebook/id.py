# -*- coding: utf-8 -*-
import os, sys
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.setdefaultencoding ("utf8")
# Ahmad Khoirul Marzuqin
os.system ("clear")
print u +"               ╔════════════════════╗"
print u +"               ║"+ k +" Daftar "+ h +"ID"+ b +" Facebook "+ u +"║"
print u +"               ╚════════════════════╝\n"
print u +"•"+ b +" id.ayu.redhiesta"
print u +"•"+ b +" id.dia.kucel"
print u +"•"+ b +" id.fauzi"
print u +"•"+ b +" id.gai"
print u +"•"+ b +" id.hams.abn"
print u +"•"+ b +" id.irul"
print u +"•"+ b +" id.kristina.purnama.sari"
print u +"•"+ b +" id.ree"
print u +"•"+ b +" id.yulia.rachma"
print u +"•"+ b +" id.yulia.syafitri"
# Ahmad Khoirul Marzuqin