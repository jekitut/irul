# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


logo()
isi = raw_input (u +"›"+ k +" Buat Postingan "+ n +": ")
if isi == "":
	print m + tebal +"\n!!! Jangan Kosong !!!"+ n
	sleep (3)
else:
	toket = open ("Token.txt", "r").read ()
	jl = json.loads (get ("https://graph.facebook.com/me/feed?method=POST&message="+ isi +"&access_token="+ toket).text)
	enter()