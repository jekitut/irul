n="\033[0m" # Normal

# Teks
miring="\033[3m" # Miring
gb="\033[4m" # Garis Bawah
tebal="\033[5m" # Tebal
gt="\033[9m" # Garis Tengah

hitam="\033[30m" # Hitam
c="\033[90m" # Coklat
m="\033[91m" # Merah
h="\033[92m" # Hijau
k="\033[93m" # Kuning
u="\033[94m" # Ungu
p="\033[95m" # Pink
b="\033[96m" # Biru

# Latar Belakang
ba="\033[100m" # Background Abu-Abu
bm="\033[101m" # Background Merah
bh="\033[102m" # Background Hijau
bk="\033[103m" # Background Kuning
bu="\033[104m" # Background Ungu
bp="\033[105m" # Background Pink
bb="\033[106m" # Background Biru
bputih="\033[107m" # Background Putih

# Irul