<?php
# Ahmad Khoirul Marzuqin
$n = "\e[0m"; # Normal
# Ahmad Khoirul Marzuqin
$c = "\e[90m"; # Coklat
# Ahmad Khoirul Marzuqin
$m = "\e[91m"; # Merah
# Ahmad Khoirul Marzuqin
$h = "\e[92m"; # Hijau
# Ahmad Khoirul Marzuqin
$k = "\e[93m"; # Kuning
# Ahmad Khoirul Marzuqin
$u = "\e[94m"; # Ungu
# Ahmad Khoirul Marzuqin
$p = "\e[95m"; # Pink
# Ahmad Khoirul Marzuqin
$b = "\e[96m"; # Biru
# Ahmad Khoirul Marzuqin
$name = $p."Nama Pembuat  :$b Ahmad Khoirul Marzuqin
".$p."Messenger     :$b m.me/ahmadkhoirulmarzuqin
".$n;
$file = file ("nama.json");
if ($file) {
$file_get_contents = file_get_contents ("nama.json");
$json_decode = json_decode ($file_get_contents, true);
foreach ($json_decode as $d) {
$nama = $d["nama"];
echo $p."Nama Pengguna :$b ".$nama."
".$name;
}
} else {
system ("clear");
echo shell_exec ("sh 0");
$array [] = array (
"nama" => readline ($p."Nama Pengguna :$b ")
);
$json_encode = json_encode ($array, JSON_PRETTY_PRINT);
file_put_contents ("nama.json", $json_encode);
$file_get_contents = file_get_contents ("nama.json");
$json_decode = json_decode ($file_get_contents, true);
foreach ($json_decode as $d) {
$nama = $d["nama"];
echo $name;
}
}
?>