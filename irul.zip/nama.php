<?php
# Ahmad Khoirul Marzuqin
require ("php");
# Ahmad Khoirul Marzuqin
$name = $k."Nama Pembuat $n :$c $miring".$tebal."Ahmad Khoirul Marzuqin
$n";
# Ahmad Khoirul Marzuqin
$file = file ("nama.json");
if ($file) {
$file_get_contents = file_get_contents ("nama.json");
$json_decode = json_decode ($file_get_contents, true);
foreach ($json_decode as $d) {
$nama = $d["nama"];
echo $h."Nama Pengguna$n : $nama
$name";
}
} else {
system ("clear");
echo shell_exec ("sh 0");
$array [] = array (
"nama" => readline ($h."Nama Pengguna$n : ")
);
$json_encode = json_encode ($array, JSON_PRETTY_PRINT);
file_put_contents ("nama.json", $json_encode);
echo $name;
}
# Ahmad Khoirul Marzuqin
?>