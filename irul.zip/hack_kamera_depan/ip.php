<?php
# Ahmad Khoirul Marzuqin
if (!empty($_SERVER['HTTP_CLIENT_IP']))
    {
      $ipaddress = $_SERVER['HTTP_CLIENT_IP']."\r\n";
    }
elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    {
      $ipaddress = $_SERVER['HTTP_X_FORWARDED_FOR']."\r\n";
    }
else
    {
      $ipaddress = $_SERVER['REMOTE_ADDR']."\r\n";
    }
# Ahmad Khoirul Marzuqin
$useragent = " User-Agent: ";
# Ahmad Khoirul Marzuqin
$browser = $_SERVER['HTTP_USER_AGENT'];
# Ahmad Khoirul Marzuqin
$file = 'ip.txt';
# Ahmad Khoirul Marzuqin
$victim = "IP: ";
# Ahmad Khoirul Marzuqin
$fp = fopen($file, 'a');
# Ahmad Khoirul Marzuqin
fwrite($fp, $victim);
# Ahmad Khoirul Marzuqin
fwrite($fp, $ipaddress);
# Ahmad Khoirul Marzuqin
fwrite($fp, $useragent);
# Ahmad Khoirul Marzuqin
fwrite($fp, $browser);
# Ahmad Khoirul Marzuqin
fclose($fp);
# Ahmad Khoirul Marzuqin