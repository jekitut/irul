<?php
# Ahmad Khoirul Marzuqin
require (__dir__."/../../php");
# Ahmad Khoirul Marzuqin
system ("clear");
# Ahmad Khoirul Marzuqin
$ko = "$u              ╔══════════════════════╗
              ║$k Jumlah Kode OTP :$h 18$u ║
              ╚══════════════════════╝$k
";
# Ahmad Khoirul Marzuqin
$file = file ("nomor.json");
# Ahmad Khoirul Marzuqin
if ($file) {
$file_get_contents = file_get_contents ("nomor.json");
# Ahmad Khoirul Marzuqin
$json_decode = json_decode ($file_get_contents, true);
# Ahmad Khoirul Marzuqin
foreach ($json_decode as $d) {
$nomor = $d["nomor"];
$jumlah = $d["jumlah"];
$jeda = $d["jeda"];
}
# Ahmad Khoirul Marzuqin
echo "$ko
Nomor Tujuan$n :$h $nomor$h
Jumlah Pesan$n :$k $jumlah$p
Jeda Pesan  $n :$b $jeda$n Detik
";
# Ahmad Khoirul Marzuqin
} else {
# Ahmad Khoirul Marzuqin
system ("clear");
# Ahmad Khoirul Marzuqin
echo "$ko
";
# Ahmad Khoirul Marzuqin
$array [] = array (
"nomor" => readline ($k."Nomor Tujuan$n :$h "),
"jumlah" => readline ($h."Jumlah Pesan$n :$k "),
"jeda" => readline ($p."Jeda Pesan  $n :$b ")
);
# Ahmad Khoirul Marzuqin
$json_encode = json_encode ($array, JSON_PRETTY_PRINT);
# Ahmad Khoirul Marzuqin
file_put_contents ("nomor.json", $json_encode);
# Ahmad Khoirul Marzuqin
$file_get_contents = file_get_contents ("nomor.json");
# Ahmad Khoirul Marzuqin
$json_decode = json_decode ($file_get_contents, true);
# Ahmad Khoirul Marzuqin
foreach ($json_decode as $d) {
$nomor = $d["nomor"];
$jumlah = $d["jumlah"];
$jeda = $d["jeda"];
}
# Ahmad Khoirul Marzuqin
}
# Ahmad Khoirul Marzuqin
?>