# -*- coding: utf-8 -*-
import os, re, requests, sys, time
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
from importlib import reload
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.stdout.encoding + str(("utf8"))
# Ahmad Khoirul Marzuqin
s = requests.Session()
# Ahmad Khoirul Marzuqin
def irul():
	try:
		rg = requests.get ("https://raw.githubusercontent.com/jekitut/irul/master/server").text
		os.system ("clear")
		berhasil = 0
		gagal = 0
		print (u +"                   ╔════════════╗")
		print (u +"                   ║"+ k +" Sms Gratis "+ u +"║")
		print (u +"                   ╚════════════╝\n")
		nomor = int(input(k +"Nomor Tujuan"+ n +" : "+ h))
		pesan = input(p +"Isi Pesan"+ n +"    : "+ b)
		jumlah = int(input(h +"Jumlah Pesan"+ n +" : "+ k))
		print ("")
		j = 0
		while (j < jumlah):
			j+= 1
			sp = s.post ("http://sms.payuterus.biz/alpha/send.php", data = {"nohp": nomor, "pesan": pesan, "captcha": eval(re.findall(r'<span>(.*?) = </span>', s.get ("http://sms.payuterus.biz/alpha/?a=keluar", headers = {"Referer": "http://sms.payuterus.biz/alpha/", "User-Agent": "Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36"}).text)[0].replace("x", "*").replace(":", "/")), "key": re.findall(r'value="(\d+)"', s.get ("http://sms.payuterus.biz/alpha/?a=keluar", headers = {"Referer": "http://sms.payuterus.biz/alpha/", "User-Agent": "Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36"}).text)[0]}, headers = {"Referer": "http://sms.payuterus.biz/alpha/", "User-Agent": "Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36"}).text
			if "SMS Gratis Telah Dikirim" in str(sp):
				berhasil+= 1
				sys.stdout.write (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ k +"Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",)
			else:
				gagal+= 1
				sys.stdout.write (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ k +"Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",)
			sys.stdout.flush()
		print (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ h +"Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal))
	except requests.exceptions.ConnectionError:
		titik = ["    ", "•   ", "••  ", "••• "]
		for t in titik:
			sys.stdout.write (m +"\r!!! Aktifkan Koneksi Internet "+ n + t,)
			sys.stdout.flush()
			time.sleep (1)
		irul()
	except Exception:
		print (m +"\n!!! Masukkan Dengan Benar")
		time.sleep (3)
		irul()
# Ahmad Khoirul Marzuqin
irul()
# Ahmad Khoirul Marzuqin