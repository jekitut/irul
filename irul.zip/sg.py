# -*- coding: utf-8 -*-
import mechanize, os, sys, time
# Ahmad Khoirul Marzuqin
from importlib import reload
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
from bs4 import BeautifulSoup as BS
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.stdout.encoding + str(("utf8"))
# Ahmad Khoirul Marzuqin
def irul():
	try:
		os.system ("clear")
		br = mechanize.Browser()
		br.set_handle_equiv(True)
		br.set_handle_gzip(True)
		br.set_handle_redirect(True)
		br.set_handle_referer(True)
		br.set_handle_robots(False)
		br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
		br.addheaders =[('Connection','keep-alive'),
		('Pragma','no-cache'),
		('Cache-Control','no-cache'),
		('Origin','http://sms.payuterus.biz'),
		('Upgrade-Insecure-Requests','1'),
		('Content-Type','application/x-www-form-urlencoded'),
		('User-Agent','Mozilla/5.0 (Linux; Android 4.4.2; Nexus 4 Build/KOT49H) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/34.0.1847.114 Mobile Safari/537.36'),
		('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'),
		('Referer','http://sms.payuterus.biz/alpha/'),
		('Accept-Encoding','gzip, deflate'),
		('Accept-Language','id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7')]
		url = 'http://sms.payuterus.biz/alpha'
		print (u +"                   ╔════════════╗")
		print (u +"                   ║"+ k +" Sms Gratis "+ u +"║")
		print (u +"                   ╚════════════╝\n")
		no = int(input(k +"Nomor Tujuan"+ n +" : "+ h))
		psn = input(p +"Isi Pesan"+ n +"    : "+ b)
		jm = int(input(h +"Jumlah Pesan"+ n +" : "+ k))
		print ("")
		msg=psn.split(' ')
		for j in range (1, jm + 1):
			o=[]
			bs=BS(br.open(url),features="html.parser")
			for x in bs.find_all("span"):
				o.append(x.text)
			capt=int(str(o)[2])+int(str(o)[6])
			br.select_form(nr=0)
			br.form['nohp']=str(no)
			br.form['pesan']=str(msg)
			br.form['captcha']=str(capt)
			sub=br.submit().read()
			if 'SMS Gratis Telah Dikirim' in str(sub):
				print (h +"Mengirim Pesan Sms : "+ b + str(j) + h +" ✓   \r")
			else:
				print (m +"limited "+ n +"or"+ m +" connection lost\r")
	except (KeyError, IOError):
		titik = ["     ", ".    ", "..   ", "...  ", ".... ", "....."]
		for t in titik:
			print (m +"\r!!! Aktifkan Koneksi Internet "+ n + t,)
			sys.stdout.flush()
			time.sleep (1)
		irul()
	except (Exception):
		print (m +"\n!!! Masukkan Dengan Benar")
		time.sleep (3)
		irul()
# Ahmad Khoirul Marzuqin
irul()
# Ahmad Khoirul Marzuqin