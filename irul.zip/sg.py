# -*- coding: utf-8 -*-
import mechanize, os, sys, time
# Ahmad Khoirul Marzuqin
from warna import *
# Ahmad Khoirul Marzuqin
from bs4 import BeautifulSoup as BS
# Ahmad Khoirul Marzuqin
from importlib import reload
# Ahmad Khoirul Marzuqin
from mechanize import Browser
# Ahmad Khoirul Marzuqin
reload (sys)
# Ahmad Khoirul Marzuqin
sys.stdout.encoding + str(("utf8"))
# Ahmad Khoirul Marzuqin
def irul():
	try:
		os.system ("clear")
		berhasil = 0
		gagal = 0
		br = mechanize.Browser()
		br.set_handle_equiv(True)
		br.set_handle_gzip(True)
		br.set_handle_redirect(True)
		br.set_handle_referer(True)
		br.set_handle_robots(False)
		br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
		br.addheaders =[('Connection','keep-alive'),
		('Pragma','no-cache'),
		('Cache-Control','no-cache'),
		('Origin','http://sms.payuterus.biz'),
		('Upgrade-Insecure-Requests','1'),
		('Content-Type','application/x-www-form-urlencoded'),
		('User-Agent','Opera/9.80 (Android; Opera Mini/8.0.1807/36.1609; U; en) Presto/2.12.423 Version/12.16'),
		('Accept','text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3'),
		('Referer','http://sms.payuterus.biz/alpha/'),
		('Accept-Encoding','gzip, deflate'),
		('Accept-Language','id-ID,id;q=0.9,en-US;q=0.8,en;q=0.7'),
		('Cookie','_ga=GA1.2.131924726.1560439960; PHPSESSID=jjrqqaakmfcgfgbtjt8tve5595; _gid=GA1.2.1969561921.1561024035; _gat=1')]
		url = 'http://sms.payuterus.biz/alpha'
		#url = 'http://sms.payuterus.biz/alpha/index.php?a=keluar'
		print (u +"                   ╔════════════╗")
		print (u +"                   ║"+ k +" Sms Gratis "+ u +"║")
		print (u +"                   ╚════════════╝\n")
		no = int(input(k +"Nomor Tujuan"+ n +" : "+ h))
		psn = input(p +"Isi Pesan"+ n +"    : "+ b)
		jumlah = int(input(h +"Jumlah Pesan"+ n +" : "+ k))
		print ("")
		msg=psn.split(' ')
		j = 0
		while (j < jumlah):
			j+= 1
			o=[]
			bs=BS(br.open(url),features="html.parser")
			for x in bs.find_all("span"):
				o.append(x.text)
			capt=int(str(o)[2])+int(str(o)[6])
			br.select_form(nr=0)
			br.form['nohp']=str(no)
			br.form['pesan']=str(msg)
			br.form['captcha']=str(capt)
			sub=br.submit().read()
			if 'SMS Gratis Telah Dikirim' in str(sub):
				berhasil+= 1
				sys.stdout.write (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ k +"Mengirim Pesan"+ n +" => "+ b + str(j) + h +" ✔ ",)
			else:
				gagal+= 1
				sys.stdout.write (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ k +"Mengirim Pesan"+ n +" => "+ b + str(j) + m +" ✘ ",)
			sys.stdout.flush()
		print (k +"\rSms "+ b + gb +"smsae.in"+ n +" • "+ h +"Berhasil"+ n +" => "+ h + str(berhasil) + u +" |"+ m +" Gagal"+ n +" => "+ m + str(gagal))
		os.system ("xdg-open http://sms.payuterus.biz")
	except mechanize.URLError:
		titik = ["    ", "•   ", "••  ", "••• "]
		for t in titik:
			sys.stdout.write (m +"\r!!! Aktifkan Koneksi Internet "+ n + t,)
			sys.stdout.flush()
			time.sleep (1)
		irul()
	except Exception:
		print (m +"\n!!! Masukkan Dengan Benar")
		time.sleep (3)
		irul()
# Ahmad Khoirul Marzuqin
irul()
# Ahmad Khoirul Marzuqin