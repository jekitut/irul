# -*- coding: utf-8 -*-
from warna import *


def jekitut():
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"00"+ u +"║"+ n +" Pembaruan"
	print u +"║"+ c +"01"+ u +"║"+ c +" Bot"
	print u +"║"+ m +"02"+ u +"║"+ m +" Download Musik Di Spotify"
	print u +"║"+ h +"03"+ u +"║"+ h +" Facebook"
	print u +"║"+ k +"04"+ u +"║"+ k +" Hack Kamera Depan"
	print u +"║"+ p +"05"+ u +"║"+ p +" Live Streaming Cctv"
	print u +"║"+ b +"06"+ u +"║"+ b +" Nomor NIK Dan Nomor KK"
	print u +"║"+ n +"07"+ u +"║"+ n +" Sms Gratis"
	print u +"║"+ c +"08"+ u +"║"+ c +" Spam Kode OTP"
	print u +"║"+ m +"09"+ u +"║"+ m +" Streaming Musik Di Youtube"
	print u +"║"+ h +"99"+ u +"║"+ h +" Keluar"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if irul == "00" or irul == "0":
		pembaruan()
	elif irul == "01" or irul == "1":
		bot()
	elif irul == "02" or irul == "2":
		spotify()
	elif irul == "03" or irul == "3":
		chdir ("facebook")
		system ("python2 irul.py")
	elif irul == "04" or irul == "4":
		hack_kamera_depan()
	elif irul == "05" or irul == "5":
		system ("xdg-open http://www.insecam.org")
		menu()
	elif irul == "06" or irul == "6":
		system ("php n")
		enter()
		system ("xdg-open https://nabila-tools.000webhostapp.com/e-ktp.php")
		menu()
	elif irul == "07" or irul == "7":
		system ("python sg.py")
		enter()
		menu()
	elif irul == "08" or irul == "8":
		spam()
	elif irul == "09" or irul == "9":
		youtube()
	elif irul == "99" or irul == "99":
		system ("clear")
		system ("pwd")
		system ("exit")
	else:
		salah()
		menu()


def pembaruan():
	system ("clear")
	print u +"                    ╔═══════════╗"
	print u +"                    ║"+ k +" Pembaruan "+ u +"║"
	print u +"                    ╚═══════════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Memperbarui Data-Data Script"
	print u +"║"+ k +"02"+ u +"║"+ k +" Memperbarui Data-Data Termux"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if irul == "01" or irul == "1":
		system ("xdg-open https://api.whatsapp.com/send?phone=6285856232526&text=Ahmad%20Khoirul%20Marzuqin")
		system ("xdg-open https://www.facebook.com/ahmadkhoirulmarzuqin")
		system ("xdg-open https://m.me/ahmadkhoirulmarzuqin")
		system ("xdg-open https://www.instagram.com/ahmad_khoirul_marzuqin")
		system ("clear")
		system ("rm -rf /data/data/com.termux/files/home/irul")
		chdir ("/data/data/com.termux/files/home")
		system ("git clone https://github.com/jekitut/irul")
		chdir ("/data/data/com.termux/files/home/irul")
		system ("unzip /data/data/com.termux/files/home/irul/irul.zip")
		system ("rm -rf /data/data/com.termux/files/home/irul/irul.zip")
		system ("rm -rf /data/data/com.termux/files/home/irul/update")
		system ("rm -rf /data/data/com.termux/files/home/storage/shared/Spotify.txt")
		system ("rm -rf /data/data/com.termux/files/home/.termux")
		system ("rm -rf /data/data/com.termux/files/usr/etc/bash.bashrc")
		move ("/data/data/com.termux/files/home/irul/bash.bashrc", "/data/data/com.termux/files/usr/etc/bash.bashrc")
		move ("/data/data/com.termux/files/home/irul/.termux", "/data/data/com.termux/files/home/.termux")
		move ("/data/data/com.termux/files/home/irul/Spotify.txt", "/data/data/com.termux/files/home/storage/shared/Spotify.txt")
		system ("termux-reload-settings")
		system ("termux-setup-storage")
		system ("python2 irul.py")
	elif irul == "02" or irul == "2":
		system ("clear")
		system ("pkg update")
		system ("pkg upgrade")
		system ("pkg install bash")
		system ("pkg install curl")
		system ("pkg install figlet")
		system ("pkg install grep -y")
		system ("pkg install jq")
		system ("pkg install mc -y")
		system ("pkg install mpv -y")
		system ("pkg install nano")
		system ("pkg install openssh -y")
		system ("pkg install php -y")
		system ("pkg install python -y")
		system ("pkg install python2 -y")
		system ("pkg install ruby -y")
		system ("pkg install termux-api")
		system ("pkg install unzip")
		system ("pkg install zip")
		system ("pkg install wget")
		system ("pip install --upgrade pip")
		system ("pip install bs4")
		system ("pip install mechanize")
		system ("pip install mps-youtube")
		system ("pip install mutagen")
		system ("pip install requests")
		system ("pip install spotdl")
		system ("pip install uncompyle6")
		system ("pip install youtube-dl")
		system ("pip2 install bs4")
		system ("pip2 install mechanize")
		system ("pip2 install mutagen")
		system ("pip2 install requests")
		system ("pip2 install uncompyle6")
		system ("gem install lolcat")
		menu()
	elif irul == "09" or irul == "9":
		menu()
	else:
		salah()
		pembaruan()


def bot():
	system ("clear")
	chdir ("bot")
	print u +"                       ╔═════╗"
	print u +"                       ║"+ k +" Bot "+ u +"║"
	print u +"                       ╚═════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ c +"00"+ u +"║"+ c +" Edit Data Aplikasi"
	print u +"║"+ h +"01"+ u +"║"+ h +" Baca Plus"
	print u +"║"+ h +"02"+ u +"║"+ h +" Caping"
	print u +"║"+ k +"03"+ u +"║"+ k +" Cashtree"
	print u +"║"+ k +"04"+ u +"║"+ k +" Flash Go"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if irul == "00" or irul == "0":
		def editdata():
			system ("clear")
			print u +"               ╔════════════════════╗"
			print u +"               ║"+ k +" Edit Data Aplikasi "+ u +"║"
			print u +"               ╚════════════════════╝\n"
			print u +"╔══╗"
			print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
			print u +"║  ║"
			print u +"║"+ h +"01"+ u +"║"+ h +" Cashtree"
			print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
			print u +"╚══╝"
			edit = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
			if edit == "01" or edit == "1":
				system ("nano bct")
				chdir ("..")
				bot()
			elif edit == "09" or edit == "9":
				chdir ("..")
				bot()
			else:
				salah()
				editdata()
		editdata()
	elif irul == "01" or irul == "1":
		system ("php bb")
		enter()
		chdir ("..")
		bot()
	elif irul == "02" or irul == "2":
		chdir ("caping")
		system ("php bot_caping")
		enter()
		chdir ("../..")
		bot()
	elif irul == "03" or irul == "3":
		system ("php bct")
		enter()
		chdir ("..")
		bot()
	elif irul == "04" or irul == "4":
		system ("php bf")
		enter()
		chdir ("..")
		bot()
	elif irul == "09" or irul == "9":
		chdir ("..")
		menu()
	else:
		salah()
		chdir ("..")
		bot()


def spotify():
	def logo():
		system ("clear")
		print u +"            ╔═══════════════════════════╗"
		print u +"            ║"+ k +" Download Musik Di Spotify "+ u +"║"
		print u +"            ╚═══════════════════════════╝\n"
	logo()
	print n +"Pastikan Anda Sudah Mengisi Url Di"
	print n +"Memori Internal Dengan Nama "+ h + tebal +"Spotify.txt\n"+ n
	raw_input ( h +"Tekan Tombol Enter Untuk Melanjutkan ")
	logo()
	chdir ("/data/data/com.termux/files/home/storage/shared")
	system ("spotdl -l Spotify.txt -f Spotify")
	logo()
	chdir ("/data/data/com.termux/files/home/irul")
	print h +"✓"+ n +" Berhasil Mendownload Musik Ke"
	print n +"  Memori Internal Dengan Nama "+ h + tebal +"Spotify"+ n
	enter()
	menu()


def hack_kamera_depan():
	system ("clear")
	print u +"                ╔═══════════════════╗"
	print u +"                ║"+ k +" Hack Kamera Depan "+ u +"║"
	print u +"                ╚═══════════════════╝\n"
	print n +"Apakah Anda Ingin Mengganti Template Html"
	print h +"Tidak (Tekan Tombol Enter)"+ n +" Atau"
	data = raw_input (m +"Ya (Ketik Ya)"+ n +" : "+ b)
	if data == "Ya" or data == "ya" or data == "YA":
		try:
			open ("/data/data/com.termux/files/home/storage/shared/irul.html", "r")
			system ("rm -rf /data/data/com.termux/files/home/irul/hack_kamera_depan/irul.html")
			copy ("/data/data/com.termux/files/home/storage/shared/irul.html", "/data/data/com.termux/files/home/irul/hack_kamera_depan")
			system ("clear")
			print h +"✓"+ n +" Berhasil Mengganti Template Html"
			enter()
			hack_kamera_depan()
		except IOError:
			system ("clear")
			print m +"!!! Template Html Tidak Ditemukan !!!"
			print n +"Pastikan File Ada Di Memori"
			print n +"Internal Dengan Nama "+ h + tebal +"irul.html"+ n
			enter()
			hack_kamera_depan()
	else:
		chdir ("hack_kamera_depan")
		system ("bash irul.sh")
		chdir ("..")
		menu()


def spam():
	system ("clear")
	print u +"                  ╔═══════════════╗"
	print u +"                  ║"+ k +" Spam Kode OTP "+ u +"║"
	print u +"                  ╚═══════════════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" 25 Kode OTP"
	print u +"║"+ p +"02"+ u +"║"+ p +" King Tools"
	print u +"║"+ b +"03"+ u +"║"+ b +" REV-ZONE.NET"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor "+ n +": ")
	if irul == "01" or irul == "1":
		chdir ("spam")
		def logo():
			system ("clear")
			print u +"              ╔══════════════════════╗"
			print u +"              ║"+ k +" Jumlah Kode OTP "+ n +":"+ h +" 25 "+ u +"║"
			print u +"              ╚══════════════════════╝\n"
		def start():
			try:
				logo()
				jl = json.load (open ("nomor.json"))
				print k +"Nomor Tujuan"+ n +" : "+ h + jl["nomor"]
				print h +"Jumlah Pesan"+ n +" : "+ k + jl["jumlah"]
				print p +"Jeda Pesan"+ n +"   : "+ b + jl["jeda"]
				bs()
			except IOError:
				logo()
				nomor = raw_input (k +"Nomor Tujuan"+ n +" : "+ h)
				jumlah = raw_input (h +"Jumlah Pesan"+ n +" : "+ k)
				jeda = raw_input (p +"Jeda Pesan  "+ n +" : "+ b)
				json.dump ({"nomor": nomor, "jumlah": jumlah, "jeda": jeda}, open ("nomor.json", "w"))
				json.dump ([{"nomor": nomor, "jumlah": jumlah, "jeda": jeda}], open ("nomor.php", "w"))
				bs()
		def bs():
			print n +"\nApakah Data-Data Di Atas Sudah"
			print h +"Benar (Tekan Tombol Enter)"+ n +" Atau"
			data = raw_input (m +"Salah (Ketik Salah)"+ n +" : "+ b)
			print ""
			if data == "Salah" or data == "salah" or data == "SALAH":
				system ("rm -rf nomor.json")
				start()
			else:
				system ("python2 irul.py")
				chdir ("..")
				spam()
		start()
	elif irul == "02" or irul == "2":
		system ("xdg-open http://kingtools.id")
		spam()
	elif irul == "03" or irul == "3":
		system ("xdg-open https://www.rev-zone.net")
		spam()
	elif irul == "09" or irul == "9":
		menu()
	else:
		salah()
		spam()


def youtube():
	irul_youtube = raw_input (u +"\n›"+ k +" Judul Lagu "+ n +": "+ h)
	system ("termux-tts-speak "+ irul_youtube)
	system ("mpsyt /"+ irul_youtube)
	menu()


# Ahmad Khoirul Marzuqin


def menu():
	system ("clear")
	hari = ("Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu", "Minggu")
	tanggal = ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31")
	bulan = ("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember")
	jam = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23")
	menit = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59")
	emit = time.localtime(time.time())
	print h +"Sekarang"+ n +"     : "+ str(hari[emit[6]]) +", "+ str(tanggal[emit[2]-1]) +" "+ str(bulan[emit[1]-1]) +" "+ str(emit[0]) + u +" ║ "+ n + str(jam[emit[3]]) +":"+ str(menit[emit[4]]) +":"+ str(menit[emit[5]])
	update()


def update():
	try:
		rg = get ("https://raw.githubusercontent.com/jekitut/irul/master/update").text
		exec rg
		print u + 53 * "═"+ m +"\nNama Pembuat"+ n +" : "+ c + miring + tebal +"Ahmad Khoirul Marzuqin\n"+ n
		jekitut()
	except ConnectionError:
		koneksi()
		update()


menu()